#!/usr/bin/env python3
"""
================================================================================
FILE        : GUI.py
PROJECT     : Sylla CAN Data Logger
COMPANY     : Sarla Aviation
DESCRIPTION : UDP-based CAN Logger Control GUI

              This application provides a graphical interface to remotely
              control CAN data logging on a Raspberry Pi flight controller.
              Commands are sent via UDP and acknowledgements are received
              on fixed listen ports.

PROTOCOL:
              LAPTOP  ──[UDP CMD]──▶  PI (UDP_IP:UDP_PORT_A / UDP_PORT_B)
              LAPTOP  ◀─[UDP ACK]──  PI (local_ip:LISTEN_PORT_A / LISTEN_PORT_B)

COMMANDS:
              "1"  →  Start logging CAN data to timestamped file on Pi
              "0"  →  Stop  logging

REPLIES:
              "1"  ←  Logging started acknowledgement
              "0"  ←  Logging stopped acknowledgement

CAN CHANNELS:
              CAN A — Send: 8881  |  Listen: 9991
              CAN B — Send: 8882  |  Listen: 9992

AUTHOR      : Vijay Singh — Embedded Systems Team

CHANGELOG:
              - Button states now updated ONLY after Pi ACK received
                (fixes state mismatch after USB remove/reinsert)
              - Local IP is read dynamically on every packet send
                (reflects correct IP even after network changes)
              - Background IP monitor refreshes GUI title bars every 2 s
                and rebinds sockets when the network interface changes
================================================================================
"""

import socket
import tkinter as tk
import threading
from datetime import datetime

# ================================================================================
#  NETWORK CONFIGURATION
#  Modify these values to match your network setup.
# ================================================================================
UDP_IP        = "192.168.0.101"   # Raspberry Pi IP address

UDP_PORT_A    = 8881              # Pi listens here  — CAN A
UDP_PORT_B    = 8882              # Pi listens here  — CAN B

LISTEN_PORT_A = 9991              # GUI listens here — CAN A replies
LISTEN_PORT_B = 9992              # GUI listens here — CAN B replies

# ================================================================================
#  UI THEME — COLOR PALETTE
# ================================================================================
BG_DARK    = "#1a1a2e"
BG_PANEL   = "#16213e"
BG_CARD    = "#0f3460"
GREEN      = "#00d26a"
RED        = "#ff4757"
BLUE       = "#1e90ff"
YELLOW     = "#ffa502"
CYAN       = "#00d2d3"   # CAN A accent
ORANGE     = "#ff6b35"   # CAN B accent
TEXT_WHITE = "#ffffff"
TEXT_GRAY  = "#a0a0b0"
FONT_MONO  = ("Consolas", 9)

# ================================================================================
#  LOCAL IP HELPER
#  _current_local_ip is the single source of truth for the current local IP.
#  It is updated every 2 seconds by the background monitor thread and read
#  by send_command() on every packet transmission.
# ================================================================================
_current_local_ip = "0.0.0.0"   # Initialised before get_local_ip() is called


def get_local_ip():
    """
    Resolve the current local IP address dynamically.

    Opens a temporary UDP socket connected to a public address (does not
    actually send any data) to determine which local interface the OS
    would use for outbound traffic.  Falls back to gethostbyname() if
    the preferred method fails.

    Returns:
        str: Dotted-decimal local IPv4 address, e.g. "192.168.0.10".
    """
    try:
        # Connect to an external address — no data is sent, but the OS
        # selects the correct outbound interface, giving us its local IP.
        tmp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        tmp.connect(("8.8.8.8", 80))
        ip = tmp.getsockname()[0]
        tmp.close()
        return ip
    except Exception:
        # Fallback: resolve hostname (may return 127.0.0.1 on some systems)
        return socket.gethostbyname(socket.gethostname())


# Seed the shared IP variable at startup
_current_local_ip = get_local_ip()

# ================================================================================
#  SOCKET SETUP — One socket per CAN channel
#  Bound to 0.0.0.0 so replies are accepted on any local interface.
#  Sockets are rebound by rebind_sockets() whenever the IP changes.
# ================================================================================
sock_a = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock_a.settimeout(5)
sock_a.bind(("0.0.0.0", LISTEN_PORT_A))

sock_b = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock_b.settimeout(5)
sock_b.bind(("0.0.0.0", LISTEN_PORT_B))

print("=" * 60)
print("  UDP Network Configuration")
print("=" * 60)
print(f"[CAN A] Send → {UDP_IP}:{UDP_PORT_A}   |  Listen → {_current_local_ip}:{LISTEN_PORT_A}")
print(f"[CAN B] Send → {UDP_IP}:{UDP_PORT_B}   |  Listen → {_current_local_ip}:{LISTEN_PORT_B}")
print("=" * 60)


# ================================================================================
#  SOCKET REBIND
#  Called whenever the local IP changes to discard the stale socket and
#  create a fresh one bound to 0.0.0.0 on the same listen port.
# ================================================================================
def rebind_sockets():
    """
    Close and rebind both UDP sockets to 0.0.0.0 on their listen ports.

    Must be called from the main thread (via root.after) to avoid race
    conditions with send_command() which also uses these sockets.
    Both sockets are recreated with the same 5-second timeout.
    """
    global sock_a, sock_b

    # ── Rebind CAN A socket ───────────────────────────────────────────────────
    try:
        sock_a.close()
    except Exception:
        pass
    sock_a = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock_a.settimeout(5)
    sock_a.bind(("0.0.0.0", LISTEN_PORT_A))
    print(f"[SYSTEM] CAN A socket rebound → 0.0.0.0:{LISTEN_PORT_A}")

    # ── Rebind CAN B socket ───────────────────────────────────────────────────
    try:
        sock_b.close()
    except Exception:
        pass
    sock_b = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock_b.settimeout(5)
    sock_b.bind(("0.0.0.0", LISTEN_PORT_B))
    print(f"[SYSTEM] CAN B socket rebound → 0.0.0.0:{LISTEN_PORT_B}")


# ================================================================================
#  BACKGROUND IP MONITOR
#  Polls get_local_ip() every 2 seconds.  When a change is detected it
#  schedules _on_ip_changed() on the main thread via root.after() — direct
#  tkinter calls from background threads are unsafe.
# ================================================================================
def start_ip_monitor():
    """
    Start a daemon thread that polls the local IP every 2 seconds.

    On IP change:
      - Updates _current_local_ip (shared variable)
      - Calls _on_ip_changed() on the main thread to refresh the GUI,
        rebind sockets, and log the event.

    The thread exits automatically when the GUI window is closed because
    it is marked as a daemon thread.
    """
    def _monitor():
        global _current_local_ip
        while True:
            new_ip = get_local_ip()
            if new_ip != _current_local_ip:
                old_ip = _current_local_ip
                _current_local_ip = new_ip
                # Schedule GUI update safely on the main thread
                root.after(0, lambda n=new_ip, o=old_ip: _on_ip_changed(n, o))
            threading.Event().wait(2)   # Poll interval — 2 seconds

    threading.Thread(target=_monitor, daemon=True).start()


def _on_ip_changed(new_ip, old_ip):
    """
    Called on the main thread when the local IP address changes.

    Actions performed:
      1. Rebind both UDP sockets on the new interface.
      2. Update both CAN channel title bar labels with the new IP.
      3. Reset both channel indicators and buttons to safe WAITING state
         (actual Pi state is unknown until next command is sent).
      4. Log the change to the activity log.

    Args:
        new_ip (str): The newly detected local IP address.
        old_ip (str): The previous local IP address.
    """
    # ── 1. Rebind sockets so they are fresh on the new interface ─────────────
    rebind_sockets()

    # ── 2. Refresh title bar labels ───────────────────────────────────────────
    title_label_a.config(
        text=f"  CAN A   |   TX → {UDP_IP}:{UDP_PORT_A}   |   RX ← {new_ip}:{LISTEN_PORT_A}"
    )
    title_label_b.config(
        text=f"  CAN B   |   TX → {UDP_IP}:{UDP_PORT_B}   |   RX ← {new_ip}:{LISTEN_PORT_B}"
    )

    # ── 3. Reset indicators and buttons to safe state ─────────────────────────
    update_indicator("waiting", "A")
    update_indicator("waiting", "B")
    start_btn_a.config(state="normal")
    stop_btn_a.config(state="disabled")
    start_btn_b.config(state="normal")
    stop_btn_b.config(state="disabled")

    # ── 4. Log the event ──────────────────────────────────────────────────────
    ts = datetime.now().strftime("%H:%M:%S")
    append_log(
        f"[{ts}][SYSTEM] ⚠ Network changed — Local IP: {old_ip}  →  {new_ip}",
        YELLOW
    )
    append_log(
        f"[{ts}][SYSTEM] ↺ Sockets rebound on new interface — Ready",
        CYAN
    )
    print(f"[SYSTEM] Local IP changed: {old_ip} → {new_ip} — Sockets rebound")


# ================================================================================
#  SEND FUNCTION
#  Reads the current local IP from _current_local_ip on every call.
#  Button states are updated ONLY after the Pi ACK is received — never on
#  the button click — preventing state mismatch after USB remove/reinsert.
# ================================================================================
def send_command(cmd, channel):
    """
    Send a UDP command to the Pi on the specified CAN channel and wait for ACK.

    The local IP (_current_local_ip) is read at the moment of sending so
    that the correct interface IP is always logged and displayed.

    Button states (START / STOP) are updated exclusively based on the
    Pi's reply — never on the button click itself — so the GUI always
    reflects the Pi's actual logging state.

    Args:
        cmd     (str): "1" for START, "0" for STOP.
        channel (str): "A" or "B" — selects port, socket, and buttons.
    """

    # ── Select channel-specific resources ────────────────────────────────────
    if channel == "A":
        sock        = sock_a
        udp_port    = UDP_PORT_A
        listen_port = LISTEN_PORT_A
        label       = "CAN A"
        upd_ind     = lambda s: update_indicator(s, "A")
        start_btn   = start_btn_a
        stop_btn    = stop_btn_a
    else:
        sock        = sock_b
        udp_port    = UDP_PORT_B
        listen_port = LISTEN_PORT_B
        label       = "CAN B"
        upd_ind     = lambda s: update_indicator(s, "B")
        start_btn   = start_btn_b
        stop_btn    = stop_btn_b

    # ── Read local IP at the exact moment of sending ──────────────────────────
    # _current_local_ip is kept up-to-date by the background monitor thread.
    current_local_ip = _current_local_ip

    try:
        # Show WAITING state and disable both buttons until ACK arrives
        upd_ind("waiting")
        start_btn.config(state="disabled")
        stop_btn.config(state="disabled")

        # ── Transmit command ─────────────────────────────────────────────────
        sock.sendto(cmd.encode(), (UDP_IP, udp_port))
        ts = datetime.now().strftime("%H:%M:%S")

        print(f"[TX][{label}] Sent '{cmd}' → {UDP_IP}:{udp_port}  (from {current_local_ip}:{listen_port})")
        append_log(
            f"[{ts}][{label}] TX → Sent '{cmd}' to {UDP_IP}:{udp_port}  (from {current_local_ip}:{listen_port})",
            YELLOW
        )

        # ── Wait for ACK from Pi ─────────────────────────────────────────────
        data, addr = sock.recvfrom(1024)
        reply = data.decode().strip()
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[RX][{label}] '{reply}' from {addr[0]}:{addr[1]}")

        # ── Handle reply — update buttons ONLY here ──────────────────────────
        if reply == "1":
            # Pi confirmed: logging STARTED → disable START, enable STOP
            start_btn.config(state="disabled")
            stop_btn.config(state="normal")
            upd_ind("active")
            append_log(
                f"[{ts}][{label}] RX ← Logging STARTED  (from {addr[0]}:{addr[1]})",
                GREEN
            )

        elif reply == "0":
            # Pi confirmed: logging STOPPED → enable START, disable STOP
            start_btn.config(state="normal")
            stop_btn.config(state="disabled")
            upd_ind("stopped")
            append_log(
                f"[{ts}][{label}] RX ← Logging STOPPED  (from {addr[0]}:{addr[1]})",
                RED
            )

        else:
            # Unknown reply → reset to safe idle state
            start_btn.config(state="normal")
            stop_btn.config(state="disabled")
            upd_ind("waiting")
            append_log(
                f"[{ts}][{label}] RX ← Unknown reply: '{reply}'",
                BLUE
            )

    except socket.timeout:
        # ── Timeout (e.g. USB removed / Pi not reachable / network changed) ──
        # Reset GUI to safe state so the operator can retry START.
        start_btn.config(state="normal")
        stop_btn.config(state="disabled")
        upd_ind("waiting")
        ts = datetime.now().strftime("%H:%M:%S")
        append_log(
            f"[{ts}][{label}] ⚠ Timeout — No response from {UDP_IP}:{udp_port}",
            RED
        )
        print(f"[ERROR][{label}] Timeout waiting for reply from {UDP_IP}:{udp_port}")


def start_logging(channel):
    """
    Dispatch a START command ("1") for the given CAN channel in a background
    thread.  Button states are NOT changed here — updated after Pi ACK.

    Args:
        channel (str): "A" or "B".
    """
    threading.Thread(target=send_command, args=("1", channel), daemon=True).start()


def stop_logging(channel):
    """
    Dispatch a STOP command ("0") for the given CAN channel in a background
    thread.  Button states are NOT changed here — updated after Pi ACK.

    Args:
        channel (str): "A" or "B".
    """
    threading.Thread(target=send_command, args=("0", channel), daemon=True).start()


# ================================================================================
#  GUI HELPER FUNCTIONS
# ================================================================================

def update_indicator(state, channel):
    """
    Update the status indicator dot and label for the given CAN channel.

    Args:
        state   (str): "active"  → GREEN  (logging running)
                       "stopped" → RED    (logging stopped)
                       "waiting" → YELLOW (awaiting Pi reply)
        channel (str): "A" or "B".
    """
    if channel == "A":
        dot_canvas, dot_id = indicator_dot_a, dot_a
        lbl   = indicator_label_a
        s_var = status_var_a
    else:
        dot_canvas, dot_id = indicator_dot_b, dot_b
        lbl   = indicator_label_b
        s_var = status_var_b

    ch = f"CAN {channel}"

    if state == "active":
        dot_canvas.itemconfig(dot_id, fill=GREEN, outline=GREEN)
        lbl.config(text=f"● {ch} LOGGING ACTIVE", fg=GREEN)
        s_var.set(f"{ch} is actively logging CAN data")
    elif state == "stopped":
        dot_canvas.itemconfig(dot_id, fill=RED, outline=RED)
        lbl.config(text=f"● {ch} LOGGING STOPPED", fg=RED)
        s_var.set(f"{ch} logging has been stopped")
    else:   # "waiting"
        dot_canvas.itemconfig(dot_id, fill=YELLOW, outline=YELLOW)
        lbl.config(text=f"● {ch} WAITING...", fg=YELLOW)
        s_var.set(f"{ch} — Waiting for response from Pi...")


def append_log(text, color=TEXT_WHITE):
    """
    Append a line to the activity log text box with the given color.

    Args:
        text  (str): Message to append.
        color (str): Hex color string for the text (defaults to white).
    """
    log_box.config(state="normal")
    log_box.insert(tk.END, text + "\n", color)
    log_box.tag_config(color, foreground=color)
    log_box.see(tk.END)
    log_box.config(state="disabled")


def clear_log():
    """Clear all entries from the activity log."""
    log_box.config(state="normal")
    log_box.delete("1.0", tk.END)
    log_box.config(state="disabled")


# ================================================================================
#  REUSABLE CHANNEL CARD BUILDER
# ================================================================================

def build_channel_card(parent, channel, accent_color, send_port, listen_port):
    """
    Build a complete status + control card for one CAN channel.

    The title bar label is returned so the IP monitor can update its text
    live whenever the local IP changes.

    Args:
        parent       : Parent tkinter widget.
        channel      : "A" or "B".
        accent_color : Hex color for the card title bar.
        send_port    : UDP port the Pi listens on for commands.
        listen_port  : UDP port the GUI listens on for ACKs.

    Returns:
        tuple: (dot_canvas, dot_oval_id, indicator_label, status_var,
                start_button, stop_button, title_label)
    """
    card = tk.Frame(parent, bg=BG_PANEL, relief="flat", bd=0)
    card.pack(fill="x", pady=(0, 10))

    # ── Card title bar ────────────────────────────────────────────────────────
    title_bar = tk.Frame(card, bg=accent_color, height=26)
    title_bar.pack(fill="x")
    title_bar.pack_propagate(False)

    # Store label reference — returned so _on_ip_changed() can update it live
    t_label = tk.Label(
        title_bar,
        text=f"  CAN {channel}   |   TX → {UDP_IP}:{send_port}   |   RX ← {_current_local_ip}:{listen_port}",
        font=("Consolas", 8, "bold"),
        bg=accent_color, fg="#000000"
    )
    t_label.pack(side="left", padx=6, pady=4)

    # ── Indicator row ─────────────────────────────────────────────────────────
    ind_frame = tk.Frame(card, bg=BG_PANEL)
    ind_frame.pack(pady=8)

    dot_canvas = tk.Canvas(ind_frame, width=20, height=20,
                           bg=BG_PANEL, highlightthickness=0)
    dot_canvas.pack(side="left")
    dot_id = dot_canvas.create_oval(2, 2, 18, 18, fill=BLUE, outline=BLUE)

    ind_label = tk.Label(ind_frame,
                         text=f"● CAN {channel} IDLE",
                         font=("Consolas", 12, "bold"),
                         bg=BG_PANEL, fg=BLUE)
    ind_label.pack(side="left", padx=8)

    s_var = tk.StringVar(value=f"Ready — Press Start to begin CAN {channel} logging")
    tk.Label(card,
             textvariable=s_var,
             font=("Consolas", 9),
             bg=BG_PANEL, fg=TEXT_GRAY).pack(pady=(0, 6))

    # ── Buttons ───────────────────────────────────────────────────────────────
    btn_row = tk.Frame(card, bg=BG_PANEL)
    btn_row.pack(fill="x", padx=10, pady=(0, 10))

    s_btn = tk.Button(btn_row,
                      text=f"▶   START CAN {channel}",
                      font=("Consolas", 10, "bold"),
                      bg=GREEN, fg="#000000",
                      activebackground="#00b359",
                      relief="flat", cursor="hand2",
                      width=18, height=2,
                      command=lambda: start_logging(channel))
    s_btn.pack(side="left", expand=True, fill="x", padx=(0, 5))

    p_btn = tk.Button(btn_row,
                      text=f"■   STOP CAN {channel}",
                      font=("Consolas", 10, "bold"),
                      bg=RED, fg=TEXT_WHITE,
                      activebackground="#cc2233",
                      relief="flat", cursor="hand2",
                      width=18, height=2,
                      state="disabled",
                      command=lambda: stop_logging(channel))
    p_btn.pack(side="left", expand=True, fill="x", padx=(5, 0))

    return dot_canvas, dot_id, ind_label, s_var, s_btn, p_btn, t_label


# ================================================================================
#  GUI LAYOUT
# ================================================================================

root = tk.Tk()
root.title("CAN Logger Control — Dual Channel")
root.geometry("620x780")
root.configure(bg=BG_DARK)
root.resizable(False, False)

# ── Header ────────────────────────────────────────────────────────────────────
header = tk.Frame(root, bg=BG_CARD, height=60)
header.pack(fill="x")
header.pack_propagate(False)

tk.Label(header,
         text="✈  CAN LOGGER CONTROL  —  DUAL CHANNEL",
         font=("Consolas", 14, "bold"),
         bg=BG_CARD, fg=TEXT_WHITE).pack(side="left", padx=20, pady=10)

tk.Label(header,
         text="SARLA AVIATION",
         font=("Consolas", 9),
         bg=BG_CARD, fg=TEXT_GRAY).pack(side="right", padx=20)

# ── Content area ──────────────────────────────────────────────────────────────
content = tk.Frame(root, bg=BG_DARK)
content.pack(fill="both", expand=True, padx=15, pady=10)

# ── CAN A Card ────────────────────────────────────────────────────────────────
(indicator_dot_a, dot_a,
 indicator_label_a, status_var_a,
 start_btn_a, stop_btn_a,
 title_label_a) = build_channel_card(
    content, "A", CYAN, UDP_PORT_A, LISTEN_PORT_A)

# ── CAN B Card ────────────────────────────────────────────────────────────────
(indicator_dot_b, dot_b,
 indicator_label_b, status_var_b,
 start_btn_b, stop_btn_b,
 title_label_b) = build_channel_card(
    content, "B", ORANGE, UDP_PORT_B, LISTEN_PORT_B)

# ── Start background IP monitor ───────────────────────────────────────────────
# Must be called AFTER title_label_a and title_label_b are created so that
# _on_ip_changed() can safely reference and update them.
start_ip_monitor()

# ── Activity Log ──────────────────────────────────────────────────────────────
log_header = tk.Frame(content, bg=BG_DARK)
log_header.pack(fill="x", pady=(5, 3))

tk.Label(log_header,
         text="ACTIVITY LOG",
         font=("Consolas", 9, "bold"),
         bg=BG_DARK, fg=TEXT_GRAY).pack(side="left")

tk.Button(log_header,
          text="CLEAR",
          font=("Consolas", 8),
          bg=BG_PANEL, fg=TEXT_GRAY,
          relief="flat", cursor="hand2", padx=8,
          command=clear_log).pack(side="right")

log_frame = tk.Frame(content, bg="#0a0a1a", bd=1, relief="solid")
log_frame.pack(fill="both", expand=True)

log_box = tk.Text(log_frame,
                  bg="#0a0a1a", fg=TEXT_WHITE,
                  font=FONT_MONO,
                  relief="flat", bd=0,
                  state="disabled",
                  wrap="word",
                  insertbackground=TEXT_WHITE)
log_box.pack(side="left", fill="both", expand=True, padx=6, pady=6)

log_scroll = tk.Scrollbar(log_frame, command=log_box.yview,
                           bg=BG_PANEL, troughcolor=BG_DARK)
log_scroll.pack(side="right", fill="y")
log_box.config(yscrollcommand=log_scroll.set)

# ── Footer ────────────────────────────────────────────────────────────────────
footer = tk.Frame(root, bg=BG_PANEL, height=28)
footer.pack(fill="x", side="bottom")
footer.pack_propagate(False)

tk.Label(footer,
         text="● GREEN = Active   ● RED = Stopped   ● YELLOW = Waiting   ● CYAN = CAN A   ● ORANGE = CAN B",
         font=("Consolas", 8),
         bg=BG_PANEL, fg=TEXT_GRAY).pack(pady=5)

# ================================================================================
#  STARTUP LOG MESSAGES
# ================================================================================
append_log("[SYSTEM] CAN Logger GUI started — Dual Channel Mode", BLUE)
append_log(f"[CAN A] TX → {UDP_IP}:{UDP_PORT_A}   |   RX ← {_current_local_ip}:{LISTEN_PORT_A}", CYAN)
append_log(f"[CAN B] TX → {UDP_IP}:{UDP_PORT_B}   |   RX ← {_current_local_ip}:{LISTEN_PORT_B}", ORANGE)
append_log("[SYSTEM] Ready — waiting for commands...", TEXT_GRAY)

# ================================================================================
#  START GUI EVENT LOOP
# ================================================================================
root.mainloop()