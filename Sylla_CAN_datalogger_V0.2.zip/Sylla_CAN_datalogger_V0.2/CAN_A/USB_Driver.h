/**
 * @file    USB_Driver.h
 * @brief   USB serial communication driver interface (libudev + POSIX threads).
 *
 * @details This header declares the public API for USB serial communication
 *          management on Linux. It uses **libudev** for device detection and
 *          **POSIX threads** for concurrent read/write handling.
 *
 *          Capabilities:
 *          - Automatic USB device detection by Vendor ID and Product ID.
 *          - Threaded receive loop with user-registered data callback.
 *          - Thread-safe transmit via mutex-protected @c write().
 *          - Auto-reconnection logic on device disconnect.
 *          - udev-based plug/unplug event monitoring.
 *
 *          Typical usage sequence:
 *          @code
 *          1. usb_init()                          // Initialise udev monitoring
 *          2. set_usb_data_callback(my_handler)   // Register RX data callback
 *          3. usb_run("/dev/ttyUSB0")             // Enter main USB event loop
 *          4. usb_send_data(buf, len)             // Send data (from any thread)
 *          5. usb_cleanup()                       // Release all resources
 *          @endcode
 *
 * @note    Link with @c -ludev and @c -lpthread when compiling.
 *
 * @author  Vijay Singh — Sarla Aviation, Embedded Systems Team
 * @version 1.0
 * @date    2025-11-03
 */

#ifndef USB_DRIVER_H
#define USB_DRIVER_H

/* ── Required System Headers ─────────────────────────────────────────────────── */
#include <libudev.h>     ///< libudev API          : udev_new, udev_monitor, udev_device
#include <stdio.h>       ///< Standard I/O         : printf, fprintf, perror
#include <stdlib.h>      ///< General utilities    : malloc, free, exit
#include <stdbool.h>     ///< Boolean type         : bool, true, false
#include <pthread.h>     ///< POSIX threads        : pthread_t, pthread_create, pthread_mutex_t

/* ═══════════════════════════════════════════════════════════════════════════════
 * USB DEVICE IDENTIFICATION
 * These values must match the idVendor and idProduct of the target hardware.
 * Verify with: lsusb | grep <device_name>
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @def   TARGET_VENDOR
 * @brief USB Vendor ID (VID) of the target USB-to-serial converter.
 *
 * @details @c "1a86" is the VID for QinHeng Electronics, commonly used on
 *          CH340/CH341-based USB serial adapters found on CAN logger hardware.
 *
 * @note  Verify with: @code lsusb | grep "1a86" @endcode
 */
#define TARGET_VENDOR     "1a86"   ///< QinHeng Electronics (CH340/CH341)

/**
 * @def   TARGET_PRODUCT
 * @brief USB Product ID (PID) of the target USB-to-serial converter.
 *
 * @details @c "7523" corresponds to the CH340 USB serial adapter.
 *          Paired with @c TARGET_VENDOR to uniquely identify the device.
 *
 * @note  Verify with: @code lsusb | grep "7523" @endcode
 */
#define TARGET_PRODUCT    "7523"   ///< CH340 USB serial adapter PID

/**
 * @def   BAUD_RATE_VALUE
 * @brief Serial communication baud rate in bits per second.
 *
 * @details Set to 2,000,000 bps (2 Mbaud) for high-speed CAN frame throughput.
 *          Must match the baud rate configured on the connected hardware device.
 *
 *          Supported values in @c configure_serial_port():
 *          @code
 *          9600, 19200, 38400, 57600, 115200, 2000000
 *          @endcode
 */
#define BAUD_RATE_VALUE   2000000U   ///< 2 Mbaud — high-speed serial for CAN frames

/* ═══════════════════════════════════════════════════════════════════════════════
 * USB OPERATIONAL PARAMETERS
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @def   MAX_FRAME_SIZE
 * @brief Maximum size in bytes of a single USB receive buffer or CAN data frame.
 *
 * @details Defines the upper bound for the RX thread's receive buffer.
 *          Frames larger than this value will be truncated by @c read().
 *          Increase if the hardware sends frames exceeding 256 bytes.
 */
#define MAX_FRAME_SIZE        256U   ///< USB RX buffer / frame size limit (bytes)

/**
 * @def   RECONNECT_DELAY_SEC
 * @brief Delay in seconds before retrying USB connection after a disconnect.
 *
 * @details Applied in @c usb_run() and @c USB_rx_thread() after detecting a
 *          device disconnection or serial port open failure. Prevents rapid
 *          retry loops that would consume unnecessary CPU resources.
 */
#define RECONNECT_DELAY_SEC   5U   ///< USB reconnect retry interval (seconds)

/**
 * @def   UDEV_MONITOR_TIMEOUT
 * @brief Timeout in milliseconds for the udev monitor @c poll() call in @c usb_run().
 *
 * @details Controls how long @c poll() blocks waiting for udev plug/unplug events.
 *          A shorter value increases responsiveness to device events but increases
 *          CPU usage. A longer value reduces CPU load but delays event detection.
 */
#define UDEV_MONITOR_TIMEOUT  1000U   ///< udev event poll timeout (milliseconds)

/* ═══════════════════════════════════════════════════════════════════════════════
 * GLOBAL VARIABLE DECLARATIONS
 * Defined in USB_Driver.c — declared here for access by other translation units.
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   File descriptor of the active USB serial device.
 *
 * @details Set to a valid fd (≥ 0) by @c configure_serial_port() when the device
 *          is successfully opened. Reset to @c -1 on disconnection or cleanup.
 *
 * @note    Do not close or modify @c usb_fd directly — use @c usb_cleanup().
 */
extern int usb_fd;

/**
 * @brief   POSIX thread ID of the USB receive thread.
 *
 * @details Created by @c usb_run() when a USB device is successfully opened.
 *          The thread runs @c USB_rx_thread() and is joined in @c usb_cleanup().
 *          Value is @c 0 when the thread has not been created.
 */
extern pthread_t rx_thread_id;

/**
 * @brief   Global control flag for USB thread lifecycle management.
 *
 * @details When @c true, USB threads continue running.
 *          Set to @c false by @c usb_cleanup() to signal all threads to exit
 *          their loops on the next iteration.
 *
 * @note    Declared @c volatile to prevent compiler optimisation from caching
 *          the value in a register — ensures cross-thread visibility.
 */
extern volatile bool running;

/* ═══════════════════════════════════════════════════════════════════════════════
 * CALLBACK TYPE DEFINITION
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @typedef data_received_callback
 * @brief   Function pointer type for the USB data receive callback.
 *
 * @details This callback is invoked by the RX thread (@c USB_rx_thread()) each
 *          time a new USB frame is successfully read from the serial device.
 *          Register it using @c set_usb_data_callback().
 *
 *          The callback must be fast and non-blocking. For heavy processing,
 *          copy the data and handle it in a separate thread.
 *
 * @param[in] data    Pointer to the raw received data buffer.
 *                    Valid only for the duration of the callback — copy if needed.
 * @param[in] length  Number of valid bytes in @p data.
 *
 * Example implementation:
 * @code
 * void my_usb_handler(const unsigned char *data, int length) {
 *     process_usb_data((uint8_t *)data, length);
 * }
 * @endcode
 */
typedef void (*data_received_callback)(const unsigned char *data, int length);

/* ═══════════════════════════════════════════════════════════════════════════════
 * C++ COMPATIBILITY GUARD
 * Ensures C linkage when included in C++ translation units.
 * ═══════════════════════════════════════════════════════════════════════════════ */
#ifdef __cplusplus
extern "C" {
#endif

/* ═══════════════════════════════════════════════════════════════════════════════
 * FUNCTION PROTOTYPES
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Initialise the USB subsystem and udev event monitoring.
 *
 * @details Creates a udev context and monitor filtered to the @c tty subsystem.
 *          Enables reception of kernel plug/unplug events for USB serial devices.
 *          Must be called once before @c usb_run().
 *
 * @note    Safe to call multiple times — releases existing resources before
 *          reinitialising.
 *
 * @return  @c true   on success — udev context and monitor are active.
 * @return  @c false  on failure — all udev resources are released on error.
 */
bool usb_init(void);


/**
 * @brief   Release all USB resources and stop all associated threads.
 *
 * @details Performs an ordered teardown:
 *          @code
 *          1. Set running = false   (signals threads to exit)
 *          2. Release udev monitor
 *          3. Release udev context
 *          4. Close USB file descriptor
 *          5. Join RX thread
 *          @endcode
 *
 * @note    Safe to call from the main thread or a signal handler.
 *          Checks @c pthread_self() to avoid deadlock if called from
 *          within the RX thread itself.
 *
 * @return  void
 */
void usb_cleanup(void);


/**
 * @brief   Register a user-defined callback for USB data reception.
 *
 * @details The registered callback is invoked by the RX thread each time a
 *          new USB frame arrives. Only one callback can be registered at a time —
 *          subsequent calls overwrite the previous registration.
 *
 * @param[in] callback  Pointer to the user-defined handler function.
 *                      Pass @c NULL to deregister (frames will be silently dropped).
 *
 * @note    The callback must remain valid for the full lifetime of the USB driver.
 *          Do not pass a pointer to a stack-allocated or local function.
 *
 * @warning Passing @c NULL disables data handling. A debug warning is printed
 *          if @c USB_DEBUG_PRINT is enabled.
 *
 * @return  void
 */
void set_usb_data_callback(data_received_callback callback);


/**
 * @brief   Execute the main USB communication and event loop.
 *
 * @details Manages the full USB connection lifecycle:
 *          @code
 *          1. Open serial port via configure_serial_port()
 *          2. Spawn RX thread on successful open
 *          3. Verify port health via tcgetattr() each iteration
 *          4. Poll udev monitor for plug/unplug events
 *          5. On disconnect: cancel RX thread, retry after RECONNECT_DELAY_SEC
 *          @endcode
 *
 *          Runs indefinitely while @c running is @c true. Call @c usb_cleanup()
 *          from another thread or signal handler to exit.
 *
 * @param[in] device_path  Path to the USB serial device (e.g., @c "/dev/ttyUSB0").
 *                         Must not be @c NULL.
 *
 * @warning @c usb_init() must be called successfully before @c usb_run().
 *          Calling without a valid udev monitor causes undefined behaviour.
 *
 * @return  void
 */
void usb_run(const char *device_path);


/**
 * @brief   Transmit data over the USB serial interface in a thread-safe manner.
 *
 * @details Acquires an internal send mutex, writes the full buffer to @c usb_fd
 *          in a loop (to handle partial @c write() returns), then releases the
 *          mutex. Safe to call from multiple threads concurrently.
 *
 * @param[in] data    Pointer to the data buffer to transmit. Must not be @c NULL.
 * @param[in] length  Number of bytes to send. Must be > 0.
 *
 * @note    Handles partial writes automatically — all @p length bytes are sent
 *          before the function returns (unless an error occurs).
 *
 * @warning Returns @c -1 immediately if the USB device is not open (@c usb_fd < 0).
 *          The mutex is always released before returning, even on error.
 *
 * @return  Total number of bytes written on success.
 * @return  @c -1 on failure — device not open, invalid arguments, or write error.
 */
int usb_send_data(const unsigned char *data, int length);

#ifdef __cplusplus
}
#endif

#endif /* USB_DRIVER_H */