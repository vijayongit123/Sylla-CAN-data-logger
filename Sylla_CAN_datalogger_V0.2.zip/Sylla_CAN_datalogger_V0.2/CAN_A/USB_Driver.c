/**
 * @file    USB_Driver.c
 * @brief   USB serial communication driver using libudev and POSIX APIs.
 *
 * @details This file implements the full USB communication lifecycle for the
 *          CAN data logger. It provides:
 *
 *          1. **Device discovery** — scans udev tty subsystem to locate the
 *             target USB serial device by vendor/product ID.
 *
 *          2. **Serial port configuration** — opens the device and applies
 *             raw 8N1 termios settings at the configured baud rate.
 *
 *          3. **Receive thread** — a dedicated POSIX thread that continuously
 *             reads incoming USB frames and dispatches them via a callback.
 *
 *          4. **Thread-safe transmit** — mutex-protected @c write() calls to
 *             prevent concurrent access from multiple threads.
 *
 *          5. **udev monitoring** — monitors kernel plug/unplug events for
 *             the tty subsystem to detect device connect/disconnect at runtime.
 *
 *          6. **Lifecycle management** — @c usb_init(), @c usb_run(), and
 *             @c usb_cleanup() manage the full driver lifecycle.
 *
 *          Threading model:
 *          @code
 *          main thread  →  usb_run()         (connection + udev event loop)
 *          rx_thread    →  USB_rx_thread()   (continuous read + callback dispatch)
 *          @endcode
 *
 * @note    Requires libudev. Link with @c -ludev during compilation.
 *
 * @author  Vijay Singh — Embedded Systems Team
 * @version 1.0
 */

/* ── Standard C Library Headers ─────────────────────────────────────────────── */
#include <fcntl.h>      ///< File control options  : open, O_RDWR, O_NOCTTY, O_NDELAY, fcntl
#include <termios.h>    ///< Terminal I/O control  : termios, tcgetattr, tcsetattr, cfmakeraw
#include <unistd.h>     ///< POSIX system calls    : read, write, close, sleep, usleep
#include <string.h>     ///< String utilities      : memset, strcmp, strdup
#include <errno.h>      ///< Error reporting       : errno, perror
#include <poll.h>       ///< I/O event polling     : poll, pollfd, POLLIN

/* ── System / POSIX Headers ─────────────────────────────────────────────────── */
#include <pthread.h>    ///< POSIX threads         : pthread_create, pthread_join, pthread_mutex_t

/* ── Project-Specific Headers ───────────────────────────────────────────────── */
#include "USB_Driver.h" ///< USB driver API        : function prototypes, macros, type definitions

/* ═══════════════════════════════════════════════════════════════════════════════
 * GLOBAL VARIABLES
 * Shared state variables used across USB driver functions.
 * ═══════════════════════════════════════════════════════════════════════════════ */

int           usb_fd      = -1;    ///< USB serial device file descriptor (-1 = not open)
pthread_t     rx_thread_id =  0;   ///< RX thread ID (0 = not created)
volatile bool running     = true;  ///< Thread control flag: true = run, false = stop

static data_received_callback USB_callback  = NULL;   ///< User-registered USB data callback
static struct udev            *udev_ctx     = NULL;   ///< Global udev context for device enumeration
static struct udev_monitor    *udev_monitor = NULL;   ///< udev monitor for tty plug/unplug events

/**
 * @brief Mutex protecting USB serial write operations.
 *
 * Statically initialised — no explicit @c pthread_mutex_init() required.
 * Ensures only one thread writes to @c usb_fd at a time.
 */
static pthread_mutex_t usb_send_mutex = PTHREAD_MUTEX_INITIALIZER;


/* ═══════════════════════════════════════════════════════════════════════════════
 * CALLBACK REGISTRATION
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Register a user-defined callback for USB data reception.
 *
 * @details Stores the provided function pointer in @c USB_callback. This
 *          callback is invoked by the RX thread (@c USB_rx_thread()) each time
 *          a new USB frame is successfully read from the serial device.
 *
 *          The callback signature must match @c data_received_callback:
 *          @code
 *          void my_callback(uint8_t *data, int len);
 *          @endcode
 *
 * @param[in] callback  Pointer to the user-defined receive handler.
 *                      Pass @c NULL to deregister the current callback.
 *
 * @note    The callback must remain valid for the entire lifetime of the USB
 *          driver. Do not pass a pointer to a local or stack-allocated function.
 *
 * @warning Passing @c NULL disables data handling — received frames will be
 *          silently dropped. A debug warning is printed if @c USB_DEBUG_PRINT
 *          is enabled.
 *
 * @return  void
 */
void set_usb_data_callback(data_received_callback callback) {

    /* ── Validate Callback Pointer ──────────────────────────────────────────
     * Reject NULL to avoid silently disabling data handling.
     * ────────────────────────────────────────────────────────────────────── */
    if (callback == NULL) {
#if USB_DEBUG_PRINT
        fprintf(stderr, "[USB] Warning: NULL callback passed to set_usb_data_callback.\n");
#endif
        return;
    }

    /* ── Register Callback ──────────────────────────────────────────────────
     * Store the user function pointer for use in the RX thread.
     * ────────────────────────────────────────────────────────────────────── */
    USB_callback = callback;

#if USB_DEBUG_PRINT
    printf("[USB] USB data receive callback successfully registered.\n");
#endif
}


/* ═══════════════════════════════════════════════════════════════════════════════
 * DEVICE DISCOVERY (STATIC — INTERNAL USE ONLY)
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Check whether a udev device matches the configured vendor and product ID.
 *
 * @details Traverses to the parent USB device of the provided tty node and
 *          compares its @c idVendor and @c idProduct sysfs attributes against
 *          @c TARGET_VENDOR and @c TARGET_PRODUCT defined in @c USB_Driver.h.
 *
 * @param[in] dev  Pointer to the udev device to evaluate. Must not be @c NULL.
 *
 * @note    This function is @c static — for internal use by @c find_target_usb_serial().
 *
 * @return  @c 1  if the device matches the target vendor and product ID.
 * @return  @c 0  if no match, or if @p dev is @c NULL.
 */
static int USB_target_device(struct udev_device *dev) {

    if (!dev) return 0;

    /* ── Traverse to Parent USB Device ─────────────────────────────────────
     * The tty node's parent USB device holds idVendor and idProduct sysfs
     * attributes used to identify the hardware.
     * ────────────────────────────────────────────────────────────────────── */
    struct udev_device *usb_dev = udev_device_get_parent_with_subsystem_devtype(
                                      dev, "usb", "usb_device");
    if (usb_dev) {
        const char *vendor  = udev_device_get_sysattr_value(usb_dev, "idVendor");
        const char *product = udev_device_get_sysattr_value(usb_dev, "idProduct");

        /* ── Compare Against Target IDs ─────────────────────────────────────
         * Both vendor and product must match for a positive identification.
         * ────────────────────────────────────────────────────────────────── */
        if (vendor && product &&
            strcmp(vendor,  TARGET_VENDOR)  == 0 &&
            strcmp(product, TARGET_PRODUCT) == 0) {
#if USB_DEBUG_PRINT
            printf("[USB] Matching device found: vendor=%s, product=%s\n", vendor, product);
#endif
            return 1;   /* Match confirmed */
        }
#if USB_DEBUG_PRINT
        else {
            printf("[USB] Skipped device: vendor=%s, product=%s\n",
                   vendor ? vendor : "N/A", product ? product : "N/A");
        }
#endif
    }

    return 0;   /* No match */
}


/**
 * @brief   Scan udev tty devices and return the path of the target USB serial port.
 *
 * @details Enumerates all devices in the @c tty subsystem via udev and calls
 *          @c USB_target_device() on each to identify the first device matching
 *          @c TARGET_VENDOR and @c TARGET_PRODUCT. Returns a heap-allocated
 *          copy of the device node path (e.g., @c "/dev/ttyUSB0").
 *
 * @note    The caller is responsible for freeing the returned string with @c free().
 *          This function is @c static — for internal use only.
 *
 * @warning Returns @c NULL if no matching device is found or if udev
 *          initialisation fails. Caller must check the return value.
 *
 * @return  Heap-allocated string containing the device node path on success.
 * @return  @c NULL if no matching device is found or on allocation failure.
 */
static char *find_target_usb_serial(void) {

    /* ── Create Temporary udev Context ─────────────────────────────────────
     * A local context is used here — separate from the global udev_ctx used
     * for monitoring — to perform a one-shot device scan.
     * ────────────────────────────────────────────────────────────────────── */
    struct udev *udev = udev_new();
    if (!udev) {
        fprintf(stderr, "[USB] Failed to initialise udev in find_target_usb_serial.\n");
        return NULL;
    }

    /* ── Create udev Enumerator ─────────────────────────────────────────────
     * The enumerator scans sysfs for devices matching the "tty" subsystem.
     * ────────────────────────────────────────────────────────────────────── */
    struct udev_enumerate *enumerate = udev_enumerate_new(udev);
    if (!enumerate) {
        fprintf(stderr, "[USB] Failed to create udev enumerate context.\n");
        udev_unref(udev);
        return NULL;
    }

    udev_enumerate_add_match_subsystem(enumerate, "tty");
    udev_enumerate_scan_devices(enumerate);

    struct udev_list_entry *devices      = udev_enumerate_get_list_entry(enumerate);
    struct udev_list_entry *dev_list_entry;
    char                   *target_devnode = NULL;

    /* ── Iterate All tty Devices ────────────────────────────────────────────
     * For each tty device, check if it matches the target vendor/product.
     * Stop at the first match and store a copy of the device node path.
     * ────────────────────────────────────────────────────────────────────── */
    udev_list_entry_foreach(dev_list_entry, devices) {
        const char *path = udev_list_entry_get_name(dev_list_entry);
        struct udev_device *dev = udev_device_new_from_syspath(udev, path);
        if (!dev) continue;

        if (USB_target_device(dev)) {
            const char *devnode = udev_device_get_devnode(dev);
            if (devnode) {
                target_devnode = strdup(devnode);   /* Caller must free() this */
#if USB_DEBUG_PRINT
                printf("[USB] Target USB serial found: %s\n", devnode);
#endif
                udev_device_unref(dev);
                break;   /* Stop at first match */
            }
        }
        udev_device_unref(dev);
    }

    /* ── Cleanup Enumerator and Local udev Context ──────────────────────── */
    udev_enumerate_unref(enumerate);
    udev_unref(udev);

#if USB_DEBUG_PRINT
    if (!target_devnode) {
        printf("[USB] No matching USB serial device found.\n");
    }
#endif

    return target_devnode;
}


/* ═══════════════════════════════════════════════════════════════════════════════
 * SERIAL PORT CONFIGURATION (STATIC — INTERNAL USE ONLY)
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Open and configure the USB serial port for raw 8N1 communication.
 *
 * @details Opens the device file with @c O_RDWR | O_NOCTTY | O_NDELAY, then
 *          applies the following termios settings:
 *          @code
 *          Mode    : raw (cfmakeraw)
 *          Data    : 8 data bits (CS8)
 *          Parity  : none (PARENB cleared)
 *          Stop    : 1 stop bit (CSTOPB cleared)
 *          Flow    : hardware disabled (CRTSCTS cleared)
 *          VMIN    : 1  — block until at least 1 byte received
 *          VTIME   : 1  — 100ms inter-character timeout
 *          @endcode
 *
 *          Baud rate is selected from @c BAUD_RATE_VALUE defined in the header.
 *          Supported rates: 9600, 19200, 38400, 57600, 115200, 2000000.
 *
 * @param[in] device  Path to the USB serial device (e.g., @c "/dev/ttyUSB0").
 *                    Must not be @c NULL.
 *
 * @note    On success, the global @c usb_fd is set to the open file descriptor.
 *          On any failure, @c usb_fd is closed and reset to @c -1.
 *
 * @return   @c  0  on success — port is open and configured.
 * @return   @c -1  on failure — invalid path, open error, or termios error.
 */
static int configure_serial_port(const char *device) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Reject NULL device path before any system call.
     * ────────────────────────────────────────────────────────────────────── */
    if (device == NULL) {
#if USB_DEBUG_PRINT
        fprintf(stderr, "[USB] NULL device path in configure_serial_port().\n");
#endif
        return -1;
    }

    /* ── Open Device File ───────────────────────────────────────────────────
     * O_RDWR    : open for read and write
     * O_NOCTTY  : do not assign as controlling terminal
     * O_NDELAY  : non-blocking open (do not wait for DCD signal)
     * ────────────────────────────────────────────────────────────────────── */
    usb_fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY);
    if (usb_fd < 0) {
        perror("[USB] Error opening USB device");
        return -1;
    }

    /* ── Retrieve Current Terminal Attributes ───────────────────────────────
     * tcgetattr() reads the current settings into the termios struct before
     * modifications are applied.
     * ────────────────────────────────────────────────────────────────────── */
    struct termios tty;
    memset(&tty, 0, sizeof(tty));

    if (tcgetattr(usb_fd, &tty) != 0) {
        perror("[USB] tcgetattr() failed");
        close(usb_fd);
        usb_fd = -1;
        return -1;
    }

    /* ── Apply Raw Mode ─────────────────────────────────────────────────────
     * cfmakeraw() disables all input/output processing, echo, and canonical
     * mode — suitable for binary serial protocols.
     * ────────────────────────────────────────────────────────────────────── */
    cfmakeraw(&tty);

    /* ── Select Baud Rate ───────────────────────────────────────────────────
     * Map the integer BAUD_RATE_VALUE to the corresponding POSIX speed_t
     * constant required by cfsetispeed() and cfsetospeed().
     * ────────────────────────────────────────────────────────────────────── */
    speed_t baud_rate;
    switch (BAUD_RATE_VALUE) {
        case 9600:    baud_rate = B9600;    break;
        case 19200:   baud_rate = B19200;   break;
        case 38400:   baud_rate = B38400;   break;
        case 57600:   baud_rate = B57600;   break;
        case 115200:  baud_rate = B115200;  break;
        case 2000000: baud_rate = B2000000; break;
        default:
#if USB_DEBUG_PRINT
            fprintf(stderr, "[USB] Unsupported baud rate: %d\n", BAUD_RATE_VALUE);
#endif
            close(usb_fd);
            usb_fd = -1;
            return -1;
    }

    printf("[USB] Baud rate: %d\n", BAUD_RATE_VALUE);

    /* ── Apply Baud Rate ────────────────────────────────────────────────────
     * Set both input (ispeed) and output (ospeed) to the same rate.
     * ────────────────────────────────────────────────────────────────────── */
    if (cfsetispeed(&tty, baud_rate) != 0 || cfsetospeed(&tty, baud_rate) != 0) {
        perror("[USB] Error setting baud rate");
        close(usb_fd);
        usb_fd = -1;
        return -1;
    }

    /* ── Configure 8N1 Frame Format ─────────────────────────────────────────
     * CLOCAL  : ignore modem control lines
     * CREAD   : enable receiver
     * CS8     : 8 data bits per character
     * ~PARENB : no parity bit
     * ~CSTOPB : 1 stop bit (clear = 1 stop, set = 2 stop)
     * ~CRTSCTS: disable hardware RTS/CTS flow control
     * ────────────────────────────────────────────────────────────────────── */
    tty.c_cflag |= (CLOCAL | CREAD);   /* Enable receiver, ignore modem lines */
    tty.c_cflag &= ~CSIZE;             /* Clear character size mask            */
    tty.c_cflag |= CS8;                /* 8 data bits                          */
    tty.c_cflag &= ~PARENB;            /* No parity                            */
    tty.c_cflag &= ~CSTOPB;            /* 1 stop bit                           */
    tty.c_cflag &= ~CRTSCTS;           /* Disable hardware flow control        */

    /* ── Disable All Processing Flags ──────────────────────────────────────
     * Disable line discipline processing, input translation, output processing.
     * Required for raw binary data — no CR/LF mapping, no echo, no signals.
     * ────────────────────────────────────────────────────────────────────── */
    tty.c_lflag = 0;   /* No canonical mode, no echo, no signals */
    tty.c_iflag = 0;   /* No input processing                    */
    tty.c_oflag = 0;   /* No output processing                   */

    /* ── Configure Blocking Behaviour ──────────────────────────────────────
     * VMIN  = 1 : block read() until at least 1 byte is available
     * VTIME = 1 : 100ms inter-character timeout (in deciseconds)
     * ────────────────────────────────────────────────────────────────────── */
    tty.c_cc[VMIN]  = 1;   /* Minimum bytes before read() returns */
    tty.c_cc[VTIME] = 1;   /* Read timeout: 100ms                  */

    /* ── Flush Input Buffer ─────────────────────────────────────────────────
     * Discard any stale bytes in the input buffer before applying new settings.
     * ────────────────────────────────────────────────────────────────────── */
    tcflush(usb_fd, TCIFLUSH);

    /* ── Apply Terminal Attributes ──────────────────────────────────────────
     * TCSANOW : apply changes immediately without waiting for pending I/O.
     * ────────────────────────────────────────────────────────────────────── */
    if (tcsetattr(usb_fd, TCSANOW, &tty) != 0) {
        perror("[USB] tcsetattr() failed");
        close(usb_fd);
        usb_fd = -1;
        return -1;
    }

    /* ── Set Blocking Mode ──────────────────────────────────────────────────
     * F_SETFL with flags=0 clears O_NDELAY/O_NONBLOCK — reverts to blocking.
     * ────────────────────────────────────────────────────────────────────── */
    if (fcntl(usb_fd, F_SETFL, 0) == -1) {
#if USB_DEBUG_PRINT
        fprintf(stderr, "[USB] Warning: failed to set blocking mode.\n");
#endif
    }

#if USB_DEBUG_PRINT
    printf("[USB] Serial port %s configured at %d baud (8N1).\n", device, BAUD_RATE_VALUE);
#endif

    return 0;
}


/* ═══════════════════════════════════════════════════════════════════════════════
 * USB RECEIVE THREAD (STATIC — INTERNAL USE ONLY)
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   USB receive thread — continuously reads frames and dispatches via callback.
 *
 * @details This thread runs while @c running is @c true. On each iteration it
 *          calls @c read() on @c usb_fd and handles three outcomes:
 *
 *          @code
 *          received_bytes > 0  →  dispatch to USB_callback()
 *          received_bytes == 0 →  no data yet, sleep 10ms and retry
 *          received_bytes <  0 →  read error / disconnect, close fd and exit
 *          @endcode
 *
 *          If @c usb_fd is not open (< 0), the thread sleeps for
 *          @c RECONNECT_DELAY_SEC before retrying.
 *
 * @param[in] arg  Unused thread argument (required by @c pthread_create signature).
 *
 * @note    This thread is @c static — created internally by @c usb_run().
 *          It must not be created directly by application code.
 *
 * @return  @c NULL when the thread exits (on error or when @c running = false).
 */
static void *USB_rx_thread(void *arg) {
    (void)arg;   /* Suppress unused parameter warning */

    unsigned char usb_rx_buffer[256];   ///< Raw receive buffer for USB frame data
    int           received_bytes;       ///< Byte count returned by read()

    /* ── Continuous Read Loop ───────────────────────────────────────────────
     * Runs while the global running flag is true.
     * Exits on read error or device disconnection.
     * ────────────────────────────────────────────────────────────────────── */
    while (running) {

        if (usb_fd >= 0) {

            received_bytes = read(usb_fd, usb_rx_buffer, sizeof(usb_rx_buffer));

            if (received_bytes > 0) {
                /* ── Data Received ───────────────────────────────────────────
                 * Forward the raw frame to the user-registered callback.
                 * ────────────────────────────────────────────────────────── */
#if USB_DEBUG_PRINT
                printf("[USB RX] Received %d bytes: ", received_bytes);
                for (int i = 0; i < received_bytes; ++i) {
                    printf("%02X ", usb_rx_buffer[i]);
                }
                printf("\n");
#endif
                if (USB_callback != NULL) {
                    USB_callback(usb_rx_buffer, received_bytes);
                }

            } else if (received_bytes == 0) {
                /* ── No Data ─────────────────────────────────────────────────
                 * Sleep briefly to avoid spinning on an idle port.
                 * ────────────────────────────────────────────────────────── */
                usleep(10000);   /* 10ms yield */

            } else {
                /* ── Read Error / Disconnection ──────────────────────────────
                 * Negative return indicates device error or disconnect.
                 * Close the fd and exit — usb_run() will handle reconnection.
                 * ────────────────────────────────────────────────────────── */
                perror("[USB RX] read() error — device disconnected");
                close(usb_fd);
                usb_fd = -1;
#if USB_DEBUG_PRINT
                fprintf(stderr, "[USB RX] Stopping RX thread after disconnect.\n");
#endif
                break;
            }

        } else {
            /* ── Device Not Open ─────────────────────────────────────────────
             * Wait before retrying — usb_run() is responsible for reopening.
             * ────────────────────────────────────────────────────────────── */
            sleep(RECONNECT_DELAY_SEC);
        }
    }

    return NULL;
}


/* ═══════════════════════════════════════════════════════════════════════════════
 * PUBLIC API IMPLEMENTATIONS
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Transmit data over the USB serial interface in a thread-safe manner.
 *
 * @details Acquires the send mutex, then writes the full buffer to @c usb_fd
 *          in a loop to handle partial @c write() returns. Releases the mutex
 *          after all bytes are sent or on error.
 *
 * @param[in] data    Pointer to the data buffer to transmit. Must not be @c NULL.
 * @param[in] length  Number of bytes to send. Must be > 0.
 *
 * @note    Thread-safe — protected by @c usb_send_mutex.
 *          Handles partial writes automatically via the inner while loop.
 *
 * @warning Returns @c -1 immediately if @c usb_fd < 0 (device not open).
 *          The mutex is always released before returning, even on error.
 *
 * @return  Total number of bytes written on success.
 * @return  @c -1 on invalid arguments, device not open, or write error.
 */
int usb_send_data(const unsigned char *data, int length) {

    /* ── Validate Device State ──────────────────────────────────────────────
     * Reject send if USB device is not currently open.
     * ────────────────────────────────────────────────────────────────────── */
    if (usb_fd < 0) {
        fprintf(stderr, "[USB SEND] Device not open (usb_fd = %d)\n", usb_fd);
        return -1;
    }

    /* ── Validate Input Arguments ───────────────────────────────────────────
     * Reject NULL buffer or zero/negative length.
     * ────────────────────────────────────────────────────────────────────── */
    if (data == NULL || length <= 0) {
        fprintf(stderr, "[USB SEND] Invalid data=%p or length=%d\n",
                (void *)data, length);
        return -1;
    }

    pthread_mutex_lock(&usb_send_mutex);   /* Acquire send mutex */

    int total_written = 0;

    /* ── Write Loop ─────────────────────────────────────────────────────────
     * write() may send fewer bytes than requested on a single call.
     * Loop until all bytes are transmitted or an error occurs.
     * ────────────────────────────────────────────────────────────────────── */
    while (total_written < length) {
        int written = write(usb_fd, data + total_written, length - total_written);
        if (written < 0) {
            perror("[USB SEND] write() error");
            pthread_mutex_unlock(&usb_send_mutex);
            return -1;
        }
        total_written += written;
    }

    pthread_mutex_unlock(&usb_send_mutex);   /* Release send mutex */

#if USB_DEBUG_PRINT
    printf("[USB SEND] Sent %d bytes: ", total_written);
    for (int i = 0; i < total_written; i++) {
        printf("%02X ", data[i]);
    }
    printf("\n");
#endif

    return total_written;
}


/**
 * @brief   Initialise USB monitoring infrastructure using libudev.
 *
 * @details Creates a udev context and monitor that listens for kernel-level
 *          events on the @c tty subsystem. This allows the driver to detect
 *          USB serial device plug and unplug events at runtime.
 *
 *          Initialisation sequence:
 *          @code
 *          1. Release any existing udev context/monitor
 *          2. Create new udev context       (udev_new)
 *          3. Create udev monitor           (udev_monitor_new_from_netlink)
 *          4. Add tty subsystem filter      (udev_monitor_filter_add_match_subsystem_devtype)
 *          5. Enable event receiving        (udev_monitor_enable_receiving)
 *          @endcode
 *
 * @note    Must be called once before @c usb_run(). Repeated calls safely
 *          release and reinitialise all udev resources.
 *
 * @return  @c true  on successful initialisation — monitoring is active.
 * @return  @c false on any failure — all udev resources are released on error.
 */
bool usb_init(void) {

    printf("[USB INIT] Initialising USB monitoring...\n");

    /* ── Release Existing Resources ─────────────────────────────────────────
     * If usb_init() is called again (e.g., after error recovery), release
     * any previously allocated udev objects before reinitialising.
     * ────────────────────────────────────────────────────────────────────── */
    if (udev_ctx) {
        udev_unref(udev_ctx);
        udev_ctx = NULL;
    }
    if (udev_monitor) {
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
    }

    /* ── Create udev Context ────────────────────────────────────────────────
     * udev_new() initialises the library context used for all udev operations.
     * ────────────────────────────────────────────────────────────────────── */
    udev_ctx = udev_new();
    if (!udev_ctx) {
        fprintf(stderr, "[USB INIT] Failed to initialise udev context.\n");
        return false;
    }

    /* ── Create udev Monitor ────────────────────────────────────────────────
     * "udev" source receives events after udev rules have been processed
     * (as opposed to "kernel" for raw kernel events).
     * ────────────────────────────────────────────────────────────────────── */
    udev_monitor = udev_monitor_new_from_netlink(udev_ctx, "udev");
    if (!udev_monitor) {
        fprintf(stderr, "[USB INIT] Failed to create udev monitor.\n");
        udev_unref(udev_ctx);
        udev_ctx = NULL;
        return false;
    }

    /* ── Add tty Subsystem Filter ───────────────────────────────────────────
     * Filter events to the "tty" subsystem only (USB serial ports).
     * Reduces noise from unrelated device events (USB hubs, HID, etc.).
     * ────────────────────────────────────────────────────────────────────── */
    if (udev_monitor_filter_add_match_subsystem_devtype(udev_monitor, "tty", NULL) < 0) {
        fprintf(stderr, "[USB INIT] Failed to add tty monitor filter.\n");
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
        udev_unref(udev_ctx);
        udev_ctx = NULL;
        return false;
    }

    /* ── Enable Event Reception ─────────────────────────────────────────────
     * Activates the monitor — must be called before reading events via
     * udev_monitor_receive_device().
     * ────────────────────────────────────────────────────────────────────── */
    if (udev_monitor_enable_receiving(udev_monitor) < 0) {
        fprintf(stderr, "[USB INIT] Failed to enable udev event reception.\n");
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
        udev_unref(udev_ctx);
        udev_ctx = NULL;
        return false;
    }

#if USB_DEBUG_PRINT
    printf("[USB INIT] USB monitoring initialised successfully.\n");
#endif

    return true;
}


/**
 * @brief   Release all USB resources and stop the RX thread.
 *
 * @details Performs an ordered teardown of all USB driver resources:
 *
 *          @code
 *          1. Set running = false          (signals RX thread to exit)
 *          2. Release udev monitor
 *          3. Release udev context
 *          4. Close USB file descriptor
 *          5. Join RX thread (if not calling from RX thread itself)
 *          @endcode
 *
 * @note    Safe to call from the main thread or signal handler.
 *          Does not call itself recursively — checks @c pthread_self()
 *          before joining @c rx_thread_id.
 *
 * @return  void
 */
void usb_cleanup(void) {

    printf("[USB CLEANUP] Releasing USB resources...\n");

    /* ── Signal RX Thread to Stop ───────────────────────────────────────────
     * The RX thread checks running on each iteration.
     * Setting false causes it to exit its loop on the next cycle.
     * ────────────────────────────────────────────────────────────────────── */
    running = false;

    /* ── Release udev Monitor ───────────────────────────────────────────────
     * Must be released before the udev context.
     * ────────────────────────────────────────────────────────────────────── */
    if (udev_monitor) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Releasing udev monitor.\n");
#endif
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
    }

    /* ── Release udev Context ───────────────────────────────────────────────
     * Frees the library context allocated by udev_new().
     * ────────────────────────────────────────────────────────────────────── */
    if (udev_ctx) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Releasing udev context.\n");
#endif
        udev_unref(udev_ctx);
        udev_ctx = NULL;
    }

    /* ── Close USB File Descriptor ──────────────────────────────────────────
     * Close the serial port if it is still open.
     * ────────────────────────────────────────────────────────────────────── */
    if (usb_fd >= 0) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Closing USB fd: %d\n", usb_fd);
#endif
        close(usb_fd);
        usb_fd = -1;
    }

    /* ── Join RX Thread ─────────────────────────────────────────────────────
     * Wait for the RX thread to fully terminate.
     * pthread_self() check prevents deadlock if cleanup is called from
     * within the RX thread itself.
     * ────────────────────────────────────────────────────────────────────── */
    if (pthread_self() != rx_thread_id && rx_thread_id != 0) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Waiting for RX thread to terminate...\n");
#endif
        pthread_join(rx_thread_id, NULL);
        rx_thread_id = 0;
    }

#if USB_DEBUG_PRINT
    printf("[USB CLEANUP] USB cleanup complete.\n");
#endif
}


/**
 * @brief   Main USB communication loop — manages connection, reception, and udev events.
 *
 * @details Runs the primary USB event loop. Performs the following on each iteration:
 *
 *          @code
 *          1. If usb_fd < 0  → attempt configure_serial_port()
 *                             → on success: create RX thread
 *                             → on failure: sleep RECONNECT_DELAY_SEC, retry
 *
 *          2. If usb_fd >= 0 → verify port still alive via tcgetattr()
 *                             → on failure: close fd, cancel RX thread, retry
 *
 *          3. Poll udev monitor fd for plug/unplug events
 *             → log event action and device node if received
 *
 *          4. Sleep 1 second between iterations to reduce CPU load
 *          @endcode
 *
 *          On exit, the RX thread is cancelled and joined, and @c usb_fd
 *          is closed if still open.
 *
 * @param[in] device_path  Path to the USB serial device to monitor.
 *                         Must not be @c NULL (e.g., @c "/dev/ttyUSB0").
 *
 * @note    This function blocks indefinitely while @c running is @c true.
 *          Call @c usb_cleanup() from another thread or signal handler to exit.
 *
 * @warning @c usb_init() must be called successfully before calling @c usb_run().
 *          Calling without a valid @c udev_monitor will cause undefined behaviour.
 *
 * @return  void
 */
void usb_run(const char *device_path) {

    int rx_thread_created = 0;                            ///< Tracks whether RX thread is active
    int monitor_fd        = udev_monitor_get_fd(udev_monitor); ///< udev monitor file descriptor

    /* ── Main USB Event Loop ────────────────────────────────────────────────
     * Runs while global running flag is true.
     * ────────────────────────────────────────────────────────────────────── */
    while (running) {

        /* ── Step 1: Open Serial Port if Not Connected ───────────────────────
         * Attempt to configure and open the USB device if fd is invalid.
         * ────────────────────────────────────────────────────────────────── */
        if (usb_fd < 0) {
#if USB_DEBUG_PRINT
            printf("[USB RUN] Attempting to open: %s\n", device_path);
#endif
            if (configure_serial_port(device_path) == 0) {
#if USB_DEBUG_PRINT
                printf("[USB RUN] Serial port opened: %s\n", device_path);
#endif
                /* ── Start RX Thread ─────────────────────────────────────────
                 * Create the receive thread only if not already running.
                 * ────────────────────────────────────────────────────────── */
                if (!rx_thread_created) {
                    if (pthread_create(&rx_thread_id, NULL, USB_rx_thread, NULL) == 0) {
#if USB_DEBUG_PRINT
                        printf("[USB RUN] RX thread started.\n");
#endif
                        rx_thread_created = 1;
                    } else {
                        perror("[USB RUN] pthread_create() failed for RX thread");
                        close(usb_fd);
                        usb_fd = -1;
                        sleep(RECONNECT_DELAY_SEC);
                        continue;
                    }
                }
            } else {
                /* ── Open Failed — Retry ─────────────────────────────────────
                 * Clean up any partially opened fd and wait before retrying.
                 * ────────────────────────────────────────────────────────── */
                if (usb_fd >= 0) {
                    close(usb_fd);
                    usb_fd = -1;
                }
                perror("[USB RUN] configure_serial_port() failed");
#if USB_DEBUG_PRINT
                fprintf(stderr, "[USB RUN] Retrying in %d second(s)...\n", RECONNECT_DELAY_SEC);
#endif
                sleep(RECONNECT_DELAY_SEC);
                continue;
            }
        }

        /* ── Step 2: Verify Port is Still Active ─────────────────────────────
         * tcgetattr() returns non-zero if the device has been disconnected.
         * ────────────────────────────────────────────────────────────────── */
        if (usb_fd >= 0) {
            struct termios test_attr;
            if (tcgetattr(usb_fd, &test_attr) != 0) {
                perror("[USB RUN] USB port disconnected");
                close(usb_fd);
                usb_fd = -1;

                /* Cancel and join RX thread on disconnect */
                if (rx_thread_created) {
                    pthread_cancel(rx_thread_id);
                    pthread_join(rx_thread_id, NULL);
                    rx_thread_created = 0;
#if USB_DEBUG_PRINT
                    printf("[USB RUN] RX thread terminated after disconnect.\n");
#endif
                }
#if USB_DEBUG_PRINT
                fprintf(stderr, "[USB RUN] Waiting for device to reconnect...\n");
#endif
                sleep(RECONNECT_DELAY_SEC);
                continue;
            }
        }

        /* ── Step 3: Poll udev Monitor for Plug/Unplug Events ───────────────
         * Use poll() with UDEV_MONITOR_TIMEOUT to check for device events.
         * Log the action (add/remove) and device node if an event is received.
         * ────────────────────────────────────────────────────────────────── */
        struct pollfd fds[1];
        fds[0].fd     = monitor_fd;
        fds[0].events = POLLIN;

        int poll_ret = poll(fds, 1, UDEV_MONITOR_TIMEOUT);

        if (poll_ret > 0 && (fds[0].revents & POLLIN)) {
            struct udev_device *dev = udev_monitor_receive_device(udev_monitor);
            if (dev) {
                const char *action  = udev_device_get_action(dev);
                const char *devnode = udev_device_get_devnode(dev);
#if USB_DEBUG_PRINT
                if (action && devnode) {
                    printf("[USB RUN] udev event: %s on %s\n", action, devnode);
                }
#endif
                udev_device_unref(dev);
            }
        } else if (poll_ret < 0) {
            perror("[USB RUN] poll() error on udev monitor fd");
            break;
        }

        sleep(1);   /* Brief pause between loop iterations to reduce CPU load */
    }

    /* ── Loop Exit: Cleanup RX Thread and USB fd ────────────────────────────
     * Cancel and join the RX thread if still active.
     * Close the USB device if still open.
     * ────────────────────────────────────────────────────────────────────── */
    if (rx_thread_created) {
        pthread_cancel(rx_thread_id);
        pthread_join(rx_thread_id, NULL);
        rx_thread_created = 0;
    }

    if (usb_fd >= 0) {
        close(usb_fd);
        usb_fd = -1;
    }

#if USB_DEBUG_PRINT
    printf("[USB RUN] USB run loop exited.\n");
#endif
}