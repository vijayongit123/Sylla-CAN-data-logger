/**
 * @file    USB_Datalogger_Main.c
 * @brief   Application entry point for USB CAN data logging with UDP control.
 *
 * @details This file integrates the USB and UDP subsystems to form the main
 *          runtime loop of the CAN data logger. It performs the following:
 *
 *          - Initialises the USB interface to receive CAN frames from hardware.
 *          - Initialises a UDP socket to receive remote START/STOP commands
 *            from the ground station GUI.
 *          - Spawns a dedicated UDP receiver thread for non-blocking command
 *            handling.
 *          - Continuously monitors the USB device for incoming CAN frames and
 *            restarts automatically on disconnection.
 *
 *          Board role is selected at compile time via preprocessor macros:
 *          @code
 *          #define CAN_A   →  Battery board  (/dev/ttyBATTERY)
 *          #define CAN_B   →  Motor board    (/dev/ttyMOTOR)
 *          @endcode
 *
 *          UDP Command Protocol:
 *          @code
 *          Received "1"  →  g_udp_cmd = 1  →  Start logging
 *          Received "0"  →  g_udp_cmd = 0  →  Stop  logging
 *          @endcode
 *
 * @author  Vijay Singh — Embedded Systems Team
 * @version 1.0
 */

/* ── Standard C Library Headers ─────────────────────────────────────────────── */
#include <stdio.h>      ///< Standard I/O          : printf, fprintf
#include <stdlib.h>     ///< General utilities      : strtoul, malloc, free
#include <string.h>     ///< String utilities       : memcpy, memset
#include <stdbool.h>    ///< Boolean type support   : true, false
#include <stddef.h>     ///< Standard definitions   : NULL, size_t
#include <stdint.h>     ///< Fixed-width integers   : uint8_t, uint32_t
#include <arpa/inet.h>   /* inet_ntoa(), inet_pton() */

/* ── System / POSIX Headers ─────────────────────────────────────────────────── */
#include <pthread.h>    ///< POSIX threads          : pthread_create, pthread_t
#include <unistd.h>     ///< POSIX system calls     : sleep, close

/* ── Project-Specific Headers ───────────────────────────────────────────────── */
#include "USB_Driver.h"        ///< USB interface layer   : usb_init, usb_run, usb_cleanup
#include "USB_Datalogger.h"    ///< CAN data logger       : MC_JSON_datalog, BMS_JSON_datalog
#include "USB_FrameParser.h"   ///< USB frame parser      : parse_motor_usb_can_frames
#include "udp_common.h"        ///< UDP socket utilities  : init_udp_socket, wait_for_udp

/* ═══════════════════════════════════════════════════════════════════════════════
 * NETWORK CONFIGURATION
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @def   SELF_PORT
 * @brief UDP port on which this device listens for incoming commands.
 *
 * The ground station GUI sends START ("1") and STOP ("0") commands to this port.
 */
#define SELF_PORT   8881

/* ═══════════════════════════════════════════════════════════════════════════════
 * BOARD ROLE CONFIGURATION
 * Select one of the following at compile time to define the hardware role.
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @def   CAN_A
 * @brief Selects the Battery Management System (BMS) board role.
 *        USB device path will be set to @c /dev/ttyBATTERY.
 *
 * @def   CAN_B
 * @brief Selects the Motor Controller (MC) board role.
 *        USB device path will be set to @c /dev/ttyMOTOR.
 */
#define CAN_A            /* Active board role: BMS / Battery board */

#ifdef CAN_A
    #define USB_DEVICE_PATH   "/dev/ttyBATTERY"   ///< USB path for BMS / Battery board

#elif defined(CAN_B)
    #define USB_DEVICE_PATH   "/dev/ttyMOTOR"     ///< USB path for Motor Controller board

#else
    #error "No valid board role defined. Define CAN_A or CAN_B before compiling."
#endif

/**
 * @def   RETRY_DELAY
 * @brief Delay in seconds before retrying USB initialisation after a failure.
 *
 * Prevents rapid retry loops on persistent USB errors or device disconnections.
 */
#define RETRY_DELAY   2   ///< USB reconnect retry delay (seconds)

/* ═══════════════════════════════════════════════════════════════════════════════
 * GLOBAL VARIABLES
 * ═══════════════════════════════════════════════════════════════════════════════ */

int          udp_sockfd = -1;   ///< Global UDP socket file descriptor (-1 = uninitialised)
unsigned int g_udp_cmd  =  0;   ///< Global UDP command: 1 = start logging, 0 = stop logging
char TARGET_IP[INET_ADDRSTRLEN];   /* e.g. "192.168.0.100\0" — 16 bytes max for IPv4 */


/**
 * @brief   Handle an incoming UDP message and store the command value globally.
 *
 * @details Receives a null-terminated string over UDP, converts it to an
 *          unsigned integer, and stores the result in @c g_udp_cmd.
 *          This value is subsequently read by the data logging functions to
 *          START or STOP file logging.
 *
 *          Expected values:
 *          @code
 *          "1"  →  g_udp_cmd = 1  →  Start logging
 *          "0"  →  g_udp_cmd = 0  →  Stop  logging
 *          @endcode
 *
 * @param[in] data    Pointer to the null-terminated command string received via UDP.
 *                    Must not be @c NULL.
 * @param[in] sender  Pointer to the sender's @c sockaddr_in address structure.
 *                    Must not be @c NULL.
 *
 * @note  Uses @c strtoul() with base 0 to support both decimal and hex input.
 *
 * @return void
 */
void handle_udp_json_message(const char *data, struct sockaddr_in *sender) {

    if (!data || !sender) {
        fprintf(stderr, "[ERROR] NULL argument in handle_udp_json_message()\n");
        return;
    }

    /* ── Save sender IP into TARGET_IP ─────────────────────────────────────
     * inet_ntop() is preferred over inet_ntoa() — it is thread-safe and
     * writes directly into TARGET_IP.
     * ────────────────────────────────────────────────────────────────────── */
    inet_ntop(AF_INET, &sender->sin_addr, TARGET_IP, sizeof(TARGET_IP));

    printf("[JSON] Received from IP   : %s\n", TARGET_IP);
    printf("[JSON] Received from Port : %d\n", ntohs(sender->sin_port));
    printf("[JSON] Data               : %s\n", data);

    g_udp_cmd = (unsigned int)strtoul(data, NULL, 0);

    printf("[INFO] UDP Command stored: g_udp_cmd = %u\n", g_udp_cmd);
}


/**
 * @brief   UDP listener thread — continuously receives and dispatches UDP packets.
 *
 * @details This thread runs indefinitely, blocking on @c wait_for_udp() until
 *          a UDP packet arrives. Each received packet is passed to
 *          @c handle_udp_json_message() for parsing and global state update.
 *
 *          Thread lifecycle:
 *          @code
 *          pthread_create() → loop: wait_for_udp() → handle_udp_json_message() → repeat
 *          @endcode
 *
 * @param[in] arg  Pointer to the UDP socket file descriptor (@c int*),
 *                 cast from @c void* as required by @c pthread_create().
 *
 * @note    This thread runs as a daemon — it will be terminated automatically
 *          when the main process exits.
 *
 * @return  @c NULL (thread runs indefinitely and never returns normally).
 */
void *udp_receiver_thread(void *arg) {

    int sockfd = *(int *)arg;   ///< Dereference socket fd from void* argument

#if USB_DEBUG_PRINT
    printf("[UDP THREAD] Started. Listening for commands on socket %d...\n", sockfd);
#endif

    /* ── Infinite Receive Loop ──────────────────────────────────────────────
     * Block on wait_for_udp() — resumes only when a UDP packet arrives.
     * The callback (handle_udp_json_message) is invoked inside wait_for_udp().
     * ────────────────────────────────────────────────────────────────────── */
    while (true) {
        wait_for_udp(sockfd, handle_udp_json_message);
#if USB_DEBUG_PRINT
        printf("[UDP THREAD] Packet received and dispatched to callback.\n");
#endif
    }

    return NULL;   /* Unreachable — satisfies compiler return requirement */
}


/**
 * @brief   Application entry point — initialises all subsystems and runs the main loop.
 *
 * @details Performs the following startup sequence:
 *
 *          1. Register USB data callback (@c parse_motor_usb_can_frames).
 *          2. Initialise the USB interface for the configured device path.
 *          3. Initialise the UDP socket on @c SELF_PORT.
 *          4. Spawn the UDP receiver thread.
 *          5. Enter the main loop: run USB listener, handle reconnections.
 *
 *          The main loop never exits under normal operation. On USB
 *          disconnection or error, @c usb_run() returns, resources are
 *          cleaned up, and the USB interface is restarted after @c RETRY_DELAY
 *          seconds.
 *
 * @note    The UDP thread runs concurrently with the USB main loop, allowing
 *          START/STOP commands to be processed independently of USB activity.
 *
 * @return  Always returns @c 0 (unreachable under normal operation).
 */
int main(void) {

    printf("[MAIN] Initialising CAN Logger — USB + UDP Application...\n");
    printf("[MAIN] Board role : %s\n", USB_DEVICE_PATH);
    printf("[MAIN] UDP listen port : %d\n", SELF_PORT);

    /* ── Step 1: Register USB Data Callback ─────────────────────────────────
     * Set the function to be called when a complete USB CAN frame is received.
     * ────────────────────────────────────────────────────────────────────── */
    set_usb_data_callback(parse_motor_usb_can_frames);

    /* ── Step 2: Initialise USB Interface ───────────────────────────────────
     * Prepare the USB driver for monitoring the configured device path.
     * Logs a warning on failure but continues — USB will be retried in the loop.
     * ────────────────────────────────────────────────────────────────────── */
    if (!usb_init()) {
        fprintf(stderr, "[ERROR] USB initialisation failed. Will retry in main loop.\n");
    } else {
#if USB_DEBUG_PRINT
        printf("[MAIN] USB initialised successfully on %s\n", USB_DEVICE_PATH);
#endif
    }

    /* ── Step 3: Initialise UDP Socket ──────────────────────────────────────
     * Open a UDP socket bound to SELF_PORT to receive remote commands.
     * ────────────────────────────────────────────────────────────────────── */
    udp_sockfd = init_udp_socket(SELF_PORT);

    /* ── Step 4: Spawn UDP Receiver Thread ──────────────────────────────────
     * Create a dedicated thread to continuously receive UDP commands without
     * blocking the USB main loop.
     * ────────────────────────────────────────────────────────────────────── */
    pthread_t udp_thread;

    if (udp_sockfd >= 0) {
        pthread_create(&udp_thread, NULL, udp_receiver_thread, &udp_sockfd);
#if USB_DEBUG_PRINT
        printf("[MAIN] UDP receiver thread started on port %d\n", SELF_PORT);
#endif
    } else {
        fprintf(stderr, "[ERROR] UDP socket initialisation failed on port %d\n", SELF_PORT);
    }

    /* ── Step 5: Main USB Loop ───────────────────────────────────────────────
     * Continuously run the USB listener. On disconnection or error,
     * usb_run() returns — clean up and retry after RETRY_DELAY seconds.
     * ────────────────────────────────────────────────────────────────────── */
    while (true) {
#if USB_DEBUG_PRINT
        printf("[MAIN] Starting USB listener on: %s\n", USB_DEVICE_PATH);
#endif
        usb_run(USB_DEVICE_PATH);    /* Blocks while USB device is connected  */
        usb_cleanup();               /* Release resources after disconnection */

#if USB_DEBUG_PRINT
        printf("[MAIN] USB disconnected. Retrying in %d second(s)...\n", RETRY_DELAY);
#endif
        sleep(RETRY_DELAY);          /* Wait before attempting reconnection   */
    }

    return 0;   /* Unreachable — satisfies compiler return requirement */
}