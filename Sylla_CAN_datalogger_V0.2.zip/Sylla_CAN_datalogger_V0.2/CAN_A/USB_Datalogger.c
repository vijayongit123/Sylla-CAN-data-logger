/**
 * @file    USB_Datalogger.c
 * @brief   Main application entry for USB communication and CAN data logging.
 *
 * @details This file integrates the following subsystems:
 *          - USB communication layer  (USB_Driver.h)
 *          - CAN data logging         (USB_Datalogger.h)
 *          - UDP socket operations    (udp_common.h)
 *
 *          It receives CAN/USB frame data and logs it to timestamped files
 *          on the Raspberry Pi, controlled remotely via UDP commands from
 *          a ground station laptop GUI.
 *
 * @note    UDP Command Protocol:
 *            "1"  →  Start logging CAN data
 *            "0"  →  Stop  logging CAN data
 *
 *          Network Configuration:
 *            Pi listens on  : udp_sockfd  (defined in udp_common.c)
 *            Pi replies to  : TARGET_IP : TARGET_PORT
 *
 * @author  Vijay Singh — Embedded Systems Team
 * @version 1.0
 */

/* ── Standard C Library Headers ─────────────────────────────────────────────── */
#include <stdio.h>      ///< Standard I/O          : printf, fprintf, fopen, fclose
#include <string.h>     ///< String utilities       : memcpy, memset, strcmp, strncpy
#include <stdlib.h>     ///< General utilities      : malloc, free, atoi, exit
#include <stdbool.h>    ///< Boolean type support   : true, false
#include <unistd.h>     ///< POSIX system calls     : read, write, close, sleep

/* ── System / POSIX Headers ─────────────────────────────────────────────────── */
#include <arpa/inet.h>  ///< Internet operations    : htons, htonl, inet_addr, inet_ntoa
#include <pthread.h>    ///< POSIX threads          : pthread_create, pthread_join, pthread_mutex
#include <sys/stat.h>   ///< File/directory status  : mkdir, stat, chmod
#include <sys/types.h>  ///< System type definitions: used by stat, pthread, socket APIs

/* ── Project-Specific Headers ───────────────────────────────────────────────── */
#include "USB_Driver.h"       ///< USB interface layer    : USB init, read, write, monitoring
#include "USB_Datalogger.h"   ///< CAN data logger        : frame parsing, file logging, JSON formatting
#include "udp_common.h"       ///< UDP socket utilities   : socket init, send_udp_json, wait_for_udp

/* ── Network Configuration ──────────────────────────────────────────────────── */
//#define TARGET_IP    "192.168.0.100"   ///< Laptop IP address  — UDP replies sent here
#define TARGET_PORT  9991             ///< Laptop UDP port    — GUI listens on this port

/* ── External Global Variables ──────────────────────────────────────────────── */
extern unsigned int g_udp_cmd;   ///< UDP command flag: 1 = start logging, 0 = stop logging
extern int          udp_sockfd;  ///< UDP socket file descriptor (created in udp_common.c)
extern char TARGET_IP[INET_ADDRSTRLEN]; 


/* ============================================================================
 * CONFIGURATION CONSTANTS
 * ============================================================================ */

/**
 * @def   DEBUG_LOGS
 * @brief Compile-time switch to enable or disable debug log output.
 *
 * @details
 *   - Set to @c 1 to enable detailed debug messages during development
 *     and troubleshooting.
 *   - Set to @c 0 to suppress all debug output in production builds.
 *
 * @note  Debug messages are written to @c stderr unless otherwise stated
 *        in the individual function implementation.
 *
 * Usage:
 * @code
 *   #if DEBUG_LOGS
 *       fprintf(stderr, "[DEBUG] Value = %d\n", val);
 *   #endif
 * @endcode
 */
#define DEBUG_LOGS 0


/**
 * @brief   Generate a formatted timestamp string with millisecond precision.
 *
 * @details Retrieves the current system wall-clock time via
 *          @c clock_gettime(CLOCK_REALTIME) and formats it into a
 *          human-readable string with millisecond accuracy.
 *
 *          Output format:
 *          @code
 *          YYYY-MM-DD HH:MM:SS.mmm
 *          @endcode
 *
 *          Example:
 *          @code
 *          2025-11-03 15:42:19.124
 *          @endcode
 *
 * @param[out] buffer  Pointer to the destination character array.
 *                     On success, contains the null-terminated timestamp string.
 *                     On failure, set to an empty string (@c "").
 * @param[in]  size    Size of @p buffer in bytes.
 *                     Must be at least @b 24 bytes to hold the full
 *                     timestamp string including the null terminator.
 *
 * @note
 *   - Uses @c clock_gettime(CLOCK_REALTIME) for sub-second precision.
 *   - Converts to local time using @c localtime().
 *   - Milliseconds derived from @c tv_nsec / 1,000,000.
 *   - On any error, @p buffer is set to @c "" and the function returns early.
 *
 * @warning Not thread-safe due to @c localtime() using a shared static buffer.
 *          Use @c localtime_r() for thread-safe operation.
 *
 * @return  void
 */
void get_timestamp(char *buffer, size_t size) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Ensure buffer is non-NULL and large enough for the full timestamp.
     * Minimum required: 23 characters + 1 null terminator = 24 bytes.
     * ────────────────────────────────────────────────────────────────────── */
    if (buffer == NULL || size < 24) {
#if DEBUG_LOGS
        fprintf(stderr, "[ERROR] Invalid buffer or insufficient size in get_timestamp().\n");
#endif
        return;
    }

    struct timespec ts;    ///< Holds raw time: tv_sec (seconds) + tv_nsec (nanoseconds)
    struct tm      *tm_info;   ///< Holds broken-down local time components after conversion

    /* ── Retrieve System Time ───────────────────────────────────────────────
     * clock_gettime(CLOCK_REALTIME) provides wall-clock time with
     * nanosecond resolution. Returns 0 on success, -1 on failure.
     * ────────────────────────────────────────────────────────────────────── */
    if (clock_gettime(CLOCK_REALTIME, &ts) != 0) {
#if DEBUG_LOGS
        perror("[ERROR] clock_gettime() failed in get_timestamp()");
#endif
        buffer[0] = '\0';
        return;
    }

    /* ── Convert to Local Time ──────────────────────────────────────────────
     * localtime() converts time_t (seconds since epoch) into a tm struct
     * representing local timezone. Returns NULL on failure.
     * ────────────────────────────────────────────────────────────────────── */
    tm_info = localtime(&ts.tv_sec);
    if (tm_info == NULL) {
#if DEBUG_LOGS
        perror("[ERROR] localtime() conversion failed in get_timestamp()");
#endif
        buffer[0] = '\0';
        return;
    }

    /* ── Format Timestamp String ────────────────────────────────────────────
     * Layout : YYYY-MM-DD HH:MM:SS.mmm
     * Fields :
     *   tm_year + 1900  → 4-digit year
     *   tm_mon  + 1     → month (1–12), tm_mon is 0-indexed
     *   tm_mday         → day of month (1–31)
     *   tm_hour         → hour (0–23)
     *   tm_min          → minute (0–59)
     *   tm_sec          → second (0–59)
     *   tv_nsec / 1e6   → milliseconds (0–999)
     * ────────────────────────────────────────────────────────────────────── */
    snprintf(buffer, size,
             "%04d-%02d-%02d %02d:%02d:%02d.%03ld",
             tm_info->tm_year + 1900,   /* Year  : offset from 1900        */
             tm_info->tm_mon  + 1,      /* Month : convert 0-based to 1-based */
             tm_info->tm_mday,          /* Day                              */
             tm_info->tm_hour,          /* Hour                             */
             tm_info->tm_min,           /* Minute                           */
             tm_info->tm_sec,           /* Second                           */
             ts.tv_nsec / 1000000L);    /* Nanoseconds → Milliseconds       */
}


/**
 * @brief   Send a UDP status notification to the ground station GUI.
 *
 * @details Constructs a single-character status message and transmits it
 *          to the target GUI application via UDP using @c send_udp_json().
 *          This is called internally whenever the logging state changes.
 *
 *          Status values:
 *          @code
 *          '1'  →  Logging has started  (sent after file is opened)
 *          '0'  →  Logging has stopped  (sent after file is closed)
 *          @endcode
 *
 * @param[in] status  Single character representing logging state.
 *                    @c '1' = started, @c '0' = stopped.
 *
 * @note    This function is @c static — only accessible within this
 *          translation unit. It is called exclusively by MC_JSON_datalog().
 *
 * @return  void
 */
static void MC_send_udp_status(char status) {

    /* ── Build Status Message ───────────────────────────────────────────────
     * Construct a 2-byte null-terminated string from the status character.
     * msg[0] = status character ('1' or '0')
     * msg[1] = null terminator  ('\0')
     * ────────────────────────────────────────────────────────────────────── */
    char msg[2];
    msg[0] = status;
    msg[1] = '\0';

    /* ── Transmit via UDP ───────────────────────────────────────────────────
     * send_udp_json() returns 0 on success, non-zero on failure.
     * Destination: TARGET_IP : TARGET_PORT (ground station GUI).
     * ────────────────────────────────────────────────────────────────────── */
    if (send_udp_json(udp_sockfd, msg, TARGET_IP, TARGET_PORT, NULL) == 0) {
        if (status == '1') printf("[INFO] UDP → Logging started sent to GUI\n");
        if (status == '0') printf("[INFO] UDP → Logging stopped sent to GUI\n");
    } else {
        fprintf(stderr, "[ERROR] Failed to send UDP status '%c' to %s:%d\n",
                status, TARGET_IP, TARGET_PORT);
    }
}


/**
 * @brief   Log incoming CAN JSON data to a timestamped file on the Pi.
 *
 * @details This function controls the CAN data logging lifecycle based on
 *          the global UDP command variable @c g_udp_cmd. It handles three
 *          responsibilities:
 *
 *          1. **STOP**  (@c g_udp_cmd == 0) — Closes the active log session
 *             and notifies the GUI via UDP.
 *
 *          2. **START** (@c g_udp_cmd == 1, first call) — Creates the output
 *             directory, generates a timestamped log filename, and notifies
 *             the GUI via UDP.
 *
 *          3. **WRITE** (@c g_udp_cmd == 1, subsequent calls) — Appends the
 *             incoming JSON string to the active log file.
 *
 *          Log file naming convention:
 *          @code
 *          Flight_Testdata/MC_YYYYMMDD_HHMMSS.txt
 *          Example: Flight_Testdata/MC_20251103_154219.txt
 *          @endcode
 *
 * @param[in] data  Pointer to a null-terminated JSON string to be logged.
 *                  Must not be @c NULL.
 *
 * @note
 *   - @c logging_active and @c filename are @c static — they persist across
 *     calls and maintain logging state for the lifetime of the program.
 *   - The output directory @c Flight_Testdata is created automatically if
 *     it does not already exist.
 *   - File is opened in append mode (@c "a") on every write call to ensure
 *     data integrity if the file handle is not held open.
 *
 * @warning Not thread-safe. If called from multiple threads concurrently,
 *          a mutex must be used to protect @c logging_active and @c filename.
 *
 * @return  void
 */
void MC_JSON_datalog(const char *data) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Reject NULL data pointer early to prevent undefined behaviour.
     * ────────────────────────────────────────────────────────────────────── */
    if (!data) {
#if DEBUG_LOGS
        fprintf(stderr, "[ERROR] NULL data pointer passed to MC_JSON_datalog().\n");
#endif
        return;
    }

    printf("[INFO] UDP Command Value = %u\n", g_udp_cmd);

    /* ── Static State Variables ─────────────────────────────────────────────
     * These persist across function calls to maintain logging session state.
     * logging_active : 1 = session open, 0 = session closed
     * filename       : full path of the currently active log file
     * ────────────────────────────────────────────────────────────────────── */
    static int  logging_active = 0;          ///< Logging session state flag
    static char filename[128]  = {0};        ///< Active log file path buffer

    /* ══════════════════════════════════════════════════════════════════════
     * STOP LOGGING  (g_udp_cmd == 0)
     * ══════════════════════════════════════════════════════════════════════
     * If a logging session is currently active, close it:
     *   1. Clear the logging state flag
     *   2. Reset the filename buffer
     *   3. Notify the GUI that logging has stopped
     * ════════════════════════════════════════════════════════════════════ */
    if (g_udp_cmd == 0) {
        if (logging_active) {
            logging_active = 0;       /* Mark session as closed             */
            filename[0]    = '\0';    /* Clear filename — forces new name on restart */
            MC_send_udp_status('0');  /* Notify GUI: logging stopped        */
        }
        return;   /* Nothing more to do when stopped */
    }

    /* ══════════════════════════════════════════════════════════════════════
     * START LOGGING  (g_udp_cmd == 1)
     * ══════════════════════════════════════════════════════════════════════ */
    if (g_udp_cmd == 1) {

        /* ── Session Initialisation (first call only) ───────────────────────
         * Runs only once per logging session when logging_active == 0.
         * ────────────────────────────────────────────────────────────────── */
        if (!logging_active) {

            /* Create output directory — silently succeeds if already exists */
            mkdir("Flight_Testdata", 0777);

            /* Generate unique timestamped filename for this session */
            time_t     now = time(NULL);       ///< Current epoch time
            struct tm *t   = localtime(&now);  ///< Broken-down local time

            snprintf(filename, sizeof(filename),
                     "Flight_Testdata/MC_%04d%02d%02d_%02d%02d%02d.txt",
                     t->tm_year + 1900,   /* Year  (offset from 1900)       */
                     t->tm_mon  + 1,      /* Month (convert 0-based to 1–12)*/
                     t->tm_mday,          /* Day of month                   */
                     t->tm_hour,          /* Hour   (0–23)                  */
                     t->tm_min,           /* Minute (0–59)                  */
                     t->tm_sec);          /* Second (0–59)                  */

            logging_active = 1;           /* Mark session as open           */
            MC_send_udp_status('1');      /* Notify GUI: logging started    */
            printf("[INFO] New log file created: %s\n", filename);
        }

        /* ── Write JSON Data to Log File ────────────────────────────────────
         * Open the file in append mode on each call.
         * Each JSON entry is written on a new line.
         * ────────────────────────────────────────────────────────────────── */
        FILE *file = fopen(filename, "a");
        if (file) {
            fprintf(file, "%s\n", data);   /* Append JSON string + newline  */
            fclose(file);                  /* Close immediately after write  */
        }
#if ENABLE_PRINT_LOG_USB
        else {
            fprintf(stderr, "[ERROR] Could not open log file: %s\n", filename);
        }
#endif
    }
}


/**
 * @brief   Log incoming BMS JSON data to a timestamped file on the Pi.
 *
 * @details This function controls the BMS data logging lifecycle based on
 *          the global UDP command variable @c g_udp_cmd. It handles three
 *          responsibilities:
 *
 *          1. **STOP**  (@c g_udp_cmd == 0) — Closes the active log session
 *             and notifies the GUI via UDP.
 *
 *          2. **START** (@c g_udp_cmd == 1, first call) — Creates the output
 *             directory, generates a timestamped log filename, and notifies
 *             the GUI via UDP.
 *
 *          3. **WRITE** (@c g_udp_cmd == 1, subsequent calls) — Appends the
 *             incoming JSON string to the active log file.
 *
 *          Log file naming convention:
 *          @code
 *          Flight_Testdata/BMS_YYYYMMDD_HHMMSS.txt
 *          Example: Flight_Testdata/BMS_20251103_154219.txt
 *          @endcode
 *
 * @param[in] data  Pointer to a null-terminated JSON string to be logged.
 *                  Must not be @c NULL.
 *
 * @note
 *   - @c logging_active and @c filename are @c static — they persist across
 *     calls and maintain logging state for the lifetime of the program.
 *   - The output directory @c Flight_Testdata is created automatically if
 *     it does not already exist.
 *   - File is opened in append mode (@c "a") on every write call to ensure
 *     data integrity.
 *
 * @warning Not thread-safe. If called from multiple threads concurrently,
 *          a mutex must be used to protect @c logging_active and @c filename.
 *
 * @return  void
 */
void BMS_JSON_datalog(const char *data) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Reject NULL data pointer early to prevent undefined behaviour.
     * ────────────────────────────────────────────────────────────────────── */
    if (!data) {
#if DEBUG_LOGS
        fprintf(stderr, "[ERROR] NULL data pointer passed to BMS_JSON_datalog().\n");
#endif
        return;
    }

    printf("[INFO] UDP Command Value = %u\n", g_udp_cmd);

    /* ── Static State Variables ─────────────────────────────────────────────
     * These persist across function calls to maintain logging session state.
     * logging_active : 1 = session open, 0 = session closed
     * filename       : full path of the currently active log file
     * ────────────────────────────────────────────────────────────────────── */
    static int  logging_active = 0;    ///< Logging session state flag
    static char filename[128]  = {0};  ///< Active log file path buffer

    /* ══════════════════════════════════════════════════════════════════════
     * STOP LOGGING  (g_udp_cmd == 0)
     * ══════════════════════════════════════════════════════════════════════
     * If a logging session is currently active, close it:
     *   1. Clear the logging state flag
     *   2. Reset the filename buffer
     *   3. Notify the GUI that logging has stopped
     * ════════════════════════════════════════════════════════════════════ */
    if (g_udp_cmd == 0) {
        if (logging_active) {
            logging_active = 0;       /* Mark session as closed                    */
            filename[0]    = '\0';    /* Clear filename — forces new name on restart*/
            MC_send_udp_status('0');  /* Notify GUI: logging stopped               */
            printf("[INFO] BMS logging stopped.\n");
        }
        return;   /* Nothing more to do when stopped */
    }

    /* ══════════════════════════════════════════════════════════════════════
     * START LOGGING  (g_udp_cmd == 1)
     * ══════════════════════════════════════════════════════════════════════ */
    if (g_udp_cmd == 1) {

        /* ── Session Initialisation (first call only) ───────────────────────
         * Runs only once per logging session when logging_active == 0.
         * ────────────────────────────────────────────────────────────────── */
        if (!logging_active) {

            /* Create output directory — silently succeeds if already exists */
            mkdir("Flight_Testdata", 0777);

            /* Generate unique timestamped filename for this session */
            time_t     now = time(NULL);       ///< Current epoch time
            struct tm *t   = localtime(&now);  ///< Broken-down local time

            snprintf(filename, sizeof(filename),
                     "Flight_Testdata/BMS_%04d%02d%02d_%02d%02d%02d.txt",
                     t->tm_year + 1900,   /* Year  (offset from 1900)        */
                     t->tm_mon  + 1,      /* Month (convert 0-based to 1–12) */
                     t->tm_mday,          /* Day of month                    */
                     t->tm_hour,          /* Hour   (0–23)                   */
                     t->tm_min,           /* Minute (0–59)                   */
                     t->tm_sec);          /* Second (0–59)                   */

            logging_active = 1;           /* Mark session as open            */
            MC_send_udp_status('1');      /* Notify GUI: logging started     */
            printf("[INFO] New BMS log file created: %s\n", filename);
        }

        /* ── Write JSON Data to Log File ────────────────────────────────────
         * Open the file in append mode on each call.
         * Each JSON entry is written on a new line.
         * ────────────────────────────────────────────────────────────────── */
        FILE *file = fopen(filename, "a");
        if (file) {
            fprintf(file, "%s\n", data);   /* Append JSON string + newline   */
            fclose(file);                  /* Close immediately after write   */
        }
#if ENABLE_PRINT_LOG_USB
        else {
            fprintf(stderr, "[ERROR] Could not open log file: %s\n", filename);
        }
#endif
    }
}

/**
 * @brief   Route incoming USB frame data to the appropriate subsystem handler.
 *
 * @details This function acts as the main dispatcher for raw USB frames received
 *          from connected flight hardware. It performs the following steps:
 *
 *          1. Validates the input buffer and length.
 *          2. Extracts the 4-byte device ID (little-endian).
 *          3. Identifies the source subsystem based on the ID range.
 *          4. Converts binary data to JSON via the respective handler.
 *          5. Validates the JSON output and logs it to a timestamped file.
 *
 *          Supported subsystems and their ID ranges:
 *          @code
 *          Motor Controller (MC) : 20–27, 40–47, 60–67, 80–87,
 *                                  100–107, 120–127, 140–147
 *          BMS Controller        : id < 20
 *          @endcode
 *
 * @param[in] data  Pointer to the raw USB data buffer.
 * @param[in] len   Length of the received USB data in bytes.
 *                  Must be at least 4 bytes to extract the device ID.
 *
 * @note
 *   - Frames with unrecognised offsets are skipped and not logged.
 *   - BMS and MC frames use separate JSON converters and log files.
 *
 * @warning Passing a @c NULL pointer or @p len < 4 will trigger an early
 *          return with an error message printed to @c stderr.
 *
 * @return  void
 */
void process_usb_data(uint8_t *data, int len) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Ensure the buffer is non-NULL and contains at least 4 bytes
     * required to extract the device ID.
     * ────────────────────────────────────────────────────────────────────── */
    if (data == NULL || len < 4) {
        fprintf(stderr, "[ERROR] Invalid USB data input: data=%p, len=%d\n",
                (void *)data, len);
        return;
    }

    char json[256] = {0};   ///< Output buffer for formatted JSON string

#if DEBUG_LOGS
    /* ── Debug: Dump Raw USB Frame ──────────────────────────────────────────
     * Print every byte of the received frame in hex for low-level debugging.
     * ────────────────────────────────────────────────────────────────────── */
    printf("\n[DEBUG] Received USB Data (len=%d): ", len);
    for (int i = 0; i < len; i++) {
        printf("0x%02X ", data[i]);
    }
    printf("\n");
#endif

    /* ── Extract 4-Byte Device ID (Little-Endian) ───────────────────────────
     * Reconstruct the 32-bit ID from 4 consecutive bytes.
     * Byte order: data[0]=LSB, data[3]=MSB
     * ────────────────────────────────────────────────────────────────────── */
    uint32_t id = ((uint32_t)data[3] << 24) |
                  ((uint32_t)data[2] << 16) |
                  ((uint32_t)data[1] <<  8) |
                  ((uint32_t)data[0]);

#if DEBUG_LOGS
    printf("[DEBUG] Parsed ID: %u (0x%08X)\n", id, id);
#endif

    /* ══════════════════════════════════════════════════════════════════════
     * MOTOR CONTROLLER (MC) FRAME PROCESSING
     * ══════════════════════════════════════════════════════════════════════
     * Route to MC handler if the ID falls within any known MC range.
     * Each range spans 8 values (one per offset 0x00–0x07).
     * ════════════════════════════════════════════════════════════════════ */
    if ((id >= 20  && id <= 27)  ||
        (id >= 40  && id <= 47)  ||
        (id >= 60  && id <= 67)  ||
        (id >= 80  && id <= 87)  ||
        (id >= 100 && id <= 107) ||
        (id >= 120 && id <= 127) ||
        (id >= 140 && id <= 147)) {

        /* Convert raw MC binary frame to JSON string */
        mc_JSONdata(data, json, sizeof(json));

#if DEBUG_LOGS
        printf("[DEBUG] MC JSON → %s\n", json);
#endif

        /* ── Skip Unknown Offset Frames ─────────────────────────────────────
         * If the converter returned an "Unknown Offset" error, discard the
         * frame — it cannot be reliably interpreted or logged.
         * ────────────────────────────────────────────────────────────────── */
        if (strstr(json, "\"error\": \"Unknown Offset") != NULL) {
            fprintf(stderr, "[WARN] Skipping unknown MC offset frame. ID: 0x%08X\n", id);
            return;
        }

        /* Log valid MC JSON frame to timestamped file */
        MC_JSON_datalog(json);
    }

    /* ══════════════════════════════════════════════════════════════════════
     * BATTERY MANAGEMENT SYSTEM (BMS) FRAME PROCESSING
     * ══════════════════════════════════════════════════════════════════════
     * Route to BMS handler if the ID is below the MC range (id < 20).
     * ════════════════════════════════════════════════════════════════════ */
    if (id < 20) {

        /* Convert raw BMS binary frame to JSON string */
        bms_JSONdata(data, json, sizeof(json));

        /* ── Skip Unknown ID Frames ──────────────────────────────────────────
         * If the converter returned an "Unknown Offset" error, discard the
         * frame — it cannot be reliably interpreted or logged.
         * ────────────────────────────────────────────────────────────────── */
        if (strstr(json, "\"error\": \"Unknown Offset") != NULL) {
            fprintf(stderr, "[WARN] Skipping unknown BMS offset frame. ID: 0x%08X\n", id);
            return;
        }

        /* Log valid BMS JSON frame to timestamped file */
        BMS_JSON_datalog(json);
    }
}


/**
 * @brief   Parse a raw Motor Controller (MC) USB frame into a JSON string.
 *
 * @details Interprets binary data received from the Motor Controller over USB.
 *          The message type is determined by the offset (lower digit of the
 *          4-byte little-endian ID), which maps to a specific data layout.
 *
 *          Offset-to-message mapping:
 *          @code
 *          Offset 0x00 → PWM, Flag
 *          Offset 0x01 → BTV, BCAvg, RPM
 *          Offset 0x02 → MT, ETM, ETC, EXST
 *          Offset 0x03 → OPWM, IPWM
 *          Offset 0x04 → ERR, WRN
 *          Offset 0x05 → NTC, ESCIS
 *          Offset 0x06 → BATTIV, EFV, PCM, PCA
 *          Offset 0x07 → BCM, IBUS
 *          default     → error: Unknown Offset
 *          @endcode
 *
 *          Example output (offset 0x01):
 *          @code
 *          {
 *            "timestamp": "2025-11-03 14:32:10.124",
 *            "id": "0x00000015",
 *            "length": 8,
 *            "fields": { "BTV": "0x0C8A", "BCAvg": "0x002F", "RPM": "0x0001A2B3" }
 *          }
 *          @endcode
 *
 * @param[in]  USBdata    Pointer to the raw USB frame buffer.
 *                        Must be at least 14 bytes for full field parsing.
 * @param[out] json       Destination buffer for the formatted JSON string.
 * @param[in]  json_size  Size of the @p json buffer in bytes.
 *                        Recommended minimum: 256 bytes.
 *
 * @note
 *   - ID is extracted as 4-byte little-endian from @c USBdata[0–3].
 *   - Offset is derived as @c id % 10 (lower decimal digit).
 *   - All field values are represented in hexadecimal format.
 *   - Unknown offsets produce a fallback error JSON.
 *
 * @warning Passing @c NULL for @p USBdata or @p json will write an error
 *          JSON to @p json if possible, then return immediately.
 *
 * @return  void
 */
void mc_JSONdata(uint8_t *USBdata, char *json, size_t json_size) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Validate all three parameters before any memory access.
     * ────────────────────────────────────────────────────────────────────── */
    if (USBdata == NULL || json == NULL || json_size == 0) {
        if (json && json_size > 0) {
            snprintf(json, json_size, "{ \"error\": \"Invalid arguments\" }");
        }
        return;
    }

    /* ── Timestamp ──────────────────────────────────────────────────────────
     * Retrieve current system time with millisecond precision.
     * ────────────────────────────────────────────────────────────────────── */
    char timestamp[64];
    get_timestamp(timestamp, sizeof(timestamp));

    /* ── Extract 4-Byte MC ID (Little-Endian) ───────────────────────────────
     * Reconstruct 32-bit ID: USBdata[0]=LSB, USBdata[3]=MSB.
     * ────────────────────────────────────────────────────────────────────── */
    uint32_t id = ((uint32_t)USBdata[3] << 24) |
                  ((uint32_t)USBdata[2] << 16) |
                  ((uint32_t)USBdata[1] <<  8) |
                  ((uint32_t)USBdata[0]);

    /* ── Determine Message Offset ───────────────────────────────────────────
     * The offset (lower decimal digit of the ID) identifies the message type.
     * ────────────────────────────────────────────────────────────────────── */
    unsigned int offset = id % 10;

    /* ── Route by Offset ────────────────────────────────────────────────────
     * Each case formats the JSON string according to the specific
     * data layout for that message offset.
     * ────────────────────────────────────────────────────────────────────── */
    switch (offset) {

        /* ── Offset 0x00: PWM Control Frame ─────────────────────────────────
         * Fields: PWM (4 bytes), Flag (1 byte)
         * ────────────────────────────────────────────────────────────────── */
        case 0x00:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 5,"
                " \"fields\": { \"PWM\": \"0x%08X\", \"Flag\": \"0x%02X\" } }",
                timestamp, id,
                (uint32_t)(USBdata[5]  | (USBdata[6]  << 8) |
                           (USBdata[7] << 16) | (USBdata[8] << 24)),  /* PWM  */
                (uint8_t)USBdata[9]);                                   /* Flag */
            break;

        /* ── Offset 0x01: Battery & RPM Frame ───────────────────────────────
         * Fields: BTV (2 bytes), BCAvg (2 bytes), RPM (4 bytes)
         * ────────────────────────────────────────────────────────────────── */
        case 0x01:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 8,"
                " \"fields\": { \"BTV\": \"0x%04X\", \"BCAvg\": \"0x%04X\","
                " \"RPM\": \"0x%08X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5] | (USBdata[6] << 8)),             /* BTV   */
                (uint16_t)(USBdata[7] | (USBdata[8] << 8)),             /* BCAvg */
                (uint32_t)(USBdata[9]  | (USBdata[10] << 8) |
                           (USBdata[11] << 16) | (USBdata[12] << 24))); /* RPM   */
            break;

        /* ── Offset 0x02: Temperature & Status Frame ────────────────────────
         * Fields: MT (2 bytes), ETM (2 bytes), ETC (2 bytes), EXST (2 bytes)
         * ────────────────────────────────────────────────────────────────── */
        case 0x02: {
            uint16_t mt   = (uint16_t)(USBdata[5]  | (USBdata[6]  << 8));  ///< Motor Temperature
            uint16_t etm  = (uint16_t)(USBdata[7]  | (USBdata[8]  << 8));  ///< Electrical Temperature Motor
            uint16_t etc  = (uint16_t)(USBdata[9]  | (USBdata[10] << 8));  ///< Electrical Temperature Controller
            uint16_t exst = (uint16_t)(USBdata[11] | (USBdata[12] << 8));  ///< Extended Status

            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 8,"
                " \"fields\": { \"MT\": \"0x%04X\", \"ETM\": \"0x%04X\","
                " \"ETC\": \"0x%04X\", \"EXST\": \"0x%04X\" } }",
                timestamp, id, mt, etm, etc, exst);
            break;
        }

        /* ── Offset 0x03: PWM Input/Output Frame ────────────────────────────
         * Fields: OPWM (2 bytes), IPWM (2 bytes)
         * ────────────────────────────────────────────────────────────────── */
        case 0x03:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 4,"
                " \"fields\": { \"OPWM\": \"0x%04X\", \"IPWM\": \"0x%04X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5] | (USBdata[6] << 8)),   /* Output PWM */
                (uint16_t)(USBdata[7] | (USBdata[8] << 8)));  /* Input PWM  */
            break;

        /* ── Offset 0x04: Error & Warning Frame ─────────────────────────────
         * Fields: ERR (4 bytes), WRN (4 bytes)
         * ────────────────────────────────────────────────────────────────── */
        case 0x04:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 8,"
                " \"fields\": { \"ERR\": \"0x%08X\", \"WRN\": \"0x%08X\" } }",
                timestamp, id,
                (uint32_t)(USBdata[5] << 24 | USBdata[6] << 16 |
                           USBdata[7] <<  8 | USBdata[8]),          /* Error code   */
                (uint32_t)(USBdata[9] << 24 | USBdata[10] << 16 |
                           USBdata[11] << 8 | USBdata[12]));        /* Warning code */
            break;

        /* ── Offset 0x05: Temperature Sensor & Current Frame ────────────────
         * Fields: NTC (4 bytes), ESCIS (2 bytes)
         * ────────────────────────────────────────────────────────────────── */
        case 0x05:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 6,"
                " \"fields\": { \"NTC\": \"0x%08X\", \"ESCIS\": \"0x%04X\" } }",
                timestamp, id,
                (uint32_t)(USBdata[5] << 24 | USBdata[6] << 16 |
                           USBdata[7] <<  8 | USBdata[8]),          /* NTC sensor   */
                (uint16_t)(USBdata[9] | (USBdata[10] << 8)));       /* ESC I-sense  */
            break;

        /* ── Offset 0x06: Voltage & Power Frame ─────────────────────────────
         * Fields: BATTIV (2 bytes), EFV (2 bytes), PCM (2 bytes), PCA (2 bytes)
         * ────────────────────────────────────────────────────────────────── */
        case 0x06:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 8,"
                " \"fields\": { \"BATTIV\": \"0x%04X\", \"EFV\": \"0x%04X\","
                " \"PCM\": \"0x%04X\", \"PCA\": \"0x%04X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5]  | (USBdata[6]  << 8)),   /* Battery Inst. Voltage  */
                (uint16_t)(USBdata[7]  | (USBdata[8]  << 8)),   /* Electrical Field Volt. */
                (uint16_t)(USBdata[9]  | (USBdata[10] << 8)),   /* Power Command Motor    */
                (uint16_t)(USBdata[11] | (USBdata[12] << 8)));  /* Power Command Actual   */
            break;

        /* ── Offset 0x07: Bus Current Frame ─────────────────────────────────
         * Fields: BCM (2 bytes), IBUS (1 byte)
         * ────────────────────────────────────────────────────────────────── */
        case 0x07:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"length\": 3,"
                " \"fields\": { \"BCM\": \"0x%04X\", \"IBUS\": \"0x%02X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5] | (USBdata[6] << 8)),  /* Bus Current Motor */
                USBdata[7]);                                   /* Input Bus Current */
            break;

        /* ── Default: Unknown Offset ─────────────────────────────────────────
         * Frame offset not recognised — produce a descriptive error JSON.
         * Caller should discard this frame and not log it.
         * ────────────────────────────────────────────────────────────────── */
        default:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%08X\", \"type\": \"MC\","
                " \"error\": \"Unknown Offset 0x%02X\" }",
                timestamp, id, offset);
            break;
    }
}


/**
 * @brief   Parse a raw Battery Management System (BMS) USB frame into a JSON string.
 *
 * @details Interprets binary data received from the BMS over USB.
 *          The message type is determined by the full 4-byte little-endian ID.
 *          Each ID maps to a specific BMS parameter group.
 *
 *          ID-to-message mapping:
 *          @code
 *          0x00F → RLY, MCELL, PCELLS, ROLLCNT, FSTATUS, PSOC
 *          0x00E → PINSTVOLT, PCUR, PSOC, AVGTEMP, HITEMP
 *          0x00D → PRES, PDOD, PSOH, PSUMVOLTS, MAXPVOLTS
 *          0x004 → MINPVOLTS, TOPCY, CURLIM, MAXPDCL
 *          0x005 → MAXPCCL, AVGCUR, HITEMP, HITHERID, LOWTEMP, LOWTHERID
 *          0x006 → AAVGTEMP, INTTEMP, FSPD, RQFSPD, LCELLVOLTS, LCELLVID, HCELLVID
 *          0x007 → HCELLVOLTS, AVGCELLVOLTS, LOPCELLVOLTS, LOPCELLVOLTSID, HOPCELLVOLTSID
 *          0x008 → HOPCELLVOLTS, AVGCELLVOLTS, LCELLRES, HCELLRES
 *          0x009 → AVGCELLINTRES, ADPTTOC, ADPTAMPH, MAXCELLVOLTS
 *          0x00A → ADPTSOC, MINCELLVOLTS, FVOLTS, J1772ACL, J1772PS
 *          0x00B → J1772ACPOL, J1772ACVOLTS, DTCF1, DTCF2
 *          default → error: Unknown ID
 *          @endcode
 *
 * @param[in]  USBdata    Pointer to the raw USB frame buffer.
 *                        Must be at least 13 bytes for full field parsing.
 * @param[out] json       Destination buffer for the formatted JSON string.
 * @param[in]  json_size  Size of the @p json buffer in bytes.
 *                        Recommended minimum: 256 bytes.
 *
 * @note
 *   - ID is extracted as 4-byte little-endian from @c USBdata[0–3].
 *   - All field values are represented in hexadecimal format.
 *   - Unknown IDs produce a fallback error JSON.
 *   - Each timestamp is generated fresh per call.
 *
 * @warning Caller must ensure @p json buffer is large enough to hold the
 *          formatted output. Insufficient size will result in truncation.
 *
 * @return  void
 */
void bms_JSONdata(uint8_t *USBdata, char *json, size_t json_size) {

    /* ── Timestamp ──────────────────────────────────────────────────────────
     * Retrieve current system time with millisecond precision.
     * ────────────────────────────────────────────────────────────────────── */
    char timestamp[64];
    get_timestamp(timestamp, sizeof(timestamp));

    /* ── Extract 4-Byte BMS ID (Little-Endian) ──────────────────────────────
     * Reconstruct 32-bit ID: USBdata[0]=LSB, USBdata[3]=MSB.
     * ────────────────────────────────────────────────────────────────────── */
    uint8_t id = (uint8_t)(((uint32_t)USBdata[3] << 24) |
                            ((uint32_t)USBdata[2] << 16) |
                            ((uint32_t)USBdata[1] <<  8) |
                             (uint32_t)USBdata[0]);

    /* ── Route by BMS ID ────────────────────────────────────────────────────
     * Each case formats the JSON string for the specific BMS parameter group.
     * ────────────────────────────────────────────────────────────────────── */
    switch (id) {

        /* ── ID 0x0F: Pack Status Frame ──────────────────────────────────────
         * Fields: RLY, MCELL, PCELLS, ROLLCNT, FSTATUS, PSOC
         * ────────────────────────────────────────────────────────────────── */
        case 0x00F:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x0F\", \"length\": 8, \"fields\": {"
                " \"RLY\": \"0x%04X\", \"MCELL\": \"0x%02X\", \"PCELLS\": \"0x%02X\","
                " \"ROLLCNT\": \"0x%02X\", \"FSTATUS\": \"0x%04X\", \"PSOC\": \"0x%02X\" } }",
                timestamp,
                (uint16_t)(USBdata[6] | (USBdata[5] << 8)),  /* Relay status          */
                USBdata[7],                                   /* Max cell               */
                USBdata[8],                                   /* Pack cells             */
                USBdata[9],                                   /* Rolling counter        */
                (uint16_t)(USBdata[11] | (USBdata[10] << 8)),/* Fault status           */
                USBdata[12]);                                 /* Pack state of charge   */
            break;

        /* ── ID 0x0E: Pack Electrical Frame ─────────────────────────────────
         * Fields: PINSTVOLT, PCUR, PSOC, AVGTEMP, HITEMP
         * ────────────────────────────────────────────────────────────────── */
        case 0x00E:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x0E\", \"length\": 7, \"fields\": {"
                " \"PINSTVOLT\": \"0x%04X\", \"PCUR\": \"0x%04X\","
                " \"PSOC\": \"0x%02X\", \"AVGTEMP\": \"0x%02X\", \"HITEMP\": \"0x%02X\" } }",
                timestamp,
                (uint16_t)(USBdata[6] | (USBdata[5] << 8)),  /* Pack instantaneous voltage */
                (uint16_t)(USBdata[8] | (USBdata[7] << 8)),  /* Pack current               */
                USBdata[9],                                   /* Pack state of charge       */
                USBdata[10],                                  /* Average temperature        */
                USBdata[11]);                                 /* Highest temperature        */
            break;

        /* ── ID 0x0D: Pack Health Frame ──────────────────────────────────────
         * Fields: PRES, PDOD, PSOH, PSUMVOLTS, MAXPVOLTS
         * ────────────────────────────────────────────────────────────────── */
        case 0x00D:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x0D\", \"length\": 8, \"fields\": {"
                " \"PRES\": \"0x%04X\", \"PDOD\": \"0x%02X\", \"PSOH\": \"0x%02X\","
                " \"PSUMVOLTS\": \"0x%04X\", \"MAXPVOLTS\": \"0x%04X\" } }",
                timestamp,
                (uint16_t)(USBdata[6] | (USBdata[5] << 8)),  /* Pack resistance      */
                USBdata[7],                                   /* Pack depth of disch. */
                USBdata[8],                                   /* Pack state of health */
                (uint16_t)(USBdata[10] | (USBdata[9]  << 8)),/* Pack sum voltage     */
                (uint16_t)(USBdata[12] | (USBdata[11] << 8)));/* Max pack voltage    */
            break;

        /* ── ID 0x04: Pack Limits Frame ──────────────────────────────────────
         * Fields: MINPVOLTS, TOPCY, CURLIM, MAXPDCL
         * ────────────────────────────────────────────────────────────────── */
        case 0x004:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x04\", \"length\": 8, \"fields\": {"
                " \"MINPVOLTS\": \"0x%04X\", \"TOPCY\": \"0x%04X\","
                " \"CURLIM\": \"0x%04X\", \"MAXPDCL\": \"0x%04X\" } }",
                timestamp,
                (uint16_t)(USBdata[6]  | (USBdata[5]  << 8)),  /* Min pack voltage     */
                (uint16_t)(USBdata[8]  | (USBdata[7]  << 8)),  /* Total op. cycles     */
                (uint16_t)(USBdata[10] | (USBdata[9]  << 8)),  /* Current limit        */
                (uint16_t)(USBdata[12] | (USBdata[11] << 8))); /* Max pack DCL         */
            break;

        /* ── ID 0x05: Pack Charge Limits & Temperature Frame ────────────────
         * Fields: MAXPCCL, AVGCUR, HITEMP, HITHERID, LOWTEMP, LOWTHERID
         * ────────────────────────────────────────────────────────────────── */
        case 0x005:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x05\", \"length\": 8, \"fields\": {"
                " \"MAXPCCL\": \"0x%04X\", \"AVGCUR\": \"0x%04X\","
                " \"HITEMP\": \"0x%02X\", \"HITHERID\": \"0x%02X\","
                " \"LOWTEMP\": \"0x%02X\", \"LOWTHERID\": \"0x%02X\" } }",
                timestamp,
                (uint16_t)(USBdata[6] | (USBdata[5] << 8)),  /* Max pack CCL        */
                (uint16_t)(USBdata[8] | (USBdata[7] << 8)),  /* Average current     */
                USBdata[9],                                   /* Highest temperature */
                USBdata[10],                                  /* Highest therm. ID   */
                USBdata[11],                                  /* Lowest temperature  */
                USBdata[12]);                                 /* Lowest therm. ID    */
            break;

        /* ── ID 0x06: Cell Voltage Summary Frame ────────────────────────────
         * Fields: AAVGTEMP, INTTEMP, FSPD, RQFSPD, LCELLVOLTS, LCELLVID, HCELLVID
         * ────────────────────────────────────────────────────────────────── */
        case 0x006:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x06\", \"length\": 8, \"fields\": {"
                " \"AAVGTEMP\": \"0x%02X\", \"INTTEMP\": \"0x%02X\","
                " \"FSPD\": \"0x%02X\", \"RQFSPD\": \"0x%02X\","
                " \"LCELLVOLTS\": \"0x%04X\", \"LCELLVID\": \"0x%02X\","
                " \"HCELLVID\": \"0x%02X\" } }",
                timestamp,
                USBdata[5],                                    /* Actual avg temp      */
                USBdata[6],                                    /* Internal temperature */
                USBdata[7],                                    /* Fan speed            */
                USBdata[8],                                    /* Requested fan speed  */
                (uint16_t)(USBdata[10] | (USBdata[9] << 8)), /* Low cell voltage     */
                USBdata[11],                                   /* Low cell volt. ID    */
                USBdata[12]);                                  /* High cell volt. ID   */
            break;

        /* ── ID 0x07: Cell Voltage Extremes Frame ───────────────────────────
         * Fields: HCELLVOLTS, AVGCELLVOLTS, LOPCELLVOLTS, LOPCELLVOLTSID, HOPCELLVOLTSID
         * ────────────────────────────────────────────────────────────────── */
        case 0x007:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x07\", \"length\": 8, \"fields\": {"
                " \"HCELLVOLTS\": \"0x%04X\", \"AVGCELLVOLTS\": \"0x%04X\","
                " \"LOPCELLVOLTS\": \"0x%04X\","
                " \"LOPCELLVOLTSID\": \"0x%02X\", \"HOPCELLVOLTSID\": \"0x%02X\" } }",
                timestamp,
                (uint16_t)(USBdata[6]  | (USBdata[5]  << 8)),  /* High cell voltage       */
                (uint16_t)(USBdata[8]  | (USBdata[7]  << 8)),  /* Avg. cell voltage       */
                (uint16_t)(USBdata[10] | (USBdata[9]  << 8)),  /* Low open cell voltage   */
                USBdata[11],                                    /* Low open cell volt. ID  */
                USBdata[12]);                                   /* High open cell volt. ID */
            break;

        /* ── ID 0x08: Cell Resistance Frame ─────────────────────────────────
         * Fields: HOPCELLVOLTS, AVGCELLVOLTS, LCELLRES, HCELLRES
         * ────────────────────────────────────────────────────────────────── */
        case 0x008:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": {"
                " \"HOPCELLVOLTS\": \"0x%04X\", \"AVGCELLVOLTS\": \"0x%04X\","
                " \"LCELLRES\": \"0x%04X\", \"HCELLRES\": \"0x%04X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[6]  | (USBdata[5]  << 8)),  /* High open cell voltage */
                (uint16_t)(USBdata[8]  | (USBdata[7]  << 8)),  /* Avg. cell voltage      */
                (uint16_t)(USBdata[10] | (USBdata[9]  << 8)),  /* Low cell resistance    */
                (uint16_t)(USBdata[12] | (USBdata[11] << 8))); /* High cell resistance   */
            break;

        /* ── ID 0x09: Adaptive Parameters Frame ─────────────────────────────
         * Fields: AVGCELLINTRES, ADPTTOC, ADPTAMPH, MAXCELLVOLTS
         * ────────────────────────────────────────────────────────────────── */
        case 0x009:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": {"
                " \"AVGCELLINTRES\": \"0x%04X\", \"ADPTTOC\": \"0x%04X\","
                " \"ADPTAMPH\": \"0x%04X\", \"MAXCELLVOLTS\": \"0x%04X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[6]  | (USBdata[5]  << 8)),  /* Avg cell int. resist. */
                (uint16_t)(USBdata[8]  | (USBdata[7]  << 8)),  /* Adaptive time of ch.  */
                (uint16_t)(USBdata[10] | (USBdata[9]  << 8)),  /* Adaptive amp-hours    */
                (uint16_t)(USBdata[12] | (USBdata[11] << 8))); /* Max cell voltage      */
            break;

        /* ── ID 0x0A: J1772 & SOC Frame ─────────────────────────────────────
         * Fields: ADPTSOC, MINCELLVOLTS, FVOLTS, J1772ACL, J1772PS
         * ────────────────────────────────────────────────────────────────── */
        case 0x00A:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x0A\", \"length\": 8, \"fields\": {"
                " \"ADPTSOC\": \"0x%02X\", \"MINCELLVOLTS\": \"0x%04X\","
                " \"FVOLTS\": \"0x%04X\", \"J1772ACL\": \"0x%04X\","
                " \"J1772PS\": \"0x%02X\" } }",
                timestamp,
                USBdata[5],                                    /* Adaptive SOC          */
                (uint16_t)(USBdata[7]  | (USBdata[6]  << 8)),/* Min cell voltage      */
                (uint16_t)(USBdata[9]  | (USBdata[8]  << 8)),/* Filtered voltage      */
                (uint16_t)(USBdata[11] | (USBdata[10] << 8)),/* J1772 AC level        */
                USBdata[12]);                                  /* J1772 pilot signal    */
            break;

        /* ── ID 0x0B: J1772 AC & DTC Frame ──────────────────────────────────
         * Fields: J1772ACPOL, J1772ACVOLTS, DTCF1, DTCF2
         * ────────────────────────────────────────────────────────────────── */
        case 0x00B:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x0B\", \"length\": 8, \"fields\": {"
                " \"J1772ACPOL\": \"0x%04X\", \"J1772ACVOLTS\": \"0x%04X\","
                " \"DTCF1\": \"0x%04X\", \"DTCF2\": \"0x%04X\" } }",
                timestamp,
                (uint16_t)(USBdata[6]  | (USBdata[5]  << 8)),  /* J1772 AC polarity   */
                (uint16_t)(USBdata[8]  | (USBdata[7]  << 8)),  /* J1772 AC voltage    */
                (uint16_t)(USBdata[10] | (USBdata[9]  << 8)),  /* DTC flag group 1    */
                (uint16_t)(USBdata[12] | (USBdata[11] << 8))); /* DTC flag group 2    */
            break;

        /* ── Default: Unknown BMS ID ─────────────────────────────────────────
         * ID not recognised — produce a descriptive error JSON.
         * Caller should discard this frame and not log it.
         * ────────────────────────────────────────────────────────────────── */
        default:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\","
                " \"length\": 8, \"error\": \"Unknown ID\" }",
                timestamp, id);
            break;
    }
}
