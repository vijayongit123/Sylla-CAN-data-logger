/**
 * @file    udp_common.h
 * @brief   Public API for common UDP socket operations.
 *
 * @details This header declares the shared UDP communication interface used
 *          across the CAN data logger subsystems. It provides:
 *
 *          - A UDP socket initialisation function bound to a configurable port.
 *          - A thread-safe JSON send function with an optional post-send callback.
 *          - A blocking receive loop that dispatches packets to a user callback.
 *
 *          Callback types are defined here to allow flexible integration with
 *          different subsystem handlers (MC, BMS, GUI notification, etc.).
 *
 *          Typical usage:
 *          @code
 *          int sockfd = init_udp_socket(8882);
 *          wait_for_udp(sockfd, my_receive_handler);     // in receiver thread
 *          send_udp_json(sockfd, json, "192.168.3.51", 8881, NULL);
 *          @endcode
 *
 * @note    All functions declared here are implemented in @c udp_common.c.
 *          This header is C++ compatible via the @c extern "C" guard.
 *
 * @author  Vijay Singh — Embedded Systems Team
 * @version 1.0
 */

#ifndef UDP_COMMON_H
#define UDP_COMMON_H

/* ── Required System Headers ─────────────────────────────────────────────────── */
#include <netinet/in.h>   ///< sockaddr_in, INADDR_ANY, htons — IPv4 address structures

/* ═══════════════════════════════════════════════════════════════════════════════
 * CONFIGURATION CONSTANTS
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @def   MAX_BUFFER
 * @brief Maximum size in bytes for the UDP receive buffer.
 *
 * @details Defines the upper limit for a single incoming UDP payload.
 *          Packets larger than this value will be truncated by @c recvfrom().
 *          Increase this value if JSON payloads exceed 1024 bytes.
 *
 * @note  UDP datagrams are limited to 65,507 bytes (IPv4 max payload).
 *        This macro sets the application-level receive buffer, not the
 *        OS socket buffer.
 */
#define MAX_BUFFER   1024   ///< UDP receive buffer size in bytes

/* ═══════════════════════════════════════════════════════════════════════════════
 * CALLBACK TYPE DEFINITIONS
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @typedef on_receive_cb
 * @brief   Function pointer type for the UDP receive callback.
 *
 * @details This callback is invoked by @c wait_for_udp() each time a valid
 *          UDP packet is received. The caller is responsible for parsing
 *          @p data and taking the appropriate action (e.g., updating @c g_udp_cmd).
 *
 * @param[in] data    Null-terminated string containing the received payload.
 *                    Valid for the duration of the callback only — copy if needed.
 * @param[in] sender  Pointer to the sender's IPv4 address structure.
 *                    Contains the source IP and port of the received packet.
 *
 * Example implementation:
 * @code
 * void my_handler(const char *data, struct sockaddr_in *sender) {
 *     printf("Received: %s from %s\n", data, inet_ntoa(sender->sin_addr));
 * }
 * @endcode
 */
typedef void (*on_receive_cb)(const char *data, struct sockaddr_in *sender);


/**
 * @typedef on_send_cb
 * @brief   Function pointer type for the UDP post-send callback.
 *
 * @details This callback is optionally invoked by @c send_udp_json() after a
 *          UDP packet is successfully transmitted. It is called outside the
 *          send mutex to prevent deadlocks.
 *
 *          Use cases include logging, acknowledgement tracking, or triggering
 *          follow-up actions after a send completes.
 *
 * @param[in] data  Null-terminated JSON string that was sent.
 * @param[in] dest  Pointer to the destination IPv4 address structure.
 *                  Contains the target IP and port used for the send.
 *
 * Example implementation:
 * @code
 * void my_send_log(const char *data, struct sockaddr_in *dest) {
 *     printf("Sent to %s: %s\n", inet_ntoa(dest->sin_addr), data);
 * }
 * @endcode
 */
typedef void (*on_send_cb)(const char *data, struct sockaddr_in *dest);


/* ═══════════════════════════════════════════════════════════════════════════════
 * C++ COMPATIBILITY GUARD
 * Ensures C linkage when this header is included in C++ translation units.
 * ═══════════════════════════════════════════════════════════════════════════════ */
#ifdef __cplusplus
extern "C" {
#endif

/* ═══════════════════════════════════════════════════════════════════════════════
 * FUNCTION PROTOTYPES
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Initialise and bind a UDP socket to the specified port.
 *
 * @details Creates an IPv4 UDP socket, enables @c SO_REUSEADDR for rapid
 *          port reuse after restart, and binds to @c INADDR_ANY so the socket
 *          accepts packets on all available network interfaces.
 *
 * @param[in] port  UDP port number to bind (valid range: 1–65535).
 *
 * @note    Binds to all interfaces (@c INADDR_ANY). Restrict to a specific
 *          interface IP in @c udp_common.c if isolation is required.
 *
 * @warning Calls @c exit(EXIT_FAILURE) on any fatal error (invalid port,
 *          socket creation failure, or bind failure).
 *
 * @return  Valid socket file descriptor (≥ 0) on success.
 *          Never returns on failure — process is terminated.
 */
int init_udp_socket(int port);


/**
 * @brief   Send a JSON-formatted string over UDP in a thread-safe manner.
 *
 * @details Resolves the destination IPv4 address, acquires a send mutex,
 *          transmits the payload via @c sendto(), then releases the mutex.
 *          An optional post-send callback is invoked after the mutex is
 *          released to avoid potential deadlocks.
 *
 * @param[in] sockfd  UDP socket file descriptor returned by @c init_udp_socket().
 *                    Must be ≥ 0.
 * @param[in] json    Null-terminated JSON string to transmit. Must not be @c NULL.
 * @param[in] ip      Destination IPv4 address string (e.g., @c "192.168.3.51").
 *                    Must be a valid dotted-decimal format. Must not be @c NULL.
 * @param[in] port    Destination UDP port number (valid range: 1–65535).
 * @param[in] cb      Optional post-send callback. Pass @c NULL if not required.
 *
 * @note    Thread-safe — protected by an internal @c pthread_mutex_t initialised
 *          once via @c pthread_once().
 *
 * @warning Invalid @p ip format will cause @c inet_pton() to fail and
 *          the function returns @c -1 without sending.
 *
 * @return   @c  0  on success — packet transmitted.
 * @return   @c -1  on failure — invalid arguments, bad IP, or send error.
 */
int send_udp_json(int sockfd, const char *json, const char *ip, int port, on_send_cb cb);


/**
 * @brief   Continuously poll for incoming UDP packets and dispatch to a callback.
 *
 * @details Runs an infinite receive loop using @c select() with a short timeout
 *          (@c UDP_RECEIVE_TIMEOUT_MS). When data is available, @c recvfrom()
 *          reads the payload and the callback @p cb is invoked with the
 *          null-terminated data and sender address.
 *
 *          The loop exits only on a @c select() error. Normal timeouts
 *          (no data) continue polling silently without consuming CPU.
 *
 * @param[in] sockfd  Valid UDP socket file descriptor (must be ≥ 0).
 * @param[in] cb      Callback invoked for each received packet.
 *                    Must not be @c NULL.
 *                    Signature: @c void cb(const char *data, struct sockaddr_in *sender)
 *
 * @note    This function is blocking and intended to run in a dedicated
 *          POSIX receiver thread created via @c pthread_create().
 *
 * @warning The loop exits only on @c select() error. Ensure the calling
 *          thread handles cleanup if this function returns unexpectedly.
 *
 * @return  void
 */
void wait_for_udp(int sockfd, on_receive_cb cb);

#ifdef __cplusplus
}
#endif

#endif /* UDP_COMMON_H */