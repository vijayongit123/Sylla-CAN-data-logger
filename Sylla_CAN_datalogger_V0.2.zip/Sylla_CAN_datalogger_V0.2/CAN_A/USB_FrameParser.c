// --------------------------------------------------------------------------------------------------
// Includes and Configuration for USB and UDP Communication
// --------------------------------------------------------------------------------------------------

#include <pthread.h>         // For multi-threading support
#include <unistd.h>          // For sleep and system calls
#include <stdio.h>           // For standard I/O functions
#include <stdlib.h>          // For general utilities (malloc, free, etc.)
#include <stdbool.h>         // For boolean type definitions
#include <stddef.h>          // For NULL macro definition
#include <stdint.h>          // For fixed-width integer types
#include <string.h>          // For memory operations like memcpy


#include "USB_Driver.h"       // USB hardware interface
#include "USB_Datalogger.h"   // CAN data processing (process_usb_data)
#include "USB_FrameParser.h"  // Public API for this module

#define RETRY_DELAY               2       // Seconds to wait before retrying a failed USB init
#define USB_FRAME_MAX_LEN         256U    // Maximum size of a single incoming USB data chunk
#define USB_CIRCULAR_BUFFER_SIZE  1024U   // Circular buffer size for incoming USB data
#define FIXED_FRAME_LEN           20U     // Expected byte length of one complete CAN frame

#ifndef USB_DEBUG_PRINT
#define USB_DEBUG_PRINT           0       // Set to 1 to enable debug output
#endif

// --------------------------------------------------------------------------------------------------
// Diagnostic Counters
// --------------------------------------------------------------------------------------------------

static volatile uint32_t usb_frame_checksum_errors = 0U;  // Number of checksum mismatches
static volatile uint32_t usb_frame_invalid_end     = 0U;  // Number of invalid end byte errors
static volatile uint32_t usb_frame_overwrites      = 0U;  // Number of circular buffer overwrites

// --------------------------------------------------------------------------------------------------
// Static Functions
// --------------------------------------------------------------------------------------------------

// Write incoming bytes into the circular buffer. Overwrites oldest data if full.
static void store_data_in_buffer(const uint8_t *data, uint16_t data_length,
                                 uint8_t *circular_buffer,
                                 uint16_t *write_index,
                                 uint16_t *read_index) {
    for (uint16_t byte_position = 0U; byte_position < data_length; ++byte_position) {
        circular_buffer[*write_index] = data[byte_position];
        *write_index = (*write_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;

        if (*write_index == *read_index) {
            *read_index = (*read_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;
            usb_frame_overwrites++;
#if USB_DEBUG_PRINT
            printf("[DEBUG] Overwrite occurred, total overwrites: %lu\n", (unsigned long)usb_frame_overwrites);
#endif
        }
    }
}

// Scan the circular buffer for the 5-byte start sequence: 0xAA 0x55 0x01 0x01 0x01.
// Updates read_index to the start position if found. Returns true on success.
static bool find_start_sequence(uint8_t *buffer, uint16_t *read_index, uint16_t available) {
    uint16_t search_index = *read_index;
    while (available >= 5U) {
        if ((buffer[search_index] == 0xAAU) &&
            (buffer[(search_index + 1U) % USB_CIRCULAR_BUFFER_SIZE] == 0x55U) &&
            (buffer[(search_index + 2U) % USB_CIRCULAR_BUFFER_SIZE] == 0x01U) &&
            (buffer[(search_index + 3U) % USB_CIRCULAR_BUFFER_SIZE] == 0x01U) &&
            (buffer[(search_index + 4U) % USB_CIRCULAR_BUFFER_SIZE] == 0x01U)) {
            return true;
        }
        search_index = (search_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;
        available--;
        *read_index = search_index;
    }
    return false;
}

// Copy FIXED_FRAME_LEN bytes from the circular buffer into a linear frame array.
static void extract_frame(const uint8_t *buffer, uint8_t *frame, uint16_t read_index) {
    for (uint8_t frame_index = 0U; frame_index < FIXED_FRAME_LEN; ++frame_index) {
        frame[frame_index] = buffer[(read_index + frame_index) % USB_CIRCULAR_BUFFER_SIZE];
    }
}

// Validate a frame: byte 18 must be 0x00 (end delimiter),
// byte 19 must equal the lower 8 bits of the sum of bytes 2-17 (checksum).
static bool validate_frame(const uint8_t *frame) {
    if (frame[18U] != 0x00U) {
        usb_frame_invalid_end++;
#if USB_DEBUG_PRINT
        printf("[DEBUG] Invalid end byte count: %lu\n", (unsigned long)usb_frame_invalid_end);
        printf("[DEBUG] Invalid end byte: 0x%02X\n", frame[18U]);
        printf("[DEBUG] Full Frame: ");
        for (uint8_t i = 0U; i < FIXED_FRAME_LEN; ++i) { printf("%02X ", frame[i]); }
        printf("\n");
#endif
        return false;
    }

    uint16_t checksum = 0U;
    for (uint8_t checksum_index = 2U; checksum_index <= 17U; ++checksum_index) {
        checksum += frame[checksum_index];
    }

    if (frame[19U] != (uint8_t)(checksum & 0xFFU)) {
        usb_frame_checksum_errors++;
#if USB_DEBUG_PRINT
        printf("[DEBUG] Checksum error count: %lu\n", (unsigned long)usb_frame_checksum_errors);
        printf("[DEBUG] Checksum mismatch: expected 0x%02X, got 0x%02X\n",
               (uint8_t)(checksum & 0xFFU), frame[19U]);
        printf("[DEBUG] Full Frame: ");
        for (uint8_t i = 0U; i < FIXED_FRAME_LEN; ++i) { printf("%02X ", frame[i]); }
        printf("\n");
#endif
        return false;
    }

    return true;
}

// Extract message ID (bytes 5-8, little-endian), payload length (byte 9), and payload
// (bytes 10-17) from a validated frame. Passes 13 bytes starting at byte 5 to the
// application layer. Discards frames with payload length > 8.
static void handle_valid_frame(const uint8_t *frame) {
    uint32_t message_id = ((uint32_t)frame[8U] << 24U) |
                          ((uint32_t)frame[7U] << 16U) |
                          ((uint32_t)frame[6U] << 8U)  |
                          (uint32_t)frame[5U];
    uint8_t payload_length = frame[9U];

    if (payload_length > 8U) {
#if USB_DEBUG_PRINT
        printf("[DEBUG] Invalid data length: %u\n", payload_length);
#endif
        return;
    }

#if USB_DEBUG_PRINT
    printf("[DEBUG] Valid frame: MSG_ID=0x%08X, Length=%u, Data=", message_id, payload_length);
    for (uint8_t i = 10U; i < 18U; ++i) { printf("%02X ", frame[i]); }
    printf("\n");
#endif

    process_usb_data((uint8_t *)&frame[5U], 13U);
}

// --------------------------------------------------------------------------------------------------
// Public API
// --------------------------------------------------------------------------------------------------

// Buffer incoming USB bytes and extract valid CAN frames. Each frame is located by its
// start sequence, validated by end byte and checksum, then forwarded to the application.
// Invalid frames advance the read index by one byte to resume scanning.
void parse_motor_usb_can_frames(const unsigned char *data, int data_length) {
    if ((data == NULL) || (data_length == 0U) || (data_length > USB_FRAME_MAX_LEN)) {
        return;
    }

    static uint8_t  circular_buffer[USB_CIRCULAR_BUFFER_SIZE];  // Internal ring buffer
    static uint16_t write_index = 0U;                           // Next write position
    static uint16_t read_index  = 0U;                           // Next read position

    store_data_in_buffer(data, data_length, circular_buffer, &write_index, &read_index);

    while (true) {
        uint16_t bytes_available = (write_index >= read_index) ?
            (write_index - read_index) :
            (USB_CIRCULAR_BUFFER_SIZE - read_index + write_index);

        if (bytes_available < FIXED_FRAME_LEN) {
            break;
        }

        if (!find_start_sequence(circular_buffer, &read_index, bytes_available)) {
            break;
        }

        uint8_t frame[FIXED_FRAME_LEN];
        extract_frame(circular_buffer, frame, read_index);

        if (!validate_frame(frame)) {
            read_index = (read_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;
            continue;
        }

        handle_valid_frame(frame);
        read_index = (read_index + FIXED_FRAME_LEN) % USB_CIRCULAR_BUFFER_SIZE;
    }
}