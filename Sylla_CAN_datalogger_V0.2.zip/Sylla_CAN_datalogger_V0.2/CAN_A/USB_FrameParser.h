/**
 * @file    usb_frame_parser.h
 * @brief   Public API for USB CAN frame parsing and validation.
 *
 * @details This module reconstructs fixed-length CAN frames from a continuous
 *          USB byte stream. It provides a single entry-point function that:
 *
 *          1. Buffers incoming raw USB bytes in a circular buffer.
 *          2. Detects valid CAN frame boundaries using start/end delimiters.
 *          3. Validates each candidate frame using a checksum.
 *          4. Forwards verified frame payloads to the higher-level data handler
 *             (@c process_usb_data()) for JSON conversion and logging.
 *
 *          Typical integration (inside the USB RX callback):
 *          @code
 *          void my_usb_handler(const unsigned char *data, int length) {
 *              parse_motor_usb_can_frames(data, length);
 *          }
 *          @endcode
 *
 *          Data flow:
 *          @code
 *          USB RX bytes
 *              └──▶ parse_motor_usb_can_frames()
 *                       └──▶ circular buffer accumulation
 *                                └──▶ delimiter detection + checksum validation
 *                                         └──▶ process_usb_data()  (valid frames only)
 *          @endcode
 *
 * @note    All function implementations are in @c USB_FrameParser.c.
 *          This header is C++ compatible via the @c extern "C" guard.
 *
 * @author  Vijay Singh — Sarla Aviation, Embedded Systems Team
 * @version 1.0
 * @date    2025-11-03
 */

#ifndef USB_FRAME_PARSER_H
#define USB_FRAME_PARSER_H

/* ── Required Type Headers ───────────────────────────────────────────────────── */
#include <stdint.h>    ///< Fixed-width integer types : uint8_t, uint16_t, uint32_t
#include <stdbool.h>   ///< Boolean type support      : bool, true, false

/* ═══════════════════════════════════════════════════════════════════════════════
 * C++ COMPATIBILITY GUARD
 * Ensures C linkage when this header is included in C++ translation units.
 * ═══════════════════════════════════════════════════════════════════════════════ */
#ifdef __cplusplus
extern "C" {
#endif

/* ═══════════════════════════════════════════════════════════════════════════════
 * FUNCTION PROTOTYPES
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Parse and process incoming raw USB bytes into validated CAN frames.
 *
 * @details This is the main entry point for all incoming USB data. It should be
 *          registered as the USB data callback via @c set_usb_data_callback().
 *
 *          Internal processing steps:
 *          @code
 *          1. Append incoming bytes to the internal circular buffer.
 *          2. Scan the buffer for valid CAN frame start/end delimiters.
 *          3. Extract candidate frames of the expected fixed length.
 *          4. Validate the frame checksum — discard on mismatch.
 *          5. Forward valid frame payload to process_usb_data().
 *          @endcode
 *
 *          This function handles fragmented USB transfers correctly — a single
 *          CAN frame may arrive across multiple @c data calls, and multiple
 *          frames may arrive in a single call.
 *
 * @param[in] data         Pointer to the raw USB byte buffer received from the
 *                         USB RX thread. Must not be @c NULL.
 * @param[in] data_length  Number of valid bytes in @p data. Must be > 0.
 *
 * @note    This function is designed to be called directly from the USB RX
 *          callback thread. It maintains internal static state (circular buffer
 *          and buffer index) across calls.
 *
 * @warning Not thread-safe if called concurrently from multiple threads.
 *          Intended to be driven by a single USB RX thread only.
 *
 * @return  void
 */
void parse_motor_usb_can_frames(const unsigned char *data, int data_length);

#ifdef __cplusplus
}
#endif

#endif /* USB_FRAME_PARSER_H */