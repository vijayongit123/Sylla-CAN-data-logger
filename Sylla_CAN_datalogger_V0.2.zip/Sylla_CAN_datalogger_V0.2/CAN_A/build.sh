#!/bin/bash

# Compile source files
gcc -c udp_common.c USB_Datalogger.c USB_FrameParser.c USB_Driver.c main.c

# Link object files and produce executable
gcc USB_Datalogger.o USB_FrameParser.o USB_Driver.o main.o udp_common.o \
    -lusb-1.0 -ludev -lpthread -o App_CAN_A