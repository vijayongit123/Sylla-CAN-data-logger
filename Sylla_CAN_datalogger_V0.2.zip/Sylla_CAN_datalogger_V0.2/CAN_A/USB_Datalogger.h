/**
 * @file    datahandler.h
 * @brief   Public API for timestamp generation, USB frame parsing, and JSON formatting.
 *
 * @details This header exposes the core data processing functions used by the
 *          CAN data logger. It covers the following responsibilities:
 *
 *          - Timestamp generation with millisecond precision.
 *          - Raw USB CAN frame routing to the correct subsystem handler.
 *          - Binary-to-JSON conversion for Motor Controller (MC) frames.
 *          - Binary-to-JSON conversion for Battery Management System (BMS) frames.
 *          - JSON data logging to timestamped files, controlled via UDP command.
 *          - UDP message handling and command routing.
 *
 *          Subsystem routing is based on the 4-byte little-endian device ID
 *          embedded in the USB frame:
 *          @code
 *          ID range 20–147 (MC groups)  →  mc_JSONdata()   →  MC_JSON_datalog()
 *          ID range  0–19  (BMS)        →  bms_JSONdata()  →  BMS_JSON_datalog()
 *          @endcode
 *
 * @note    All functions in this header are implemented in @c USB_Datalogger.c.
 *
 * @author  Vijay Singh — Embedded Systems Team
 * @version 1.0
 */

#ifndef DATAHANDLER_H
#define DATAHANDLER_H

/* ── Required Type Headers ───────────────────────────────────────────────────── */
#include <stddef.h>          ///< size_t definition
#include <stdint.h>          ///< Fixed-width integer types : uint8_t, uint32_t
#include <netinet/in.h>      ///< sockaddr_in structure for UDP sender address

/* ═══════════════════════════════════════════════════════════════════════════════
 * UTILITY FUNCTIONS
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Generate a formatted timestamp string with millisecond precision.
 *
 * @details Retrieves the current wall-clock time and formats it as:
 *          @code
 *          YYYY-MM-DD HH:MM:SS.mmm
 *          Example: 2025-11-03 15:42:19.124
 *          @endcode
 *
 * @param[out] buffer  Destination buffer for the formatted timestamp string.
 *                     Set to @c "" on failure.
 * @param[in]  size    Size of @p buffer in bytes. Minimum required: 24 bytes.
 *
 * @note    Uses @c clock_gettime(CLOCK_REALTIME) for sub-second precision.
 *
 * @warning Not thread-safe due to @c localtime(). Use @c localtime_r() for
 *          concurrent access.
 *
 * @return  void
 */
void get_timestamp(char *buffer, size_t size);


/* ═══════════════════════════════════════════════════════════════════════════════
 * USB FRAME PROCESSING
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Route a raw USB CAN frame to the appropriate subsystem handler.
 *
 * @details Extracts the 4-byte little-endian device ID from the frame and
 *          dispatches to either the MC or BMS JSON converter based on ID range.
 *          The resulting JSON is validated and logged to a timestamped file.
 *
 *          Routing logic:
 *          @code
 *          ID in {20–27, 40–47, 60–67, 80–87, 100–107, 120–127, 140–147}
 *                               →  mc_JSONdata()   →  MC_JSON_datalog()
 *          ID < 20              →  bms_JSONdata()  →  BMS_JSON_datalog()
 *          @endcode
 *
 * @param[in] data  Pointer to the raw USB data buffer. Must not be @c NULL.
 * @param[in] len   Length of the buffer in bytes. Must be at least 4 bytes.
 *
 * @note    Frames with unrecognised offsets or IDs are silently discarded.
 *
 * @warning Passing @c NULL or @p len < 4 triggers an early return with an
 *          error message printed to @c stderr.
 *
 * @return  void
 */
void process_usb_data(uint8_t *data, int len);


/**
 * @brief   Parse a raw Motor Controller (MC) USB frame into a JSON string.
 *
 * @details Interprets binary MC data based on the message offset
 *          (lower decimal digit of the 4-byte little-endian ID).
 *
 *          Offset-to-field mapping:
 *          @code
 *          0x00 → PWM, Flag
 *          0x01 → BTV, BCAvg, RPM
 *          0x02 → MT, ETM, ETC, EXST
 *          0x03 → OPWM, IPWM
 *          0x04 → ERR, WRN
 *          0x05 → NTC, ESCIS
 *          0x06 → BATTIV, EFV, PCM, PCA
 *          0x07 → BCM, IBUS
 *          default → error: Unknown Offset
 *          @endcode
 *
 * @param[in]  USBdata    Pointer to the raw USB frame. Must be ≥ 14 bytes.
 * @param[out] json       Destination buffer for the formatted JSON string.
 * @param[in]  json_size  Size of @p json in bytes. Recommended minimum: 256 bytes.
 *
 * @note    All field values are formatted in hexadecimal.
 *          Unknown offsets produce a fallback error JSON — caller must discard.
 *
 * @warning Passing @c NULL for @p USBdata or @p json writes an error JSON
 *          to @p json if possible, then returns immediately.
 *
 * @return  void
 */
void mc_JSONdata(uint8_t *USBdata, char *json, size_t json_size);


/**
 * @brief   Parse a raw Battery Management System (BMS) USB frame into a JSON string.
 *
 * @details Interprets binary BMS data based on the full 4-byte little-endian ID.
 *
 *          ID-to-field mapping:
 *          @code
 *          0x00F → RLY, MCELL, PCELLS, ROLLCNT, FSTATUS, PSOC
 *          0x00E → PINSTVOLT, PCUR, PSOC, AVGTEMP, HITEMP
 *          0x00D → PRES, PDOD, PSOH, PSUMVOLTS, MAXPVOLTS
 *          0x004 → MINPVOLTS, TOPCY, CURLIM, MAXPDCL
 *          0x005 → MAXPCCL, AVGCUR, HITEMP, HITHERID, LOWTEMP, LOWTHERID
 *          0x006 → AAVGTEMP, INTTEMP, FSPD, RQFSPD, LCELLVOLTS, LCELLVID, HCELLVID
 *          0x007 → HCELLVOLTS, AVGCELLVOLTS, LOPCELLVOLTS, LOPCELLVOLTSID, HOPCELLVOLTSID
 *          0x008 → HOPCELLVOLTS, AVGCELLVOLTS, LCELLRES, HCELLRES
 *          0x009 → AVGCELLINTRES, ADPTTOC, ADPTAMPH, MAXCELLVOLTS
 *          0x00A → ADPTSOC, MINCELLVOLTS, FVOLTS, J1772ACL, J1772PS
 *          0x00B → J1772ACPOL, J1772ACVOLTS, DTCF1, DTCF2
 *          default → error: Unknown ID
 *          @endcode
 *
 * @param[in]  USBdata    Pointer to the raw USB frame. Must be ≥ 13 bytes.
 * @param[out] json       Destination buffer for the formatted JSON string.
 * @param[in]  json_size  Size of @p json in bytes. Recommended minimum: 256 bytes.
 *
 * @note    All field values are formatted in hexadecimal.
 *          Unknown IDs produce a fallback error JSON — caller must discard.
 *
 * @warning Insufficient @p json_size will cause output truncation without error.
 *
 * @return  void
 */
void bms_JSONdata(uint8_t *USBdata, char *json, size_t json_size);


/* ═══════════════════════════════════════════════════════════════════════════════
 * DATA LOGGING FUNCTIONS
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Log incoming MC JSON data to a timestamped file, controlled by UDP command.
 *
 * @details Logging behaviour is governed by @c g_udp_cmd:
 *          @code
 *          g_udp_cmd == 1  →  START: create dir, open new file, notify GUI, write data
 *          g_udp_cmd == 0  →  STOP : close session, reset filename, notify GUI
 *          @endcode
 *
 *          Log file format:
 *          @code
 *          Flight_Testdata/MC_YYYYMMDD_HHMMSS.txt
 *          @endcode
 *
 * @param[in] data  Pointer to a null-terminated JSON string. Must not be @c NULL.
 *
 * @warning Not thread-safe. Use a mutex if called from multiple threads.
 *
 * @return  void
 */
void MC_JSON_datalog(const char *data);


/**
 * @brief   Log incoming BMS JSON data to a timestamped file, controlled by UDP command.
 *
 * @details Logging behaviour is governed by @c g_udp_cmd:
 *          @code
 *          g_udp_cmd == 1  →  START: create dir, open new file, notify GUI, write data
 *          g_udp_cmd == 0  →  STOP : close session, reset filename, notify GUI
 *          @endcode
 *
 *          Log file format:
 *          @code
 *          Flight_Testdata/BMS_YYYYMMDD_HHMMSS.txt
 *          @endcode
 *
 * @param[in] data  Pointer to a null-terminated JSON string. Must not be @c NULL.
 *
 * @warning Not thread-safe. Use a mutex if called from multiple threads.
 *
 * @return  void
 */
void BMS_JSON_datalog(const char *data);


/* ═══════════════════════════════════════════════════════════════════════════════
 * UDP MESSAGE HANDLING
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Parse an incoming UDP message and store the command in @c g_udp_cmd.
 *
 * @details Converts the received string to an unsigned integer via @c strtoul()
 *          and stores it in the global @c g_udp_cmd variable.
 *
 *          Expected values:
 *          @code
 *          "1"  →  g_udp_cmd = 1  →  Start logging
 *          "0"  →  g_udp_cmd = 0  →  Stop  logging
 *          @endcode
 *
 * @param[in] data    Null-terminated UDP command string. Must not be @c NULL.
 * @param[in] sender  Pointer to the sender's address structure. Must not be @c NULL.
 *
 * @return  void
 */
void handle_udp_json_message(const char *data, struct sockaddr_in *sender);

#endif /* DATAHANDLER_H */