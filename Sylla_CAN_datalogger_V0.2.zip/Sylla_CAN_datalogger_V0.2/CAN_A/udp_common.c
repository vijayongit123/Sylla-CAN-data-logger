/**
 * @file    udp_common.c
 * @brief   Common UDP socket utilities for initialisation, sending, and receiving.
 *
 * @details This file implements the shared UDP communication layer used by the
 *          CAN data logger. It provides three core capabilities:
 *
 *          1. **Socket initialisation** — creates and binds a UDP socket to a
 *             specified port for listening.
 *
 *          2. **Thread-safe sending** — transmits a JSON string to a target
 *             IP:port using a mutex-protected @c sendto() call.
 *
 *          3. **Non-blocking receive loop** — polls for incoming UDP packets
 *             using @c select() with a short timeout, invoking a user-supplied
 *             callback for each received packet.
 *
 *          Thread safety:
 *          - @c send_udp_json() is protected by a @c pthread_mutex_t initialised
 *            exactly once via @c pthread_once().
 *          - @c wait_for_udp() is intended to run in a dedicated receiver thread.
 *
 * @note    Set @c UDP_DEBUG_PRINT to @c 1 to enable verbose socket logging.
 *
 * @author  Vijay Singh — Embedded Systems Team
 * @version 1.0
 */

#include "udp_common.h"

/* ── Standard C Library Headers ─────────────────────────────────────────────── */
#include <stdio.h>        ///< Standard I/O         : printf, fprintf, perror
#include <stdlib.h>       ///< General utilities    : exit, EXIT_FAILURE
#include <string.h>       ///< String utilities     : memset, strlen
#include <unistd.h>       ///< POSIX system calls   : close

/* ── System / POSIX Headers ─────────────────────────────────────────────────── */
#include <arpa/inet.h>    ///< Internet operations  : htons, inet_pton, inet_ntoa, INADDR_ANY
#include <sys/select.h>   ///< I/O multiplexing     : select, fd_set, FD_ZERO, FD_SET, timeval
#include <pthread.h>      ///< POSIX threads        : pthread_mutex_t, pthread_once_t

/* ═══════════════════════════════════════════════════════════════════════════════
 * CONFIGURATION
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @def   UDP_DEBUG_PRINT
 * @brief Compile-time switch to enable verbose UDP debug output.
 *
 *        Set to @c 1 during development to trace socket events.
 *        Set to @c 0 for production builds to suppress all UDP debug prints.
 */
#ifndef UDP_DEBUG_PRINT
#define UDP_DEBUG_PRINT 0
#endif

/**
 * @def   UDP_RECEIVE_TIMEOUT_MS
 * @brief Timeout in milliseconds for @c select() in the UDP receive loop.
 *
 *        A short timeout allows the loop to remain responsive and process
 *        burst packets without blocking indefinitely on an idle socket.
 */
#define UDP_RECEIVE_TIMEOUT_MS   10   ///< Receive poll timeout (milliseconds)

/* ═══════════════════════════════════════════════════════════════════════════════
 * MUTEX — THREAD-SAFE SEND PROTECTION
 * ═══════════════════════════════════════════════════════════════════════════════ */

static pthread_mutex_t udp_send_mutex;                        ///< Protects concurrent UDP sends
static pthread_once_t  mutex_init_once = PTHREAD_ONCE_INIT;  ///< Ensures mutex is initialised exactly once


/**
 * @brief   One-time initialisation function for the UDP send mutex.
 *
 * @details Called internally via @c pthread_once() the first time
 *          @c send_udp_json() is invoked. Guarantees the mutex is
 *          initialised exactly once regardless of thread call order.
 *
 * @note    This function is @c static — not part of the public API.
 *
 * @return  void
 */
static void init_udp_mutex(void) {
    pthread_mutex_init(&udp_send_mutex, NULL);
}


/* ═══════════════════════════════════════════════════════════════════════════════
 * FUNCTION IMPLEMENTATIONS
 * ═══════════════════════════════════════════════════════════════════════════════ */

/**
 * @brief   Initialise and bind a UDP socket to the specified port.
 *
 * @details Creates a @c SOCK_DGRAM socket, enables @c SO_REUSEADDR to allow
 *          rapid port reuse after restart, and binds to @c INADDR_ANY on the
 *          given port so the socket accepts packets on all network interfaces.
 *
 *          On any fatal error (invalid port, socket creation failure, bind
 *          failure), the function prints a diagnostic message and calls
 *          @c exit(EXIT_FAILURE).
 *
 * @param[in] port  UDP port number to bind (valid range: 1–65535).
 *
 * @note    Binding to @c INADDR_ANY accepts packets from all interfaces
 *          (Ethernet, Wi-Fi, loopback). Restrict to a specific IP if needed.
 *
 * @warning This function calls @c exit() on failure — ensure the port is
 *          valid before calling. Consider wrapping with error handling if
 *          graceful failure is required.
 *
 * @return  Valid socket file descriptor (≥ 0) on success.
 *          Never returns on failure — exits the process.
 */
int init_udp_socket(int port) {

    /* ── Port Validation ────────────────────────────────────────────────────
     * Reject port numbers outside the valid UDP range (1–65535).
     * Port 0 is reserved and must not be used for application binding.
     * ────────────────────────────────────────────────────────────────────── */
    if (port <= 0 || port > 65535) {
        fprintf(stderr, "[UDP INIT] Invalid port number: %d (valid range: 1–65535)\n", port);
        exit(EXIT_FAILURE);
    }

    int                sockfd;   ///< Socket file descriptor
    struct sockaddr_in addr;     ///< Bind address structure

    /* ── Create UDP Socket ──────────────────────────────────────────────────
     * AF_INET  = IPv4, SOCK_DGRAM = connectionless UDP, 0 = default protocol.
     * ────────────────────────────────────────────────────────────────────── */
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("[UDP INIT] Socket creation failed");
        exit(EXIT_FAILURE);
    }

    /* ── Enable SO_REUSEADDR ────────────────────────────────────────────────
     * Allows immediate port reuse after the process restarts, bypassing the
     * TIME_WAIT state that would otherwise block rebinding for ~60 seconds.
     * ────────────────────────────────────────────────────────────────────── */
    int opt = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("[UDP INIT] setsockopt(SO_REUSEADDR) failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    /* ── Configure Bind Address ─────────────────────────────────────────────
     * Bind to all interfaces (INADDR_ANY) on the specified port.
     * sin_port uses network byte order (big-endian) via htons().
     * ────────────────────────────────────────────────────────────────────── */
    addr.sin_family      = AF_INET;        /* IPv4                           */
    addr.sin_addr.s_addr = INADDR_ANY;     /* Accept on all interfaces       */
    addr.sin_port        = htons(port);    /* Convert port to network order  */

    /* ── Bind Socket ────────────────────────────────────────────────────────
     * Associates the socket with the configured address and port.
     * ────────────────────────────────────────────────────────────────────── */
    if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("[UDP INIT] Bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

#if UDP_DEBUG_PRINT
    printf("[UDP INIT] Socket bound successfully on port %d (fd=%d)\n", port, sockfd);
#endif

    return sockfd;
}


/**
 * @brief   Send a JSON-formatted string over UDP in a thread-safe manner.
 *
 * @details Resolves the destination address, acquires the send mutex, transmits
 *          the JSON string via @c sendto(), then releases the mutex. An optional
 *          post-send callback is invoked after the mutex is released.
 *
 *          Thread safety is guaranteed by a @c pthread_mutex_t initialised
 *          exactly once via @c pthread_once().
 *
 * @param[in] sockfd  UDP socket file descriptor (must be ≥ 0).
 * @param[in] json    Null-terminated JSON string to transmit. Must not be @c NULL.
 * @param[in] ip      Destination IPv4 address string (e.g., @c "192.168.3.51").
 *                    Must not be @c NULL.
 * @param[in] port    Destination UDP port (valid range: 1–65535).
 * @param[in] cb      Optional callback invoked after successful send.
 *                    Pass @c NULL if no post-send action is required.
 *
 * @note    The callback @p cb is invoked outside the mutex lock to prevent
 *          potential deadlocks if the callback itself calls @c send_udp_json().
 *
 * @warning Invalid @p ip strings (non-IPv4 format) will cause @c inet_pton()
 *          to fail and the function will return @c -1.
 *
 * @return   @c 0  on success.
 * @return  @c -1  on invalid arguments, address resolution failure, or send failure.
 */
int send_udp_json(int sockfd, const char *json, const char *ip, int port, on_send_cb cb) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Reject NULL pointers and invalid socket/port values early.
     * ────────────────────────────────────────────────────────────────────── */
    if (!json || !ip || port <= 0 || sockfd < 0) {
        fprintf(stderr, "[UDP SEND] Invalid arguments: json=%p, ip=%p, port=%d, sockfd=%d\n",
                (void *)json, (void *)ip, port, sockfd);
        return -1;
    }

    /* ── One-Time Mutex Initialisation ─────────────────────────────────────
     * pthread_once() guarantees init_udp_mutex() runs exactly once,
     * even if multiple threads call send_udp_json() concurrently.
     * ────────────────────────────────────────────────────────────────────── */
    pthread_once(&mutex_init_once, init_udp_mutex);
    pthread_mutex_lock(&udp_send_mutex);

    /* ── Build Destination Address ──────────────────────────────────────────
     * inet_pton() converts the dotted-decimal IP string to binary form.
     * Returns 1 on success, 0 if string is invalid, -1 on system error.
     * ────────────────────────────────────────────────────────────────────── */
    struct sockaddr_in dest;
    memset(&dest, 0, sizeof(dest));
    dest.sin_family = AF_INET;
    dest.sin_port   = htons(port);

    if (inet_pton(AF_INET, ip, &dest.sin_addr) <= 0) {
        fprintf(stderr, "[UDP SEND] Invalid IP address: %s\n", ip);
        pthread_mutex_unlock(&udp_send_mutex);
        return -1;
    }

    /* ── Transmit JSON Payload ──────────────────────────────────────────────
     * sendto() sends the JSON string as a single UDP datagram.
     * Returns the number of bytes sent, or -1 on failure.
     * ────────────────────────────────────────────────────────────────────── */
    ssize_t sent_bytes = sendto(sockfd, json, strlen(json), 0,
                                (struct sockaddr *)&dest, sizeof(dest));
    if (sent_bytes == -1) {
        perror("[UDP SEND] sendto() failed");
        pthread_mutex_unlock(&udp_send_mutex);
        return -1;
    }

#if UDP_DEBUG_PRINT
    printf("[UDP SEND] Sent %zd bytes to %s:%d → %s\n", sent_bytes, ip, port, json);
#endif

    pthread_mutex_unlock(&udp_send_mutex);

    /* ── Invoke Post-Send Callback (outside mutex) ──────────────────────────
     * Called after releasing the mutex to avoid potential deadlocks if
     * the callback itself triggers another UDP send.
     * ────────────────────────────────────────────────────────────────────── */
    if (cb) cb(json, &dest);

    return 0;
}


/**
 * @brief   Poll for incoming UDP packets and dispatch each to a callback.
 *
 * @details Uses @c select() with a short timeout (@c UDP_RECEIVE_TIMEOUT_MS)
 *          to non-blocking poll the socket. When data is available,
 *          @c recvfrom() reads the packet and the callback is invoked with
 *          the payload and sender address.
 *
 *          The short timeout prevents indefinite blocking, allowing burst
 *          packets to be processed rapidly without CPU spinning.
 *
 *          Loop behaviour:
 *          @code
 *          loop:
 *            select() → timeout?  → continue polling
 *                     → data?     → recvfrom() → cb(buffer, &sender)
 *                     → error?    → perror + break
 *          @endcode
 *
 * @param[in] sockfd  Valid UDP socket file descriptor (must be ≥ 0).
 * @param[in] cb      Callback invoked for each received packet.
 *                    Signature: @c void cb(const char *data, struct sockaddr_in *sender).
 *                    Must not be @c NULL.
 *
 * @note    This function blocks indefinitely (until a @c select() error).
 *          It is intended to run in a dedicated receiver thread.
 *
 * @warning The function exits its loop only on a @c select() error.
 *          Normal timeout and idle states continue polling silently.
 *
 * @return  void
 */
void wait_for_udp(int sockfd, on_receive_cb cb) {

    /* ── Input Validation ───────────────────────────────────────────────────
     * Reject invalid socket descriptor or NULL callback before entering loop.
     * ────────────────────────────────────────────────────────────────────── */
    if (sockfd < 0 || cb == NULL) {
        fprintf(stderr, "[UDP RECV] Invalid arguments: sockfd=%d, cb=%p\n",
                sockfd, (void *)cb);
        return;
    }

    fd_set             read_fds;          ///< File descriptor set for select()
    struct sockaddr_in sender;            ///< Stores sender IP and port per packet
    socklen_t          addrlen = sizeof(sender);  ///< Size of sender address structure
    char               buffer[MAX_BUFFER];        ///< Receive buffer for incoming data

    /* ── Continuous Receive Loop ────────────────────────────────────────────
     * Poll the socket repeatedly using select() with a short timeout.
     * Exits only on a select() error.
     * ────────────────────────────────────────────────────────────────────── */
    while (1) {

        /* ── Prepare fd_set for select() ────────────────────────────────────
         * FD_ZERO clears the set; FD_SET adds our socket for monitoring.
         * Must be re-initialised every iteration — select() modifies the set.
         * ────────────────────────────────────────────────────────────────── */
        FD_ZERO(&read_fds);
        FD_SET(sockfd, &read_fds);

        /* ── Configure Timeout ──────────────────────────────────────────────
         * tv_sec  = 0 seconds
         * tv_usec = UDP_RECEIVE_TIMEOUT_MS * 1000 microseconds
         * Must be re-set every iteration — select() may modify it on Linux.
         * ────────────────────────────────────────────────────────────────── */
        struct timeval timeout = { 0, UDP_RECEIVE_TIMEOUT_MS * 1000 };

        int ready = select(sockfd + 1, &read_fds, NULL, NULL, &timeout);

        if (ready > 0 && FD_ISSET(sockfd, &read_fds)) {

            /* ── Read Incoming Packet ────────────────────────────────────────
             * recvfrom() fills buffer with payload and sender with source addr.
             * Null-terminate before passing to the callback.
             * ────────────────────────────────────────────────────────────── */
            int len = recvfrom(sockfd, buffer, MAX_BUFFER - 1, 0,
                               (struct sockaddr *)&sender, &addrlen);
            if (len >= 0) {
                buffer[len] = '\0';   /* Null-terminate received string */

#if UDP_DEBUG_PRINT
                printf("[UDP RECV] %d bytes from %s:%d → %s\n",
                       len,
                       inet_ntoa(sender.sin_addr),
                       ntohs(sender.sin_port),
                       buffer);
#endif
                /* Dispatch payload and sender info to user callback */
                cb(buffer, &sender);
            }

        } else if (ready < 0) {

            /* ── select() Error ──────────────────────────────────────────────
             * A negative return indicates a system-level socket error.
             * Break the loop — caller's thread should handle recovery.
             * ────────────────────────────────────────────────────────────── */
            perror("[UDP RECV] select() error");
            break;
        }

        /* Timeout (ready == 0): no data available — continue polling silently */
    }
}