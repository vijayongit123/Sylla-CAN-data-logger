#ifndef DATAHANDLER_H
#define DATAHANDLER_H

/**
 * @file datahandler.h
 * @brief Header file containing utilities for timestamp generation, JSON logging,
 *        USB data processing, and UDP JSON message routing.
 */

// ------------------------------
// Function Prototypes
// ------------------------------

/**
 * @brief Generates a timestamp string with millisecond precision.
 *
 * @param buffer Pointer to a character array where the formatted timestamp will be written.
 * @param size   Size of the buffer to prevent overflow.
 */
void get_timestamp(char *buffer, size_t size);

/**
 * @brief Logs JSON-formatted data to a log file and optionally prints it.
 *
 * @param data        The JSON-formatted string to log.
 * @param target_ip   The destination IP address associated with the message.
 * @param target_port The destination port number associated with the message.
 */
void JSON_datalog(const char *data);


/**
 * @brief Processes raw USB data received and handles decoding/parsing logic.
 *
 * @param data Pointer to the raw data buffer.
 * @param len  Length of the data in bytes.
 */
void process_usb_data(uint8_t *data, int len);

/**
 * @brief Converts motor controller USB data into a formatted JSON string.
 *
 * @param USBdata   Pointer to the USB frame data received from the motor controller.
 * @param json      Pointer to the buffer where the resulting JSON string will be written.
 * @param json_size Size of the json buffer to prevent overflow.
 */
void mc_JSONdata(uint8_t *USBdata, char *json, size_t json_size);

/**
 * @brief Converts USB frame data into a JSON string for Battery Management System (BMS) messages.
 *
 * This function parses raw USB data received from the BMS module and formats it into
 * a structured JSON string. The JSON typically includes timestamp, ID, frame length,
 * and decoded BMS parameters such as voltage, current, temperature, and fault codes.
 *
 * @param USBdata    Pointer to the raw USB frame data received from the BMS.
 * @param json       Pointer to the output buffer where the formatted JSON string will be stored.
 * @param json_size  Size of the output JSON buffer, used to prevent overflow.
 */
void bms_JSONdata(uint8_t *USBdata, char *json, size_t json_size);

#endif // DATAHANDLER_H
