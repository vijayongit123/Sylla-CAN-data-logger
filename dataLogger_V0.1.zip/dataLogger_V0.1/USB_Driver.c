
/**
 * @file USB_Driver.c
 * @brief Implementation of USB serial communication using libudev and POSIX APIs.
 *
 * This source file provides the implementation for USB initialization, data transmission,
 * reception, and dynamic monitoring of USB devices (e.g., CH340-based USB-to-serial converters).
 * It also manages threading, I/O polling, and callback-based data handling.
 */
// --------------------------------------------------------------------------------------------------
// USB Interface Implementation for Serial Communication
// --------------------------------------------------------------------------------------------------

#include <fcntl.h>      /**< For file control options (open, O_RDWR, O_NOCTTY, etc.) */
#include <termios.h>    /**< For terminal I/O control (baud rate, parity, etc.) */
#include <unistd.h>     /**< For POSIX system calls (read, write, close, etc.) */
#include <string.h>     /**< For string manipulation functions (memset, strcmp, etc.) */
#include <errno.h>      /**< For error reporting and error codes (errno values) */
#include <poll.h>       /**< For polling file descriptors for readiness (poll()) */
#include <pthread.h>    /**< For multi-threading and synchronization (pthread APIs) */

#include "USB_Driver.h" /**< Header file containing declarations for USB driver functions */

// --------------------------------------------------------------------------------------------------
// Global Variables
// --------------------------------------------------------------------------------------------------

/**
 * @brief Global variables for USB driver management and synchronization.
 *
 * These variables handle USB device state, threading, synchronization, and udev monitoring.
 * They are shared across internal USB driver functions and used for maintaining communication
 * between the USB device and the main application.
 */

/** 
 * @var int usb_fd
 * @brief File descriptor for the USB serial device.
 *
 * Initialized to -1 (invalid). Set when a USB device is successfully opened.
 */
int usb_fd = -1;

/** 
 * @var pthread_t rx_thread_id
 * @brief Thread ID for the USB receive thread.
 *
 * Used to manage and join the RX thread that continuously reads incoming USB data.
 */
pthread_t rx_thread_id = 0;

/** 
 * @var volatile bool running
 * @brief Control flag for USB operations.
 *
 * Used to signal threads (e.g., RX thread) to continue or terminate.
 * Declared volatile to ensure visibility across threads.
 */
volatile bool running = true;

/** 
 * @var static data_received_callback USB_callback
 * @brief Function pointer to the user-defined USB data receive callback.
 *
 * When new data arrives from the USB device, this callback is invoked.
 */
static data_received_callback USB_callback = NULL;

/** 
 * @var static struct udev *udev_ctx
 * @brief Pointer to the global udev context.
 *
 * Used for USB device enumeration and monitoring events (connect/disconnect).
 */
static struct udev *udev_ctx = NULL;

/** 
 * @var static struct udev_monitor *udev_monitor
 * @brief Pointer to the global udev monitor instance.
 *
 * Used to listen for "tty" subsystem events (e.g., /dev/ttyUSBx plug/unplug).
 */
static struct udev_monitor *udev_monitor = NULL;

/** 
 * @var static pthread_mutex_t usb_send_mutex
 * @brief Mutex for thread-safe USB data transmission.
 *
 * Ensures that multiple threads do not write to the USB device simultaneously.
 */
static pthread_mutex_t usb_send_mutex = PTHREAD_MUTEX_INITIALIZER;


// --------------------------------------------------------------------------------------------------
// Set the callback to be invoked when USB motor data is received
// --------------------------------------------------------------------------------------------------
/**
 * @brief Registers a user-defined callback function for USB data reception.
 *
 * This function allows the application to specify a callback that will be
 * invoked whenever data is received from the USB device. The callback is
 * stored in a global pointer (`USB_callback`) and later called from the
 * receive thread when new data becomes available.
 *
 * @param[in] callback  Pointer to a user-defined function of type 
 *                      `data_received_callback`. If NULL is passed, the 
 *                      function will issue a warning (in debug mode) and 
 *                      return without registering.
 *
 * @note The callback must remain valid for the lifetime of the USB driver.
 *       Passing a NULL pointer disables any previously set callback.
 *
 * @return None
 */
void set_usb_data_callback(data_received_callback callback)
{
    // Validate callback pointer
    if (callback == NULL) {
#if USB_DEBUG_PRINT
        fprintf(stderr, "[USB] Warning: NULL callback passed to set_usb_data_callback.\n");
#endif
        return;
    }

    // Assign user callback for USB data handling
    USB_callback = callback;

#if USB_DEBUG_PRINT
    printf("[USB] USB data receive callback successfully registered.\n");
#endif
}

// --------------------------------------------------------------------------------------------------
// Helper: Check if udev device matches target USB vendor/product
// --------------------------------------------------------------------------------------------------
/**
 * @brief Check if the given udev device matches the configured vendor and product ID.
 *
 * This function inspects the parent USB device of a tty node to verify whether
 * it matches the predefined TARGET_VENDOR and TARGET_PRODUCT.
 *
 * @param[in] dev  udev device to evaluate.
 * @return 1 if the device matches, 0 otherwise.
 */
static int USB_target_device(struct udev_device *dev) {
    if (!dev) return 0;

    struct udev_device *usb_dev = udev_device_get_parent_with_subsystem_devtype(dev, "usb", "usb_device");
    if (usb_dev) {
        const char *vendor  = udev_device_get_sysattr_value(usb_dev, "idVendor");
        const char *product = udev_device_get_sysattr_value(usb_dev, "idProduct");

        if (vendor && product &&
            strcmp(vendor, TARGET_VENDOR) == 0 &&
            strcmp(product, TARGET_PRODUCT) == 0) {
#if USB_DEBUG_PRINT
            printf("[USB] Found matching USB device: vendor=%s, product=%s\n", vendor, product);
#endif
            return 1; // Match found
        } else {
#if USB_DEBUG_PRINT
            printf("[USB] Skipped device: vendor=%s, product=%s\n", vendor, product);
#endif
        }
    }

    return 0; // No match
}

// --------------------------------------------------------------------------------------------------
// Search for the matching USB serial device (based on vendor/product)
// --------------------------------------------------------------------------------------------------
/**
 * @brief Scan and return the device node path of the target USB serial port.
 *
 * This function performs udev enumeration of tty devices and uses is_target_device()
 * to identify the USB serial device matching the vendor/product criteria.
 *
 * @note Consider exposing this function publicly or integrating it into usb_run()
 *       to dynamically resolve USB device paths instead of hardcoding.
 *
 * @return Allocated string containing the device path (e.g., "/dev/ttyUSB0"), or NULL on failure.
 */
static char *find_target_usb_serial() {
    struct udev *udev = udev_new();
    if (!udev) {
        fprintf(stderr, "[USB] Failed to initialize udev in find_target_usb_serial.\n");
        return NULL;
    }

    struct udev_enumerate *enumerate = udev_enumerate_new(udev);
    if (!enumerate) {
        fprintf(stderr, "[USB] Failed to create udev enumerate context.\n");
        udev_unref(udev);
        return NULL;
    }

    udev_enumerate_add_match_subsystem(enumerate, "tty");
    udev_enumerate_scan_devices(enumerate);

    struct udev_list_entry *devices = udev_enumerate_get_list_entry(enumerate);
    struct udev_list_entry *dev_list_entry;
    char *target_devnode = NULL;

    udev_list_entry_foreach(dev_list_entry, devices) {
        const char *path = udev_list_entry_get_name(dev_list_entry);
        struct udev_device *dev = udev_device_new_from_syspath(udev, path);
        if (!dev) continue;

        if (USB_target_device(dev)) {
            const char *devnode = udev_device_get_devnode(dev);
            if (devnode) {
                target_devnode = strdup(devnode);
#if USB_DEBUG_PRINT
                printf("[USB] Target USB serial found: %s\n", devnode);
#endif
                udev_device_unref(dev);
                break;
            }
        }

        udev_device_unref(dev);
    }

    udev_enumerate_unref(enumerate);
    udev_unref(udev);

    if (!target_devnode) {
#if USB_DEBUG_PRINT
        printf("[USB] No matching USB serial device found.\n");
#endif
    }

    return target_devnode;
}


/**
 * @brief Configure and open the USB serial port.
 *
 * This function opens the specified device file and configures it with the appropriate
 * termios settings for raw 8N1 serial communication at the configured baud rate.
 * If any step fails, the file descriptor is closed and -1 is returned.
 *
 * @param[in] device  The path to the USB serial device (e.g., "/dev/ttyUSB0").
 * @return 0 on success, -1 on failure.
 */
static int configure_serial_port(const char *device) {
    if (device == NULL) {
#if USB_DEBUG_PRINT
        fprintf(stderr, "[USB] Error: NULL device path provided to configure_serial_port().\n");
#endif
        return -1;
    }

    usb_fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY);
    if (usb_fd < 0) {
        perror("[USB] Error opening USB device");
        return -1;
    }

    struct termios tty;
    memset(&tty, 0, sizeof(tty));

    // Retrieve current terminal settings
    if (tcgetattr(usb_fd, &tty) != 0) {
        perror("[USB] Error from tcgetattr");
        close(usb_fd);
        usb_fd = -1;
        return -1;
    }

    // Set raw mode
    cfmakeraw(&tty);

    // Set baud rate
    speed_t baud_rate;
    switch (BAUD_RATE_VALUE) {
        case 9600: baud_rate = B9600; break;
        case 19200: baud_rate = B19200; break;
        case 38400: baud_rate = B38400; break;
        case 57600: baud_rate = B57600; break;
        case 115200: baud_rate = B115200; break;
        case 2000000: baud_rate = B2000000; break;
        default:
#if USB_DEBUG_PRINT
            fprintf(stderr, "[USB] Unsupported baud rate: %d\n", BAUD_RATE_VALUE);
#endif
            close(usb_fd);
            usb_fd = -1;
            return -1;
    }

    printf("[USB] baud rate: %d\n", BAUD_RATE_VALUE);
    // Apply baud rate to input and output
    if (cfsetispeed(&tty, baud_rate) != 0 || cfsetospeed(&tty, baud_rate) != 0) {
        perror("[USB] Error setting baud rate");
        close(usb_fd);
        usb_fd = -1;
        return -1;
    }

    // Configure 8N1 (8 data bits, no parity, 1 stop bit)
    tty.c_cflag |= (CLOCAL | CREAD);  // Enable receiver, ignore modem control lines
    tty.c_cflag &= ~CSIZE;            // Clear size mask
    tty.c_cflag |= CS8;               // 8-bit characters
    tty.c_cflag &= ~PARENB;           // No parity
    tty.c_cflag &= ~CSTOPB;           // 1 stop bit
    tty.c_cflag &= ~CRTSCTS;          // Disable hardware flow control

    // Set non-canonical mode (no echo or line processing)
    tty.c_lflag = 0;
    tty.c_iflag = 0;
    tty.c_oflag = 0;

    // Minimum characters to read / timeout
    tty.c_cc[VMIN]  = 1;   // At least one character
    tty.c_cc[VTIME] = 1;   // Timeout in deciseconds

    // Flush input buffer before applying settings
    tcflush(usb_fd, TCIFLUSH);

    // Apply the new attributes immediately
    if (tcsetattr(usb_fd, TCSANOW, &tty) != 0) {
        perror("[USB] Error setting term attributes");
        close(usb_fd);
        usb_fd = -1;
        return -1;
    }

    // Set to blocking mode
    if (fcntl(usb_fd, F_SETFL, 0) == -1) {
#if USB_DEBUG_PRINT
        fprintf(stderr, "[USB] Warning: failed to set blocking mode.\n");
#endif
    }

#if USB_DEBUG_PRINT
    printf("[USB] Serial port %s configured at %d baud.\n", device, BAUD_RATE_VALUE);
#endif
    return 0;
}


/**
 * @brief USB receive thread to handle incoming data from serial port.
 *
 * This thread continuously reads from the configured USB serial device.
 * If data is received, it is forwarded to the user-defined callback function.
 * In case of a disconnection or read error, the thread logs an error and exits.
 *
 * @param[in] arg Unused thread argument.
 * @return NULL when the thread exits.
 */
static void *USB_rx_thread(void *arg) {
    unsigned char usb_rx_buffer[256];  // Buffer to store incoming USB data
    int received_bytes;                // Number of bytes received from read()

    while (running) {
        if (usb_fd >= 0) {
            received_bytes = read(usb_fd, usb_rx_buffer, sizeof(usb_rx_buffer));

            if (received_bytes > 0) {
#if USB_DEBUG_PRINT
                printf("[USB RX] Received %d bytes: ", received_bytes);
                for (int i = 0; i < received_bytes; ++i) {
                    printf("%02X ", usb_rx_buffer[i]);
                }
                printf("\n");
#endif
                // Pass received data to user-defined callback
                if (USB_callback != NULL) {
                    USB_callback(usb_rx_buffer, received_bytes);
                }
            } else if (received_bytes == 0) {
                // No data received, sleep briefly to reduce CPU load
                usleep(10000); // 10ms
            } else {
                // Read error (likely device disconnected)
                perror("[USB RX] Error reading from USB");
                close(usb_fd);
                usb_fd = -1;
#if USB_DEBUG_PRINT
                fprintf(stderr, "[USB RX] Disconnected, stopping thread.\n");
#endif
                break; // Exit thread
            }
        } else {
            // Device not connected, sleep before retrying
            sleep(RECONNECT_DELAY_SEC);
        }
    }

    return NULL;
}



/**
 * @brief Transmit data over the USB serial interface in a thread-safe manner.
 *
 * This function sends a buffer of data over the USB connection to the currently
 * opened USB device. It handles partial writes and retries until all data is sent.
 * A mutex is used to protect against concurrent write access from multiple threads.
 *
 * @param[in] data   Pointer to the data buffer to send.
 * @param[in] length Number of bytes to send from the buffer.
 * @return Number of bytes successfully written, or -1 on error.
 */
int usb_send_data(const unsigned char *data, int length) {
    // Check if USB is properly initialized
    if (usb_fd < 0) {
        fprintf(stderr, "[USB SEND] USB not opened\n");
        return -1;
    }

    // Validate input arguments
    if (data == NULL || length <= 0) {
        fprintf(stderr, "[USB SEND] Invalid data or length\n");
        return -1;
    }

    pthread_mutex_lock(&usb_send_mutex); // Lock before writing

    int total_written = 0;

    // Continue writing until all data has been sent
    while (total_written < length) {
        int written = write(usb_fd, data + total_written, length - total_written);
        if (written < 0) {
            perror("[USB SEND] Error writing to USB");
            pthread_mutex_unlock(&usb_send_mutex); // Unlock before returning
            return -1;
        }
        total_written += written;
    }

    pthread_mutex_unlock(&usb_send_mutex); // Unlock after writing

#if USB_DEBUG_PRINT
    printf("[USB SEND] Sent %d bytes: ", total_written);
    for (int i = 0; i < total_written; i++) {
        printf("%02X ", data[i]);
    }
    printf("\n");
#endif

    return total_written;
}


/**
 * @brief Initialize USB monitoring infrastructure using libudev.
 *
 * This function sets up the udev context and monitor to listen for
 * USB device events (e.g., connection or disconnection of serial devices).
 * It filters for the "tty" subsystem to monitor USB serial devices.
 *
 * @return true on successful initialization, false otherwise.
 */
bool usb_init() {
    printf("[USB INIT] Initializing USB monitoring...");

    // Cleanup existing udev context and monitor if already initialized
    if (udev_ctx) {
        udev_unref(udev_ctx);
        udev_ctx = NULL;
    }
    if (udev_monitor) {
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
    }

    // Create new udev context
    udev_ctx = udev_new();
    if (!udev_ctx) {
        fprintf(stderr, "[USB INIT] Failed to initialize udev context.\n");
        return false;
    }

    // Create a new udev monitor that listens to kernel udev events
    udev_monitor = udev_monitor_new_from_netlink(udev_ctx, "udev");
    if (!udev_monitor) {
        fprintf(stderr, "[USB INIT] Failed to create udev monitor.\n");
        udev_unref(udev_ctx);
        udev_ctx = NULL;
        return false;
    }

    // Filter only TTY devices (e.g., USB serial ports)
    if (udev_monitor_filter_add_match_subsystem_devtype(udev_monitor, "tty", NULL) < 0) {
        fprintf(stderr, "[USB INIT] Failed to add monitor filter for tty devices.\n");
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
        udev_unref(udev_ctx);
        udev_ctx = NULL;
        return false;
    }

    // Start receiving udev events
    if (udev_monitor_enable_receiving(udev_monitor) < 0) {
        fprintf(stderr, "[USB INIT] Failed to enable udev event receiving.\n");
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
        udev_unref(udev_ctx);
        udev_ctx = NULL;
        return false;
    }

#if USB_DEBUG_PRINT
    printf("[USB INIT] USB monitoring successfully initialized.\n");
#endif

    return true;
}



/**
 * @brief Clean up USB resources and stop related threads.
 *
 * This function safely deallocates and closes all USB-related resources, such as
 * udev monitor, udev context, and USB file descriptor. It also signals the receiving
 * thread to terminate and waits for it to join if needed.
 */
void usb_cleanup() {
    printf("[USB CLEANUP] Cleaning up USB resources...\n");

    // Stop the RX thread loop
    running = false;

    // Release udev monitor if initialized
    if (udev_monitor) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Releasing udev monitor...\n");
#endif
        udev_monitor_unref(udev_monitor);
        udev_monitor = NULL;
    }

    // Release udev context if initialized
    if (udev_ctx) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Releasing udev context...\n");
#endif
        udev_unref(udev_ctx);
        udev_ctx = NULL;
    }

    // Close USB file descriptor if open
    if (usb_fd >= 0) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Closing USB file descriptor: %d\n", usb_fd);
#endif
        close(usb_fd);
        usb_fd = -1;
    }

    // Ensure RX thread is properly joined (if not calling itself)
    if (pthread_self() != rx_thread_id && rx_thread_id != 0) {
#if USB_DEBUG_PRINT
        printf("[USB CLEANUP] Waiting for RX thread to terminate...\n");
#endif
        pthread_join(rx_thread_id, NULL);
        rx_thread_id = 0;
    }

#if USB_DEBUG_PRINT
    printf("[USB CLEANUP] USB cleanup completed.\n");
#endif
}

/**
 * @brief Run the main USB communication loop.
 *
 * This function manages USB device connection, disconnection, and data reception
 * by initializing the serial port and monitoring device status via udev.
 * It handles creating and terminating the receive (RX) thread based on device state.
 *
 * @param[in] device_path The fixed path of the USB serial device (e.g., /dev/ttyUSB0).
 */
void usb_run(const char *device_path) {
    int rx_thread_created = 0;
    int monitor_fd = udev_monitor_get_fd(udev_monitor);

    while (running) {
        // Attempt to open the serial port if not already open
        if (usb_fd < 0) {
#if USB_DEBUG_PRINT
            printf("[USB RUN] Attempting to open device: %s\n", device_path);
#endif
            if (configure_serial_port(device_path) == 0) {
#if USB_DEBUG_PRINT
                printf("[USB RUN] USB serial port opened on %s\n", device_path);
#endif
                // Start RX thread if not already running
                if (!rx_thread_created) {
                    if (pthread_create(&rx_thread_id, NULL, USB_rx_thread, NULL) == 0) {
#if USB_DEBUG_PRINT
                        printf("[USB RUN] RX thread started.\n");
#endif
                        rx_thread_created = 1;
                    } else {
                        perror("[USB RUN] Failed to create RX thread");
                        close(usb_fd);
                        usb_fd = -1;
                        sleep(RECONNECT_DELAY_SEC);
                        continue;
                    }
                }
            } else {
                if (usb_fd >= 0) {
                    close(usb_fd);
                    usb_fd = -1;
                }

                perror("[USB RUN] Error configuring serial port");
#if USB_DEBUG_PRINT
                fprintf(stderr, "[USB RUN] Retrying in %d seconds...\n", RECONNECT_DELAY_SEC);
#endif
                sleep(RECONNECT_DELAY_SEC);
                continue;
            }
        }

        // Periodically verify if USB port is still connected
        if (usb_fd >= 0) {
            struct termios test_attr;
            if (tcgetattr(usb_fd, &test_attr) != 0) {
                perror("[USB RUN] USB port disconnected");
                close(usb_fd);
                usb_fd = -1;

                if (rx_thread_created) {
                    pthread_cancel(rx_thread_id);
                    pthread_join(rx_thread_id, NULL);
                    rx_thread_created = 0;
#if USB_DEBUG_PRINT
                    printf("[USB RUN] RX thread terminated due to disconnect.\n");
#endif
                }
#if USB_DEBUG_PRINT
                fprintf(stderr, "[USB RUN] Waiting for USB device to reconnect...\n");
#endif
                sleep(RECONNECT_DELAY_SEC);
                continue;
            }
        }

        // Monitor udev for USB plug/unplug events
        struct pollfd fds[1];
        fds[0].fd = monitor_fd;
        fds[0].events = POLLIN;

        int poll_ret = poll(fds, 1, UDEV_MONITOR_TIMEOUT);

        if (poll_ret > 0 && (fds[0].revents & POLLIN)) {
            struct udev_device *dev = udev_monitor_receive_device(udev_monitor);
            if (dev) {
                const char *action = udev_device_get_action(dev);
                const char *devnode = udev_device_get_devnode(dev);
                if (action && devnode) {
#if USB_DEBUG_PRINT
                    printf("[USB RUN] Udev event: %s on %s\n", action, devnode);
#endif
                }
                udev_device_unref(dev);
            }
        } else if (poll_ret < 0) {
            perror("[USB RUN] poll() error");
            break;
        }

        sleep(1); // Brief pause to reduce CPU load
    }

    // Cleanup RX thread and close USB if still active
    if (rx_thread_created) {
        pthread_cancel(rx_thread_id);
        pthread_join(rx_thread_id, NULL);
        rx_thread_created = 0;
    }

    if (usb_fd >= 0) {
        close(usb_fd);
        usb_fd = -1;
    }

#if USB_DEBUG_PRINT
    printf("[USB RUN] Exiting USB run loop.\n");
#endif
}
