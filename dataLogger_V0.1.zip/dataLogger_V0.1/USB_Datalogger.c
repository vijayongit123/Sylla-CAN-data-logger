/**
 * @file USB_Datalogger.c
 * @brief Main application file for handling USB communication and data logging.
 *
 * This file integrates USB communication using `USB_Driver.h` and 
 * logs or processes received CAN/USB frame data via `USB_Datalogger.h`.
 * It includes standard system headers required for networking, threading, 
 * file handling, and general-purpose operations.
 */

#include <stdio.h>      ///< Standard I/O functions (e.g., printf, fprintf, fopen)
#include <string.h>     ///< String manipulation utilities (e.g., memcpy, strcmp)
#include <stdlib.h>     ///< General utilities (e.g., malloc, free, atoi)
#include <arpa/inet.h>  ///< Definitions for internet operations (e.g., htons, inet_ntoa)
#include <pthread.h>    ///< POSIX threads for concurrent execution
#include <unistd.h>     ///< POSIX API for system calls (e.g., read, write, close)
#include <stdbool.h>    ///< Boolean type support (`true`, `false`)
#include <sys/stat.h>   ///< File and directory status operations (e.g., mkdir, stat)
#include <sys/types.h>  ///< System data type definitions (used by many system calls)

#include "USB_Driver.h"        ///< Custom USB interface header for communication and monitoring.
#include "USB_Datalogger.h"    ///< Header for USB data logging and CAN frame processing.
// ============================================================================
//                              CONFIGURATION CONSTANTS
// ============================================================================

/**
 * @def DEBUG_LOGS
 * @brief Enable or disable debug log printing throughout the module.
 *
 * Set this macro to `1` to enable detailed debug output for troubleshooting,
 * or `0` to disable all debug print statements in production builds.
 *
 * @note When enabled, log messages are printed to `stderr` or `stdout`
 * depending on the function’s implementation.
 */
#define DEBUG_LOGS 0


/**
 * @brief Generate a formatted timestamp string with millisecond precision.
 *
 * This function retrieves the current system time and formats it into a
 * human-readable timestamp string with millisecond accuracy.
 *
 * **Format:** `YYYY-MM-DD HH:MM:SS.mmm`
 *
 * Example output:
 * ```
 * 2025-11-03 15:42:19.124
 * ```
 *
 * @param[out] buffer Pointer to a character array where the formatted timestamp will be stored.
 * @param[in]  size   Size of the buffer in bytes. Must be at least 24 bytes
 *                    to store the full timestamp string and null terminator.
 *
 * @note
 * - Uses `clock_gettime(CLOCK_REALTIME)` for nanosecond precision.
 * - Converts to local time using `localtime()`.
 * - If an error occurs, the buffer will be set to an empty string.
 */
void get_timestamp(char *buffer, size_t size) {
    // Validate input parameters to ensure safe operation
    if (buffer == NULL || size < 24) {  // 23 chars + null terminator
#if DEBUG_LOGS
        fprintf(stderr, "[ERROR] Invalid buffer or insufficient size in get_timestamp().\n");
#endif
        return;
    }

    struct timespec ts;   ///< Structure to hold seconds and nanoseconds
    struct tm *tm_info;   ///< Structure to hold converted local time components

    // Retrieve the current system time with nanosecond resolution
    if (clock_gettime(CLOCK_REALTIME, &ts) != 0) {
#if DEBUG_LOGS
        perror("[ERROR] clock_gettime() failed in get_timestamp()");
#endif
        buffer[0] = '\0';
        return;
    }

    // Convert time to local timezone representation
    tm_info = localtime(&ts.tv_sec);
    if (tm_info == NULL) {
#if DEBUG_LOGS
        perror("[ERROR] localtime() conversion failed in get_timestamp()");
#endif
        buffer[0] = '\0';
        return;
    }

    // Format the timestamp: YYYY-MM-DD HH:MM:SS.mmm
    snprintf(buffer, size, "%04d-%02d-%02d %02d:%02d:%02d.%03ld",
             tm_info->tm_year + 1900,
             tm_info->tm_mon + 1,
             tm_info->tm_mday,
             tm_info->tm_hour,
             tm_info->tm_min,
             tm_info->tm_sec,
             ts.tv_nsec / 1000000);  // Convert nanoseconds to milliseconds
}

/**
 * @brief Write a JSON-formatted string to a uniquely named log file.
 *
 * This function logs incoming JSON data to a timestamped file within the
 * `Flight_Testdata` directory. Each program execution creates a new file
 * named using the format:
 * ```
 * MC_YYYYMMDD_HHMMSS.txt
 * ```
 * All JSON entries are appended sequentially, one per line.
 *
 * Example:
 * ```
 * Flight_Testdata/MC_20251103_162045.txt
 * ```
 *
 * @param[in] data  Pointer to a null-terminated JSON string to be logged.
 *
 * @details
 * - Creates the directory `Flight_Testdata` if it does not already exist.
 * - The log file name is generated **once per program run**.
 * - Each subsequent log entry is appended to the same file.
 * - If file creation fails, an error message is printed (when `ENABLE_PRINT_LOG_USB` is enabled).
 *
 * @note This function is thread-safe if invoked from a single writer thread.
 * For concurrent logging, a file write mutex is recommended.
 */
void JSON_datalog(const char *data) {
    // === Input Validation ===
    // Ensure the provided data pointer is valid
    if (!data) {
#if DEBUG_LOGS
        fprintf(stderr, "[ERROR] Invalid argument in JSON_datalog().\n");
#endif
        return;
    }

    // === Ensure Log Directory Exists ===
    // Create "Flight_Testdata" directory with full permissions if missing
    mkdir("Flight_Testdata", 0777);

    // === Generate Timestamped Filename (Once Per Program Run) ===
    static char filename[128] = {0};  ///< Static buffer to store the log file path
    if (filename[0] == '\0') {
        time_t now = time(NULL);          ///< Current system time
        struct tm *t = localtime(&now);   ///< Local time structure
        snprintf(filename, sizeof(filename),
                 "Flight_Testdata/MC_%04d%02d%02d_%02d%02d%02d.txt",
                 t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
                 t->tm_hour, t->tm_min, t->tm_sec);
    }

    // === Open Log File in Append Mode ===
    FILE *file = fopen(filename, "a");
    if (file) {
        // Write the JSON string followed by a newline
        fprintf(file, "%s\n", data);
        fclose(file);
    } else {
#if ENABLE_PRINT_LOG_USB
        fprintf(stderr, "[ERROR] Could not open %s for writing.\n", filename);
#endif
    }
}

/**
 * @brief Write a JSON-formatted string to a uniquely named log file.
 *
 * This function logs incoming JSON data to a timestamped file within the
 * `Flight_Testdata` directory. Each program execution creates a new file
 * named using the format:
 * ```
 * MC_YYYYMMDD_HHMMSS.txt
 * ```
 * All JSON entries are appended sequentially, one per line.
 *
 * Example:
 * ```
 * Flight_Testdata/MC_20251103_162045.txt
 * ```
 *
 * @param[in] data  Pointer to a null-terminated JSON string to be logged.
 *
 * @details
 * - Creates the directory `Flight_Testdata` if it does not already exist.
 * - The log file name is generated **once per program run**.
 * - Each subsequent log entry is appended to the same file.
 * - If file creation fails, an error message is printed (when `ENABLE_PRINT_LOG_USB` is enabled).
 *
 * @note This function is thread-safe if invoked from a single writer thread.
 * For concurrent logging, a file write mutex is recommended.
 */
void BMS_JSON_datalog(const char *data) {
    // === Input Validation ===
    // Ensure the provided data pointer is valid
    if (!data) {
#if DEBUG_LOGS
        fprintf(stderr, "[ERROR] Invalid argument in JSON_datalog().\n");
#endif
        return;
    }

    // === Ensure Log Directory Exists ===
    // Create "Flight_Testdata" directory with full permissions if missing
    mkdir("Flight_Testdata", 0777);

    // === Generate Timestamped Filename (Once Per Program Run) ===
    static char filename[128] = {0};  ///< Static buffer to store the log file path
    if (filename[0] == '\0') {
        time_t now = time(NULL);          ///< Current system time
        struct tm *t = localtime(&now);   ///< Local time structure
        snprintf(filename, sizeof(filename),
                 "Flight_Testdata/BMS_%04d%02d%02d_%02d%02d%02d.txt",
                 t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
                 t->tm_hour, t->tm_min, t->tm_sec);
    }

    // === Open Log File in Append Mode ===
    FILE *file = fopen(filename, "a");
    if (file) {
        // Write the JSON string followed by a newline
        fprintf(file, "%s\n", data);
        fclose(file);
    } else {
#if ENABLE_PRINT_LOG_USB
        fprintf(stderr, "[ERROR] Could not open %s for writing.\n", filename);
#endif
    }
}

/**
 * @brief Process incoming USB data and route it to the appropriate handler (BMS or MC).
 *
 * This function is responsible for interpreting the USB data frame received from
 * a connected device. It extracts a 4-byte device ID from the beginning of the frame,
 * determines the target subsystem (e.g., Motor Controller or Battery Management System),
 * and forwards the data to the correct JSON converter function.
 *
 * Once the JSON-formatted output is generated, it is logged locally via
 * `JSON_datalog()` and may optionally be transmitted over a network.
 *
 * **Processing Steps:**
 * 1. Validate input buffer and length.
 * 2. Extract the 4-byte device ID (little-endian).
 * 3. Identify the source (e.g., Motor Controller) based on the ID range.
 * 4. Convert the binary data into JSON using the respective handler.
 * 5. Log the JSON string (if valid and not an error frame).
 *
 * @param[in] data Pointer to the raw USB data buffer.
 * @param[in] len  Length of the received USB data in bytes.
 *
 * @note
 * - Currently, only Motor Controller (MC) frames are processed.
 * - BMS frame handling can be added similarly by expanding the ID range logic.
 * - Frames with unrecognized offsets are safely skipped and not logged.
 */
void process_usb_data(uint8_t *data, int len) {
    // --- Step 1: Validate input ---
    if (data == NULL || len < 4) {
        fprintf(stderr, "[ERROR] Invalid USB data input.\n");
        return;
    }

    char json[256] = {0};  ///< Output buffer for formatted JSON data

#if DEBUG_LOGS
    // --- Debug: Dump raw USB frame content ---
    printf("\n[DEBUG] Received USB Data (len=%d): ", len);
    for (int i = 0; i < len; i++) {
        printf("0x%02X ", data[i]);
    }
    printf("\n");
#endif

    // --- Step 2: Extract 4-byte device ID (Little Endian) ---
    uint32_t id = (data[3] << 24) |
                  (data[2] << 16) |
                  (data[1] << 8)  |
                  data[0];

#if DEBUG_LOGS
    printf("[DEBUG] Parsed ID: %u\n", id);
#endif

    // --- Step 3: Identify Motor Controller frame based on ID range ---
    if ((id >= 20  && id <= 27)  ||
        (id >= 40  && id <= 47)  ||
        (id >= 60  && id <= 67)  ||
        (id >= 80  && id <= 87)  ||
        (id >= 100 && id <= 107) ||
        (id >= 120 && id <= 127) ||
        (id >= 140 && id <= 147)) {

        // --- Step 4: Convert binary data to JSON ---
        mc_JSONdata(data, json, sizeof(json));

#if DEBUG_LOGS
        printf("[DEBUG] JSON Data --> %s\n", json);
#endif

        // --- Step 5: Validate and log ---
        if (strstr(json, "\"error\": \"Unknown Offset") != NULL) {
            fprintf(stderr, "[WARN] Skipping unknown MC offset frame for ID: 0x%02X\n", data[0]);
            return;  // Skip invalid or incomplete frames
        }

        // Log valid Motor Controller frame
        JSON_datalog(json);
    }

    // BMS Controller ID Ranges (each ID group spans 8 values)
    if (id < 20) { // Use the dummy ID for the condition {

        bms_JSONdata(data, json, sizeof(json)); // Pass the dummy data

        // === Skip transmission/logging if fallback/unknown offset ===
        if (strstr(json, "\"error\": \"Unknown Offset") != NULL) {
            fprintf(stderr, "[WARN] Skipping unknown MC offset frame for ID: 0x%02X\n", data[0]);
            return;  // Exit early, do not send or log
        }
        
        BMS_JSON_datalog(json);
      }
}



/**
 * @brief Parses raw USB frame data from the Motor Controller (MC) into structured JSON format.
 *
 * This function interprets binary data received from the Motor Controller over USB,
 * extracts key parameters based on message ID offsets (0x00–0x07),
 * and converts them into a human-readable JSON string.
 *
 * Each message type (defined by the lower nibble of the 4-byte ID) has a specific data structure.
 * The parsed information includes motor telemetry, control flags, voltage/current parameters,
 * error/warning codes, and PWM-related information. The function automatically
 * timestamps each JSON entry for easier synchronization and logging.
 *
 * Example JSON output (for offset 0x01):
 * @code
 * {
 *   "timestamp": "2025-11-03 14:32:10",
 *   "id": "0x12345601",
 *   "length": 8,
 *   "fields": {
 *       "BTV": "0x0C8A",
 *       "BCAvg": "0x002F",
 *       "RPM": "0x0001A2B3"
 *   }
 * }
 * @endcode
 *
 * @note
 * - The ID is extracted as a 4-byte little-endian integer (USBdata[0–3]).
 * - The offset (lower nibble of the ID) determines the message type.
 * - Invalid or unknown offsets generate a fallback JSON with an error description.
 * - All numerical values are represented in hexadecimal for clarity.
 *
 * @param[in]  USBdata     Pointer to the raw USB frame (must be ≥14 bytes for full parsing).
 * @param[out] json        Pointer to the buffer where formatted JSON is stored.
 * @param[in]  json_size   Size of the output buffer to avoid overflow.
 *
 * @retval None
 *
 * @warning Ensure `json` has enough space (recommended ≥256 bytes).
 * @warning Passing NULL pointers will result in an error JSON message.
 */

void mc_JSONdata(uint8_t *USBdata, char *json, size_t json_size) {
    // === Argument Validation ===
    if (USBdata == NULL || json == NULL || json_size == 0) {
        if (json && json_size > 0) {
            snprintf(json, json_size, "{ \"error\": \"Invalid arguments\" }");
        }
        return;
    }

    // === Get current timestamp ===
    char timestamp[64];
    get_timestamp(timestamp, sizeof(timestamp));

    // === Parse 4-byte Motor ID from USBdata[0-3] (Little-endian) ===
    uint32_t id = (USBdata[3] << 24) | (USBdata[2] << 16) | (USBdata[1] << 8) | USBdata[0];

    // === Determine Offset (lower digit of ID) ===
    unsigned int offset = id % 10;

    // === Switch on offset ===
    switch (offset) {
case 0x00:
    snprintf(json, json_size,
        "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 5, \"fields\": { \"PWM\": \"0x%08X\", \"Flag\": \"0x%02X\" } }",
        timestamp, id,
        (uint32_t)(USBdata[5] | (USBdata[6] << 8) | (USBdata[7] << 16) | (USBdata[8] << 24)), // PWM
        (uint8_t)USBdata[9]  // Flag
    );
    break;
        case 0x01:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": { \"BTV\": \"0x%04X\", \"BCAvg\": \"0x%04X\", \"RPM\": \"0x%08X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5] | (USBdata[6] << 8)),         // BTV
                (uint16_t)(USBdata[7] | (USBdata[8] << 8)),         // BCAvg
                (uint32_t)(USBdata[9] | (USBdata[10] << 8) |
                (USBdata[11] << 16) | (USBdata[12] << 24))          // RPM
            );
            break;

        case 0x02: 
            uint16_t mt = (uint16_t)(USBdata[5] | (USBdata[6] << 8));     // MT
            uint16_t etm = (uint16_t)(USBdata[7] | (USBdata[8] << 8));    // ETM
            uint16_t etc = (uint16_t)(USBdata[9] | (USBdata[10] << 8));   // ETC
            uint16_t exst = (uint16_t)(USBdata[11] | (USBdata[12] << 8)); // EXST

            // === Format JSON ===
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": { \"MT\": \"0x%04X\", \"ETM\": \"0x%04X\", \"ETC\": \"0x%04X\", \"EXST\": \"0x%04X\" } }",
                timestamp, id, mt, etm, etc, exst
            );
            break;

        case 0x03:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 4, \"fields\": { \"OPWM\": \"0x%04X\", \"IPWM\": \"0x%04X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5] | (USBdata[6] << 8)),     // OPWM
                (uint16_t)(USBdata[7] | (USBdata[8] << 8))      // IPWM
            );
            break;

        case 0x04:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": { \"ERR\": \"0x%08X\", \"WRN\": \"0x%08X\" } }",
                timestamp, id,
                (uint32_t)(USBdata[5] << 24 | USBdata[6] << 16 | USBdata[7] << 8 | USBdata[8]),     // ERR
                (uint32_t)(USBdata[9] << 24 | USBdata[10] << 16 | USBdata[11] << 8 | USBdata[12])   // WRN
            );
            break;

        case 0x05:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 6, \"fields\": { \"NTC\": \"0x%08X\", \"ESCIS\": \"0x%04X\" } }",
                timestamp, id,
                (uint32_t)(USBdata[5] << 24 | USBdata[6] << 16 | USBdata[7] << 8 | USBdata[8]),     // NTC
                (uint16_t)(USBdata[9] | (USBdata[10] << 8))                                          // ESCIS
            );
            break;

        case 0x06:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": { \"BATTIV\": \"0x%04X\", \"EFV\": \"0x%04X\", \"PCM\": \"0x%04X\", \"PCA\": \"0x%04X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5] | (USBdata[6] << 8)),      // BATTIV
                (uint16_t)(USBdata[7] | (USBdata[8] << 8)),      // EFV
                (uint16_t)(USBdata[9] | (USBdata[10] << 8)),     // PCM
                (uint16_t)(USBdata[11] | (USBdata[12] << 8))     // PCA
            );
            break;

        case 0x07:
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 3, \"fields\": { \"BCM\": \"0x%04X\", \"IBUS\": \"0x%02X\" } }",
                timestamp, id,
                (uint16_t)(USBdata[5] | (USBdata[6] << 8)),  // BCM
                USBdata[7]                                   // IBUS
            );
            break;

        default:
            // Fallback for unknown offset
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"type\": \"MC\", \"error\": \"Unknown Offset 0x%02X\" }",
                timestamp, id, offset
            );
            break;
    }
}



/**
 * @brief Processes USB data and formats it into BMS-related JSON based on the ID.
 *
 * This function takes a pointer to the raw USB data buffer, a character buffer
 * for storing the resulting JSON string, and the size of the JSON buffer. It
 * extracts the ID from the first byte of the USB data and then uses a switch
 * statement to parse the subsequent bytes based on the ID. The parsed data is
 * then formatted into a JSON string.
 *
 * @param USBdata Pointer to the buffer containing the received USB data.
 * @param json Buffer to store the formatted JSON string.
 * @param json_size Size of the JSON buffer to prevent buffer overflows.
 */
void bms_JSONdata(uint8_t *USBdata, char *json, size_t json_size) {
    char timestamp[64];
    get_timestamp(timestamp, sizeof(timestamp));
//    uint16_t id = USBdata[1] | (USBdata[0] << 8); // 2 bytes for ID

                    uint8_t  id = (USBdata[3] << 24) |
                                          (USBdata[2] << 16) |
                                          (USBdata[1] << 8) |
                                          USBdata[0];
    switch (id) {

        case 0x00F: {
            snprintf(json, json_size,
                "{ \"timestamp\": \"%s\", \"id\": \"0x0F\", \"length\": 8, \"fields\": { "
                "\"RLY\": \"0x%04X\", \"MCELL\": \"0x%02X\", \"PCELLS\": \"0x%02X\", "
                "\"ROLLCNT\": \"0x%02X\", \"FSTATUS\": \"0x%04X\", \"PSOC\": \"0x%02X\" } }",
                timestamp,
                USBdata[6] | (USBdata[5] << 8), 
                USBdata[7], 
                USBdata[8],
                USBdata[9], 
                USBdata[11] | (USBdata[10] << 8),  
                USBdata[12]);
            break;
        }

    case 0x00E: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x0E\", \"length\": 7, \"fields\": { "
            "\"PINSTVOLT\": \"0x%04X\", \"PCUR\": \"0x%04X\", \"PSOC\": \"0x%02X\", "
            "\"AVGTEMP\": \"0x%02X\", \"HITEMP\": \"0x%02X\" } }",
            timestamp,
            USBdata[6] | (USBdata[5] << 8),   // PINSTVOLT
            USBdata[8] | (USBdata[7] << 8),   // PCUR
            USBdata[9],                       // PSOC
            USBdata[10],                      // AVGTEMP
            USBdata[11]);                     // HITEMP
            
        break;
    }


    case 0x00D: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x0D\", \"length\": 8, \"fields\": { "
            "\"PRES\": \"0x%04X\", \"PDOD\": \"0x%02X\", \"PSOH\": \"0x%02X\", "
            "\"PSUMVOLTS\": \"0x%04X\", \"MAXPVOLTS\": \"0x%04X\" } }",
            timestamp,
            USBdata[6] | (USBdata[5] << 8),   // PRES
            USBdata[7],                       // PDOD
            USBdata[8],                       // PSOH
            USBdata[10] | (USBdata[9] << 8),  // PSUMVOLTS
            USBdata[12] | (USBdata[11] << 8)  // MAXPVOLTS
        );
        break;
    }


    case 0x004: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x04\", \"length\": 8, \"fields\": { "
            "\"MINPVOLTS\": \"0x%04X\", \"TOPCY\": \"0x%04X\", \"CURLIM\": \"0x%04X\", "
            "\"MAXPDCL\": \"0x%04X\" } }",
            timestamp,
            USBdata[6] | (USBdata[5] << 8),
            USBdata[8] | (USBdata[7] << 8),
            USBdata[10] | (USBdata[9] << 8),
            USBdata[12] | (USBdata[11] << 8));
        break;
    }


    case 0x005: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x05\", \"length\": 8, \"fields\": { "
            "\"MAXPCCL\": \"0x%04X\", \"AVGCUR\": \"0x%04X\", \"HITEMP\": \"0x%02X\", "
            "\"HITHERID\": \"0x%02X\", \"LOWTEMP\": \"0x%02X\", \"LOWTHERID\": \"0x%02X\" } }",
            timestamp,
            USBdata[6] | (USBdata[5] << 8),
            USBdata[8] | (USBdata[7] << 8),
            USBdata[9],
            USBdata[10],
            USBdata[11],
            USBdata[12]);
        break;
    }


    case 0x006: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x06\", \"length\": 8, \"fields\": { "
            "\"AAVGTEMP\": \"0x%02X\", \"INTTEMP\": \"0x%02X\", \"FSPD\": \"0x%02X\", "
            "\"RQFSPD\": \"0x%02X\", \"LCELLVOLTS\": \"0x%04X\", \"LCELLVID\": \"0x%02X\", \"HCELLVID\": \"0x%02X\" } }",
            timestamp,
            USBdata[5],
            USBdata[6],
            USBdata[7],
            USBdata[8],
            USBdata[10] | (USBdata[9] << 8),
            USBdata[11],
            USBdata[12]);
        break;
    }


    case 0x007: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x07\", \"length\": 8, \"fields\": { "
            "\"HCELLVOLTS\": \"0x%04X\", \"AVGCELLVOLTS\": \"0x%04X\", \"LOPCELLVOLTS\": \"0x%04X\", "
            "\"LOPCELLVOLTSID\": \"0x%02X\", \"HOPCELLVOLTSID\": \"0x%02X\" } }",
            timestamp,
            USBdata[6] | (USBdata[5] << 8),
            USBdata[8] | (USBdata[7] << 8),
            USBdata[10] | (USBdata[9] << 8),
            USBdata[11],
            USBdata[12]);
        break;
    }


    case 0x008: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": { "
            "\"HOPCELLVOLTS\": \"0x%04X\", \"AVGCELLVOLTS\": \"0x%04X\", \"LCELLRES\": \"0x%04X\", "
            "\"HCELLRES\": \"0x%04X\" } }",
            timestamp, id,
            USBdata[6] | (USBdata[5] << 8),
            USBdata[8] | (USBdata[7] << 8),
            USBdata[10] | (USBdata[9] << 8),
            USBdata[12] | (USBdata[11] << 8));
        break;
    }

    case 0x009: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"fields\": { "
            "\"AVGCELLINTRES\": \"0x%04X\", \"ADPTTOC\": \"0x%04X\", \"ADPTAMPH\": \"0x%04X\", "
            "\"MAXCELLVOLTS\": \"0x%04X\" } }",
            timestamp, id,
            USBdata[6] | (USBdata[5] << 8),
            USBdata[8] | (USBdata[7] << 8),
            USBdata[10] | (USBdata[9] << 8),
            USBdata[12] | (USBdata[11] << 8));
        break;
    }


    case 0x00A: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x0A\", \"length\": 8, \"fields\": { "
            "\"ADPTSOC\": \"0x%02X\", \"MINCELLVOLTS\": \"0x%04X\", \"FVOLTS\": \"0x%04X\", "
            "\"J1772ACL\": \"0x%04X\", \"J1772PS\": \"0x%02X\" } }",
            timestamp,
            USBdata[5],
            USBdata[7] | (USBdata[6] << 8),
            USBdata[9] | (USBdata[8] << 8),
            USBdata[11] | (USBdata[10] << 8),
            USBdata[12]);
        break;
    }


    case 0x00B: {
        snprintf(json, json_size,
            "{ \"timestamp\": \"%s\", \"id\": \"0x0B\", \"length\": 8, \"fields\": { "
            "\"J1772ACPOL\": \"0x%04X\", \"J1772ACVOLTS\": \"0x%04X\", "
            "\"DTCF1\": \"0x%04X\", \"DTCF2\": \"0x%04X\" } }",
            timestamp,
            USBdata[6] | (USBdata[5] << 8),
            USBdata[8] | (USBdata[7] << 8),
            USBdata[10] | (USBdata[9] << 8),
            USBdata[12] | (USBdata[11] << 8));
        break;
    }

    default: {
        snprintf(json, json_size,
        "{ \"timestamp\": \"%s\", \"id\": \"0x%02X\", \"length\": 8, \"error\": \"Unknown ID\" }",
        timestamp, id);
        break;
        }
    }
}
