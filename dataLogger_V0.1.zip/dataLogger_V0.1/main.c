// --------------------------------------------------------------------------------------------------
// Includes and Configuration for USB and UDP Communication
// --------------------------------------------------------------------------------------------------

#include <pthread.h>         // For multi-threading support
#include <unistd.h>          // For sleep and system calls
#include <stdio.h>           // For standard I/O functions
#include <stdlib.h>          // For general utilities (malloc, free, etc.)
#include <stdbool.h>         // For boolean type definitions
#include <stddef.h>          // For NULL macro definition
#include <stdint.h>          // For fixed-width integer types
#include <string.h>          // For memory operations like memcpy

#include "USB_Driver.h"        // Custom USB interface header
#include "USB_Datalogger.h"    // Header for processing USB CAN frame data
#include  "USB_FrameParser.h"  // Header file to create USB raw data into valid frame

// --------------------------------------------------------------------------------------------------
// Application Configuration: Define board role (Battery Management System or Motor Controller)
// --------------------------------------------------------------------------------------------------

#define CAN_A            // For Sensor board (3rd device)

#ifdef CAN_A
    #define USB_DEVICE_PATH   "/dev/ttyBATTERY"

#elif defined(CAN_B)

    #define USB_DEVICE_PATH   "/dev/ttyMOTOR"  // or "/dev/ttyMOTOR_RS485" as needed

#else
    #error "No valid port is define"
#endif

#define RETRY_DELAY   2       // Delay in seconds before retrying USB init after failure

// --------------------------------------------------------------------------------------------------
// Main Function: Application Entry Point
// --------------------------------------------------------------------------------------------------

/**
 * @brief Entry point for the combined USB and UDP data processing application.
 *
 * This function initializes USB and UDP interfaces, spawns the UDP listening thread,
 * and continuously monitors the USB device for new CAN frames.
 *
 * @return Always returns 0 (never exits under normal conditions).
 */
int main() {
    printf("[MAIN] Initializing Combined USB and UDP Application...\n");

    // Set the application's callback for processing received USB data
    set_usb_data_callback(parse_motor_usb_can_frames);

    // Initialize USB (monitors the specified device path)
    if (!usb_init()) {
        fprintf(stderr, "[ERROR] USB initialization failed.\n");
    } else {
#if USB_DEBUG_PRINT
        printf("[MAIN] USB initialized successfully.\n");
#endif
    }

    // Main loop for continuous USB operation
    while (true) {
#if USB_DEBUG_PRINT
        printf("[MAIN] Listening on USB device: %s\n", USB_DEVICE_PATH);
#endif
        usb_run(USB_DEVICE_PATH);     // Handle USB data reception and callbacks
        usb_cleanup();                // Reset and clean resources after USB disconnect/error
#if USB_DEBUG_PRINT
        printf("[MAIN] USB listener restarted after potential disconnection.\n");
#endif
        sleep(RETRY_DELAY);          // Wait before retrying USB detection
    }

    return 0; // Unreachable
}
