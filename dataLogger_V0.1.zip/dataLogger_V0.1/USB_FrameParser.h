/**
 * @file usb_frame_parser.h
 * @brief Header file for USB CAN frame parsing and validation module.
 *
 * This module provides functionality to parse, validate, and handle fixed-length
 * USB CAN frames received from a motor controller or similar device.
 * The parser reconstructs frames from a continuous USB byte stream using a
 * circular buffer, validates checksum and frame delimiters, and forwards valid
 * frames to the higher-level data handler.
 *
 * @version 1.0
 * @date 2025-11-03
 * @author Vijay Singh
 */

#ifndef USB_FRAME_PARSER_H
#define USB_FRAME_PARSER_H

// --------------------------------------------------------------------------------------------------
// Includes
// --------------------------------------------------------------------------------------------------

#include <stdint.h>   ///< For fixed-width integer types
#include <stdbool.h>  ///< For boolean type support

#ifdef __cplusplus
extern "C" {
#endif


// --------------------------------------------------------------------------------------------------
// Function Prototypes
// --------------------------------------------------------------------------------------------------

/**
 * @brief Parse and process incoming USB CAN frames.
 *
 * This function is the main entry point for handling incoming USB data.
 * It stores data in a circular buffer, detects valid CAN frame sequences,
 * validates checksums, and forwards valid payloads to the data handler.
 *
 * Example call (in your USB receive thread):
 * @code
 * parse_motor_usb_can_frames(usb_rx_buffer, bytes_read);
 * @endcode
 *
 * @param[in] data         Pointer to received USB data bytes.
 * @param[in] data_length  Number of bytes received from USB transfer.
 */
void parse_motor_usb_can_frames(const unsigned char *data, int data_length);

// --------------------------------------------------------------------------------------------------
// External Variables (optional)
// --------------------------------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif /* USB_FRAME_PARSER_H */
