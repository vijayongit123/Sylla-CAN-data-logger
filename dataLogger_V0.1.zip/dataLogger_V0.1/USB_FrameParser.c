// --------------------------------------------------------------------------------------------------
// Includes and Configuration for USB and UDP Communication
// --------------------------------------------------------------------------------------------------

#include <pthread.h>         // For multi-threading support
#include <unistd.h>          // For sleep and system calls
#include <stdio.h>           // For standard I/O functions
#include <stdlib.h>          // For general utilities (malloc, free, etc.)
#include <stdbool.h>         // For boolean type definitions
#include <stddef.h>          // For NULL macro definition
#include <stdint.h>          // For fixed-width integer types
#include <string.h>          // For memory operations like memcpy

#include "USB_Driver.h"        // Custom USB interface header
#include "USB_Datalogger.h"    // Header for processing USB CAN frame data
#include "USB_FrameParser.h"  // Header file to create USB raw data into valid frame

#define RETRY_DELAY               2       // Delay in seconds before retrying USB init after failure
#define USB_DEBUG_PRINT           0      // Set to 1 to enable debug output, 0 to disable

// --------------------------------------------------------------------------------------------------
// USB Frame Parsing Configuration
// --------------------------------------------------------------------------------------------------

#define USB_FRAME_MAX_LEN         256U   // Maximum allowed USB data chunk size
#define USB_CIRCULAR_BUFFER_SIZE  1024U  // Circular buffer size for incoming USB data
#define FIXED_FRAME_LEN           20U    // Expected fixed size of a complete USB CAN frame

#ifndef USB_DEBUG_PRINT
#define USB_DEBUG_PRINT           0      // Set to 1 to enable debug output, 0 to disable
#endif

// --------------------------------------------------------------------------------------------------
// Global Variables
// --------------------------------------------------------------------------------------------------

// Diagnostic counters for monitoring runtime anomalies
static volatile uint32_t usb_frame_checksum_errors = 0U;  ///< Counts checksum mismatches
static volatile uint32_t usb_frame_invalid_end = 0U;      ///< Counts invalid end byte errors
static volatile uint32_t usb_frame_overwrites = 0U;       ///< Counts overwritten bytes in circular buffer

// --------------------------------------------------------------------------------------------------
// Function definition
// --------------------------------------------------------------------------------------------------

/**
 * @brief Store incoming USB data into a circular buffer.
 *
 * This function copies each byte from the incoming USB data stream into a circular
 * buffer used for CAN frame reconstruction. If the buffer becomes full (i.e., the
 * write index catches up to the read index), the oldest data is overwritten and the
 * read index is advanced to maintain continuity.
 *
 * @param[in]  data             Pointer to the array of incoming USB data bytes.
 * @param[in]  data_length      Length of the incoming data array.
 * @param[out] circular_buffer Pointer to the circular buffer array.
 * @param[in,out] write_index   Pointer to the buffer write index.
 * @param[in,out] read_index    Pointer to the buffer read index.
 */
static void store_data_in_buffer(const uint8_t *data, uint16_t data_length,
                                 uint8_t *circular_buffer,
                                 uint16_t *write_index,
                                 uint16_t *read_index) {
    for (uint16_t byte_position = 0U; byte_position < data_length; ++byte_position) {
        circular_buffer[*write_index] = data[byte_position];
        *write_index = (*write_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;

        if (*write_index == *read_index) {
            *read_index = (*read_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;
            usb_frame_overwrites++; // track overwrites
#if USB_DEBUG_PRINT
            printf("[DEBUG] Overwrite occurred, total overwrites: %lu\n", (unsigned long)usb_frame_overwrites);
#endif
        }
    }
}

/**
 * @brief Search for the start sequence in the circular buffer.
 *
 * This function scans through the available bytes in the circular buffer to locate a valid
 * CAN frame start sequence. The expected 5-byte start sequence is defined by the protocol as:
 * 0xAA, 0x55, 0x01, 0x01, 0x01. If found, the read index is updated to the start position.
 *
 * @param[in,out] buffer       Pointer to the circular buffer.
 * @param[in,out] read_index   Pointer to the read index, updated if start sequence found.
 * @param[in]     available    Number of available bytes in the buffer.
 *
 * @return true if a valid start sequence is found, false otherwise.
 */
static bool find_start_sequence(uint8_t *buffer, uint16_t *read_index, uint16_t available) {
    uint16_t search_index = *read_index;
    while (available >= 5U) {
        if ((buffer[search_index] == 0xAAU) &&
            (buffer[(search_index + 1U) % USB_CIRCULAR_BUFFER_SIZE] == 0x55U) &&
            (buffer[(search_index + 2U) % USB_CIRCULAR_BUFFER_SIZE] == 0x01U) &&
            (buffer[(search_index + 3U) % USB_CIRCULAR_BUFFER_SIZE] == 0x01U) &&
            (buffer[(search_index + 4U) % USB_CIRCULAR_BUFFER_SIZE] == 0x01U)) {
            return true;
        }
        search_index = (search_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;
        available--;
        *read_index = search_index;
    }
    return false;
}

/**
 * @brief Extract a fixed-length frame from the circular buffer.
 *
 * This function copies a full frame of FIXED_FRAME_LEN bytes from the circular buffer
 * into a linear frame array, starting at the specified read index. It handles buffer
 * wrap-around using modulo arithmetic.
 *
 * @param[in]  buffer      Pointer to the circular buffer.
 * @param[out] frame       Pointer to the destination frame buffer.
 * @param[in]  read_index  Starting index in the circular buffer to extract the frame from.
 */
static void extract_frame(const uint8_t *buffer, uint8_t *frame, uint16_t read_index) {
    for (uint8_t frame_index = 0U; frame_index < FIXED_FRAME_LEN; ++frame_index) {
        frame[frame_index] = buffer[(read_index + frame_index) % USB_CIRCULAR_BUFFER_SIZE];
    }
}

/**
 * @brief Validate the structure and contents of a frame.
 *
 * This function performs validation of a frame based on two criteria:
 * 1. The 19th byte (index 18) must be the end delimiter byte (0x00).
 * 2. The checksum (byte 19) must match the calculated checksum of bytes 2 to 17.
 *
 * The checksum is calculated by summing all bytes from index 2 to 17 (inclusive)
 * and masking the result to 8 bits.
 *
 * @param[in] frame Pointer to the frame buffer.
 * @return true if the frame is valid, false otherwise.
 */
static bool validate_frame(const uint8_t *frame) {
    if (frame[18U] != 0x00U) {
        usb_frame_invalid_end++;
#if USB_DEBUG_PRINT
        printf("[DEBUG] Invalid end byte count: %lu\n", (unsigned long)usb_frame_invalid_end);
        printf("[DEBUG] Invalid end byte: 0x%02X\n", frame[18U]);
        printf("[DEBUG] Full Frame: ");
        for (uint8_t frame_byte_index = 0U; frame_byte_index < FIXED_FRAME_LEN; ++frame_byte_index) {
            printf("%02X ", frame[frame_byte_index]);
        }
        printf("\n");
#endif
        return false;
    }

    uint16_t checksum = 0U;
    for (uint8_t checksum_index = 2U; checksum_index <= 17U; ++checksum_index) {
        checksum += frame[checksum_index];
    }

    if (frame[19U] != (uint8_t)(checksum & 0xFFU)) {
        usb_frame_checksum_errors++;
#if USB_DEBUG_PRINT
        printf("[DEBUG] Checksum error count: %lu\n", (unsigned long)usb_frame_checksum_errors);
        printf("[DEBUG] Checksum mismatch: expected 0x%02X, got 0x%02X\n",
               (uint8_t)(checksum & 0xFFU), frame[19U]);
        printf("[DEBUG] Full Frame: ");
        for (uint8_t frame_byte_index = 0U; frame_byte_index < FIXED_FRAME_LEN; ++frame_byte_index) {
            printf("%02X ", frame[frame_byte_index]);
        }
        printf("\n");
#endif
        return false;
    }

    return true;
}

/**
 * @brief Handle and log a successfully validated CAN frame.
 *
 * This function extracts the message ID (bytes 5 to 8), data length (byte 9), and payload
 * (bytes 10 to 17) from the validated frame. The entire segment from byte 5 to 17 (13 bytes)
 * is passed to the higher-level application via `process_usb_CAN_data()`.
 *
 * This frame format is structured as follows:
 *   - Bytes 0-4: Start sequence (0xAA, 0x55, 0x01, 0x01, 0x01)
 *   - Bytes 5-8: 32-bit Message ID (Big Endian)
 *   - Byte 9:    Data Length Code (max 8 bytes)
 *   - Bytes 10-17: Payload data (up to 8 bytes)
 *   - Byte 18:   End marker (0x00)
 *   - Byte 19:   Checksum (sum of bytes 2-17)
 *
 * @param[in] frame Pointer to the validated frame buffer.
 */
static void handle_valid_frame(const uint8_t *frame) {
    uint32_t message_id = ((uint32_t)frame[8U] << 24U) |
                          ((uint32_t)frame[7U] << 16U) |
                          ((uint32_t)frame[6U] << 8U)  |
                          (uint32_t)frame[5U];
    uint8_t payload_length = frame[9U];

    if (payload_length > 8U) {
#if USB_DEBUG_PRINT
        printf("[DEBUG] Invalid data length: %u\n", payload_length);
#endif
        return;
    }

#if USB_DEBUG_PRINT
    printf("[DEBUG] Valid frame: MSG_ID=0x%08X (%u), Length=%u, Data=", message_id, message_id, payload_length);
    for (uint8_t data_byte_index = 10U; data_byte_index < 18U; ++data_byte_index) {
        printf("%02X ", frame[data_byte_index]);
    }
    printf("\n");
#endif

    process_usb_data((uint8_t *)&frame[5U], 13U);
}

/**
 * @brief Main entry point for processing USB CAN frames received from a motor controller.
 *
 * This function acts as the primary handler for receiving raw USB data, buffering it,
 * and extracting and validating fixed-length CAN frames encoded within. Valid frames
 * are forwarded to a user-defined processing function. It utilizes a circular buffer
 * to manage streaming data and ensures data integrity through start sequence detection,
 * end byte validation, and checksum verification.
 *
 * @param[in] data         Pointer to incoming USB byte stream.
 * @param[in] data_length  Number of bytes received.
 */
void parse_motor_usb_can_frames(const unsigned char *data, int data_length){
    if ((data == NULL) || (data_length == 0U) || (data_length > USB_FRAME_MAX_LEN)) {
        return;
    }

    static uint8_t circular_buffer[USB_CIRCULAR_BUFFER_SIZE];   ///< Internal ring buffer
    static uint16_t write_index = 0U;                           ///< Write index into circular buffer
    static uint16_t read_index = 0U;                            ///< Read index for processing

    store_data_in_buffer(data, data_length, circular_buffer, &write_index, &read_index);

    while (true) {
        uint16_t bytes_available = (write_index >= read_index) ?
            (write_index - read_index) :
            (USB_CIRCULAR_BUFFER_SIZE - read_index + write_index);

        if (bytes_available < FIXED_FRAME_LEN) {
            break;
        }

        if (!find_start_sequence(circular_buffer, &read_index, bytes_available)) {
            break;
        }

        uint8_t frame[FIXED_FRAME_LEN];
        extract_frame(circular_buffer, frame, read_index);

        if (!validate_frame(frame)) {
            read_index = (read_index + 1U) % USB_CIRCULAR_BUFFER_SIZE;
            continue;
        }

        handle_valid_frame(frame);
        read_index = (read_index + FIXED_FRAME_LEN) % USB_CIRCULAR_BUFFER_SIZE;
    }
}