/**
 * @file USB_Driver.h
 * @brief USB Serial Communication Driver Interface (libudev + pthreads)
 *
 * This header file provides the interface for USB serial communication
 * management on Linux using **libudev** and **POSIX threads**.  
 *
 * The driver supports:
 *  - Automatic USB device detection using Vendor ID and Product ID
 *  - Threaded read/write handling
 *  - Reconnection logic when the USB device is disconnected
 *  - Callback mechanism for received data
 *
 * Typical usage involves:
 *  1. Calling `usb_init()` to initialize udev monitoring
 *  2. Registering a callback via `set_usb_data_callback()`
 *  3. Running `usb_run("/dev/ttyUSB0")` to handle data communication
 *  4. Sending data using `usb_send_data()`
 *  5. Cleaning up resources with `usb_cleanup()`
 *
 * @version 1.0
 * @date 2025-11-03
 * @author
 * Vijay Singh
 */

#ifndef USB_DRIVER_H
#define USB_DRIVER_H

// --------------------------------------------------------------------------------------------------
// Includes
// --------------------------------------------------------------------------------------------------

#include <libudev.h>     ///< For USB device detection and monitoring
#include <stdio.h>       ///< For standard input/output operations
#include <stdlib.h>      ///< For memory management and general utilities
#include <stdbool.h>     ///< For boolean data types
#include <pthread.h>     ///< For multithreaded communication handling

// --------------------------------------------------------------------------------------------------
// USB Device Configuration
// --------------------------------------------------------------------------------------------------

/**
 * @brief USB Vendor ID for the CAN-based Motor Controller (e.g., CH340 chip).
 */
#define TARGET_VENDOR          "1a86"

/**
 * @brief USB Product ID for the CAN-based Motor Controller (e.g., CH340 chip).
 */
#define TARGET_PRODUCT         "7523"

/**
 * @brief Baud rate used for USB serial communication (in bits per second).
 */
#define BAUD_RATE_VALUE        2000000U

// --------------------------------------------------------------------------------------------------
// USB Operational Parameters
// --------------------------------------------------------------------------------------------------

/**
 * @brief Maximum allowed size (in bytes) for a USB receive buffer or data frame.
 */
#define MAX_FRAME_SIZE         256U

/**
 * @brief Delay (in seconds) before retrying a USB reconnection after disconnection.
 */
#define RECONNECT_DELAY_SEC    5U

/**
 * @brief Poll timeout for the libudev monitor (in milliseconds).
 */
#define UDEV_MONITOR_TIMEOUT   1000U

// --------------------------------------------------------------------------------------------------
// Global Variables
// --------------------------------------------------------------------------------------------------

/**
 * @brief File descriptor of the active USB serial device.
 *
 * Set by `usb_run()` when a valid USB device is connected and opened.
 */
extern int usb_fd;

/**
 * @brief Thread ID of the USB receive thread.
 *
 * This thread continuously reads data from the USB device.
 */
extern pthread_t rx_thread_id;

/**
 * @brief Global control flag used to manage USB service execution.
 *
 * When set to `false`, all USB threads are signaled to stop.
 */
extern volatile bool running;

// --------------------------------------------------------------------------------------------------
// Callback Type Definition
// --------------------------------------------------------------------------------------------------

/**
 * @brief Callback type for handling received USB data.
 *
 * The driver invokes this function automatically whenever data
 * is received from the USB interface.
 *
 * @param data   Pointer to the received data buffer.
 * @param length Number of bytes received.
 */
typedef void (*data_received_callback)(const unsigned char *data, int length);

// --------------------------------------------------------------------------------------------------
// Function Declarations
// --------------------------------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Initialize the USB subsystem and udev monitoring.
 *
 * Sets up udev context and prepares for detection of USB plug/unplug events.
 *
 * @return `true` if initialization is successful, otherwise `false`.
 */
bool usb_init(void);

/**
 * @brief Clean up and release all USB-related resources.
 *
 * Stops running threads, closes file descriptors, and releases allocated memory.
 */
void usb_cleanup(void);

/**
 * @brief Register a user callback for received USB data.
 *
 * This callback is triggered automatically when USB data is received.
 *
 * @param callback Pointer to the user-defined callback function.
 */
void set_usb_data_callback(data_received_callback callback);

/**
 * @brief Execute the main USB service loop.
 *
 * This function handles USB detection, read thread creation, and reconnection.
 *
 * @param device_path Path to the USB device (e.g., "/dev/ttyUSB0").
 */
void usb_run(const char *device_path);

/**
 * @brief Send data to the USB serial interface.
 *
 * Writes data to the connected USB device. The operation is thread-safe.
 *
 * @param data   Pointer to the data buffer.
 * @param length Number of bytes to transmit.
 * @return Number of bytes written, or `-1` on failure.
 */
int usb_send_data(const unsigned char *data, int length);

#ifdef __cplusplus
}
#endif

#endif /* USB_DRIVER_H */
